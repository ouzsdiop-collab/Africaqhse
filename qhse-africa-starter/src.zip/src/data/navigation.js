export const siteOptions = [
  'Site principal',
  'Site industriel',
  'Vue groupe multi-sites'
];

export const navigationGroups = [
  {
    label: 'Pilotage',
    items: [
      { id: 'dashboard', label: 'Dashboard', icon: '◫' },
      { id: 'sites', label: 'Sites', icon: '⌂' },
      { id: 'incidents', label: 'Incidents', icon: '!' },
      { id: 'risks', label: 'Risques', icon: '△' },
      { id: 'actions', label: 'Actions', icon: '✓' }
    ]
  },
  {
    label: 'Conformité',
    items: [
      { id: 'iso', label: 'Conformité & ISO', icon: '◎' },
      { id: 'audits', label: 'Audits', icon: '☑' },
      { id: 'products', label: 'Produits / FDS', icon: '⚗' },
      { id: 'imports', label: 'Import documents', icon: '⎘' },
      { id: 'activity-log', label: 'Journal des modifications', icon: '≣' }
    ]
  },
  {
    label: 'Différenciation',
    items: [
      { id: 'analytics', label: 'Analytics / Synthèse', icon: '≈' },
      { id: 'ai-center', label: 'Centre IA', icon: '✦' }
    ]
  }
];

/** Métadonnées shell (topbar) — titres, fil d’Ariane perceptif, CTA principal */
export const pageTopbarById = {
  dashboard: {
    title: 'Cockpit QHSE',
    kicker: 'Pilotage',
    subtitle: 'Vue consolidée des indicateurs critiques, alertes et priorités du jour.',
    cta: { label: 'Voir les incidents', pageId: 'incidents' }
  },
  sites: {
    title: 'Sites & périmètres',
    kicker: 'Organisation',
    subtitle:
      'Référentiel des sites pour rattacher incidents, audits et actions à un périmètre réel (V1).',
    cta: { label: 'Voir les incidents', pageId: 'incidents' }
  },
  incidents: {
    title: 'Incidents terrain',
    kicker: 'Sécurité & environnement',
    subtitle: 'Suivi des événements, investigations et plans de correction.',
    cta: { label: 'Aller au plan d’actions', pageId: 'actions' }
  },
  risks: {
    title: 'Registre des risques',
    kicker: 'Risques',
    subtitle: 'Cartographie, criticité et traitements associés.',
    cta: { label: 'Plan d’actions', pageId: 'actions' }
  },
  actions: {
    title: 'Plan d’actions',
    kicker: 'Exécution',
    subtitle: 'Pilotez les actions correctives, préventives et le suivi des échéances.',
    cta: { label: 'Centre IA', pageId: 'ai-center' }
  },
  iso: {
    title: 'Conformité & ISO',
    kicker: 'Système',
    subtitle: 'Pilotage du SMS QHSE, référentiels, exigences et preuves pour audits et revue de direction.',
    cta: { label: 'Audits terrain', pageId: 'audits' }
  },
  audits: {
    title: 'Audits & conformité',
    kicker: 'Conformité',
    subtitle: 'Audits planifiés, constats et preuves documentaires.',
    cta: { label: 'Produits / FDS', pageId: 'products' }
  },
  products: {
    title: 'Produits / FDS',
    kicker: 'Documentation',
    subtitle: 'Fiches de données sécurité et registres produits.',
    cta: { label: 'Import documents', pageId: 'imports' }
  },
  imports: {
    title: 'Import de documents',
    kicker: 'Documents',
    subtitle: 'Chargement et aperçu brut des contenus (PDF, Excel) — base pour extraction intelligente ultérieure.',
    cta: { label: 'Centre IA', pageId: 'ai-center' }
  },
  analytics: {
    title: 'Analytics & synthèse',
    kicker: 'Indicateurs',
    subtitle:
      'Synthèse consolidée incidents, NC, actions, audits et alertes — base revue direction et rapports périodiques.',
    cta: { label: 'Dashboard', pageId: 'dashboard' }
  },
  'ai-center': {
    title: 'Centre IA',
    kicker: 'Assistants',
    subtitle: 'Assistants et analyses pilotées pour accélérer vos revues QHSE.',
    cta: { label: 'Retour dashboard', pageId: 'dashboard' }
  },
  'activity-log': {
    title: 'Journal des modifications',
    kicker: 'Traçabilité',
    subtitle: 'Historique des changements et traçabilité opérationnelle.',
    cta: { label: 'Audits', pageId: 'audits' }
  }
};

/**
 * Contexte de navigation pour fil d’Ariane / recherche.
 * @param {string} pageId
 * @returns {{ groupLabel: string; item: { id: string; label: string; icon: string } } | null}
 */
export function getNavContextForPage(pageId) {
  for (const group of navigationGroups) {
    const item = group.items.find((i) => i.id === pageId);
    if (item) return { groupLabel: group.label, item };
  }
  return null;
}

/**
 * Fil d’Ariane léger : racine → groupe → page courante.
 * @param {string} pageId
 */
export function getBreadcrumbForPage(pageId) {
  const meta = pageTopbarById[pageId];
  const ctx = getNavContextForPage(pageId);
  const currentTitle = meta?.title || ctx?.item?.label || 'Module';
  /** @type {{ label: string; pageId?: string | null }[]} */
  const crumbs = [{ label: 'Accueil', pageId: 'dashboard' }];
  if (ctx) {
    crumbs.push({ label: ctx.groupLabel, pageId: null });
  }
  crumbs.push({ label: currentTitle, pageId: null });
  return crumbs;
}

/**
 * Toutes les entrées menu (pour recherche rapide).
 */
export function getFlattenedNavItems() {
  return navigationGroups.flatMap((g) =>
    g.items.map((item) => ({
      ...item,
      groupLabel: g.label
    }))
  );
}
