export const dashboardKpis = [
  { label: 'Incidents du mois', value: '18', tone: 'amber', note: '3 nouveaux sur 7 jours' },
  { label: 'Risques critiques', value: '6', tone: 'red', note: '2 sans action engagée' },
  { label: 'Actions en retard', value: '11', tone: 'blue', note: '4 sur site principal' },
  { label: 'Taux conformité', value: '87%', tone: 'green', note: 'Audit interne favorable' }
];

export const alerts = [
  { title: 'Incident environnemental — bassin nord', detail: 'Déversement mineur à vérifier avant clôture.', status: 'Critique', tone: 'red', meta: 'Aujourd’hui' },
  { title: 'Action corrective non lancée', detail: 'Protection machine non remplacée sur atelier concassage.', status: 'Retard', tone: 'amber', meta: '+4 jours' },
  { title: 'Audit site sud à préparer', detail: 'Pièces de preuve manquantes sur 2 contrôles.', status: 'Préparation', tone: 'blue', meta: 'Cette semaine' }
];

export const incidents = [
  ['INC-204', 'Quasi-accident', 'Zone concassage', 'Modérée', 'En analyse', '03/04'],
  ['INC-203', 'Environnement', 'Bassin nord', 'Critique', 'Ouvert', '02/04'],
  ['INC-202', 'Accident mineur', 'Atelier maintenance', 'Faible', 'Suivi', '01/04'],
  ['INC-201', 'Presque accident', 'Accès rampe', 'Élevée', 'Clos', '29/03']
];

export const risks = [
  {
    title: 'Renversement d’engin en pente',
    detail: 'Zone de manutention — signalisation et stabilité des sols à revoir ; plan de manœuvre à formaliser.',
    status: 'Critique',
    tone: 'red',
    meta: 'G5 × P4'
  },
  {
    title: 'Pollution ponctuelle par hydrocarbures',
    detail: 'Zone stockage — rétention incomplète ; contrôle des absorbants et registre des déchets.',
    status: 'Très élevé',
    tone: 'amber',
    meta: 'G4 × P3'
  },
  {
    title: 'Exposition bruit opérateurs',
    detail: 'Poste bruyant — EPI disponibles ; campagne de mesures et formation à planifier.',
    status: 'Élevé',
    tone: 'amber',
    meta: 'G3 × P3'
  },
  {
    title: 'Dérapage procédure contrôle qualité',
    detail: 'Ligne de conditionnement — non-conformité mineure détectée ; revue du mode opératoire.',
    status: 'Élevé',
    tone: 'amber',
    meta: 'G2 × P4'
  }
];

export const actionColumns = {
  todo: [
    { title: 'Mettre à jour le plan de circulation', detail: 'Site principal • Resp. Exploitation' },
    { title: 'Vérifier stock absorbants', detail: 'Bassin nord • Resp. Environnement' }
  ],
  doing: [
    { title: 'Former opérateurs zone concassage', detail: 'Échéance 09/04 • Resp. HSE' },
    { title: 'Installer signalétique pente', detail: 'Échéance 12/04 • Resp. Maintenance' }
  ],
  overdue: [
    { title: 'Contrôle rétention hydrocarbures', detail: '+4 jours • Resp. Atelier' },
    { title: 'Clôturer NC audit interne', detail: '+2 jours • Resp. Qualité' }
  ]
};

export const audits = [
  { title: 'Contrôles opérationnels documentés', detail: 'Preuves présentes, mise à jour récente.', status: 'Conforme', tone: 'green' },
  { title: 'Gestion des déchets dangereux', detail: 'Registre incomplet sur 1 zone de stockage.', status: 'Écart', tone: 'amber' },
  { title: 'Habilitations et autorisations', detail: '2 échéances proches à anticiper.', status: 'Vigilance', tone: 'blue' },
  { title: 'Gestion d’urgence environnementale', detail: 'Exercice à reprogrammer ce mois-ci.', status: 'Prioritaire', tone: 'red' }
];

export const products = [
  ['Acide sulfurique', '7664-93-9', 'Corrosif', '02/2026'],
  ['Gasoil industriel', '68334-30-5', 'Inflammable', '01/2026'],
  ['Soude caustique', '1310-73-2', 'Corrosif', '11/2025']
];
