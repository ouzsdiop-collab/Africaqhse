const STYLE_ID = 'qhse-activity-log-styles';

const CSS = `
.activity-log-page .activity-log-toolbar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:12px;padding:10px 12px;border-radius:12px;background:rgba(0,0,0,.12);border:1px solid rgba(148,163,184,.1)}
.activity-log-page .activity-log-toolbar > span:first-child{font-size:11px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;color:var(--text3)}
.activity-log-toolbar-note{font-size:13px;font-weight:600;color:var(--text2)}

.activity-log-summary{display:grid;grid-template-columns:minmax(140px,0.9fr) minmax(200px,1.4fr) minmax(140px,1fr);gap:12px;margin-bottom:14px}
@media (max-width:900px){.activity-log-summary{grid-template-columns:1fr}}
.activity-log-summary-card{border-radius:14px;border:1px solid rgba(148,163,184,.12);background:rgba(255,255,255,.03);padding:12px 14px;display:grid;gap:6px;min-width:0}
.activity-log-summary-card--stretch{min-height:100%}
.activity-log-summary-k{font-size:10px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--text3)}
.activity-log-summary-v{font-size:28px;font-weight:800;letter-spacing:-.03em;color:var(--text);line-height:1.1}
.activity-log-summary-v--sm{font-size:15px;font-weight:700;letter-spacing:-.01em}
.activity-log-summary-h{font-size:11px;color:var(--text3);line-height:1.35}
.activity-log-summary-chips{display:flex;flex-wrap:wrap;gap:6px;align-items:center;min-height:32px}
.activity-log-summary-chip{font-size:11px;font-weight:800;padding:5px 10px;border-radius:999px;border:1px solid rgba(148,163,184,.2);background:rgba(0,0,0,.15)}
.activity-log-summary-empty{font-size:12px;color:var(--text3);font-style:italic}
.activity-log-summary-chip.mod-incidents{color:#fecaca;border-color:rgba(248,113,113,.35)}
.activity-log-summary-chip.mod-actions{color:#fde68a;border-color:rgba(251,191,36,.35)}
.activity-log-summary-chip.mod-audits{color:#bae6fd;border-color:rgba(125,211,252,.35)}
.activity-log-summary-chip.mod-iso{color:#ddd6fe;border-color:rgba(167,139,250,.35)}
.activity-log-summary-chip.mod-products{color:#c4b5fd;border-color:rgba(167,139,250,.25)}
.activity-log-summary-chip.mod-context{color:#cbd5e1;border-color:rgba(148,163,184,.3)}
.activity-log-summary-chip.mod-ai-center{color:#a7f3d0;border-color:rgba(52,211,153,.35)}
.activity-log-summary-chip.mod-system{color:#e2e8f0;border-color:rgba(203,213,225,.25)}
.activity-log-summary-chip.mod-default{color:var(--text2)}

.activity-log-table{margin-top:4px;border-radius:14px;border:1px solid rgba(148,163,184,.12);overflow:hidden}
.activity-log-head,.activity-log-row{display:grid;grid-template-columns:minmax(112px,1fr) minmax(130px,1.15fr) minmax(160px,1.5fr) minmax(108px,1fr) minmax(104px,.95fr);gap:12px;padding:12px 16px;align-items:start;font-size:12px}
.activity-log-head{font-weight:800;letter-spacing:.06em;text-transform:uppercase;color:var(--text3);background:rgba(0,0,0,.22);border-bottom:1px solid rgba(148,163,184,.18)}
.activity-log-row{border-bottom:1px solid rgba(148,163,184,.08);position:relative}
.activity-log-row:last-child{border-bottom:none}
.activity-log-row:nth-child(even){background:rgba(255,255,255,.025)}
.activity-log-row--emphasis{background:rgba(77,160,255,.04)!important;border-left:3px solid rgba(77,160,255,.45);padding-left:13px;margin-left:0}
.activity-log-cell{display:flex;flex-direction:column;gap:6px;min-width:0}
.activity-log-module-badge{display:inline-flex;flex-direction:column;align-items:flex-start;gap:2px;padding:8px 10px;border-radius:12px;border:1px solid rgba(148,163,184,.15);background:rgba(0,0,0,.12);max-width:100%}
.activity-log-module-short{font-size:13px;font-weight:800;letter-spacing:.06em}
.activity-log-module-full{font-size:10px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:var(--text3);line-height:1.2}
.mod-incidents .activity-log-module-short{color:#f87171}
.mod-actions .activity-log-module-short{color:#fbbf24}
.mod-audits .activity-log-module-short{color:#7dd3fc}
.mod-iso .activity-log-module-short{color:#a78bfa}
.mod-products .activity-log-module-short{color:#c4b5fd}
.mod-context .activity-log-module-short{color:#94a3b8}
.mod-ai-center .activity-log-module-short{color:#34d399}
.mod-system .activity-log-module-short{color:#cbd5e1}
.mod-default .activity-log-module-short{color:var(--text2)}
.activity-log-action-wrap{display:flex;flex-wrap:wrap;align-items:center;gap:8px}
.activity-log-cell--action .activity-log-strong{font-weight:700;font-size:13px;color:var(--text);line-height:1.4}
.activity-log-importance{font-size:10px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;padding:3px 8px;border-radius:999px;background:rgba(77,160,255,.12);color:#93c5fd;border:1px solid rgba(77,160,255,.25)}
.activity-log-cell--detail .activity-log-detail-text{font-size:12px;line-height:1.5;color:var(--text2)}
.activity-log-meta{font-size:12px;font-weight:600;color:var(--text)}
.activity-log-time{font-size:12px;color:var(--text2);font-variant-numeric:tabular-nums;font-weight:600}

.activity-log-extension-slot{margin-top:14px;padding:10px 12px;border-radius:12px;border:1px dashed rgba(148,163,184,.2);background:rgba(0,0,0,.08);display:flex;flex-wrap:wrap;gap:8px 14px;align-items:baseline}
.activity-log-extension-label{font-size:10px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--text3)}
.activity-log-extension-text{font-size:12px;color:var(--text3);line-height:1.45;max-width:62ch}

@media (max-width:900px){
  .activity-log-head{display:none}
  .activity-log-row{grid-template-columns:1fr;gap:10px;padding:16px;border-bottom:1px solid rgba(148,163,184,.1)}
  .activity-log-cell--module::before{content:'Module';font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--text3)}
  .activity-log-cell--action::before{content:'Action';font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--text3)}
  .activity-log-cell--detail::before{content:'Détail';font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--text3)}
  .activity-log-cell--user::before{content:'Utilisateur';font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--text3)}
  .activity-log-cell--time::before{content:'Date / heure';font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--text3)}
}
`;

export function ensureActivityLogStyles() {
  if (document.getElementById(STYLE_ID)) return;
  const el = document.createElement('style');
  el.id = STYLE_ID;
  el.textContent = CSS;
  document.head.append(el);
}
