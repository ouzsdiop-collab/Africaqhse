const STYLE_ID = 'qhse-dashboard-module-styles';

const CSS = `
/* —— Hiérarchie direction : CEO → priorités → cockpit (pression) → analyse → activité —— */
.dashboard-page.page-stack{gap:20px}
.dashboard-band{display:flex;flex-direction:column;gap:20px;min-width:0}
.dashboard-band--ceo{
  margin:0 0 2px;
  padding:0;
  border-radius:var(--ds-radius-lg,22px);
  overflow:hidden;
}
.dashboard-band--priority{
  padding:16px 16px 20px;
  margin:2px 0 4px;
  border-radius:var(--ds-radius-lg,20px);
  border:1px solid rgba(61,184,154,.16);
  background:linear-gradient(165deg,rgba(61,184,154,.07) 0%,rgba(18,24,32,.42) 48%,rgba(12,16,22,.28) 100%);
  box-shadow:0 6px 32px rgba(0,0,0,.14);
}
.dashboard-band--cockpit{
  padding:20px 18px 24px;
  margin:4px 0 6px;
  border-radius:var(--ds-radius-lg,20px);
  background:linear-gradient(165deg,rgba(82,148,247,.08) 0%,rgba(18,24,36,.52) 40%,rgba(12,16,24,.32) 100%);
  border:1px solid rgba(82,148,247,.14);
  box-shadow:0 8px 44px rgba(0,0,0,.2),0 0 0 1px rgba(255,255,255,.035) inset;
}
.dashboard-band--alerts{
  padding:18px 16px 22px;
  margin:4px 0 8px;
  border-radius:var(--ds-radius-lg,20px);
  border:1px solid rgba(239,91,107,.14);
  background:linear-gradient(165deg,rgba(239,91,107,.05) 0%,rgba(18,22,30,.5) 55%,rgba(12,16,22,.35) 100%);
  box-shadow:0 6px 40px rgba(0,0,0,.18);
}
.dashboard-band--cockpit .dashboard-alerts-prio-card{
  border-color:rgba(232,93,108,.2);
  box-shadow:0 12px 44px rgba(0,0,0,.22),0 0 0 1px rgba(239,91,107,.08);
}
.dashboard-band--analysis{
  padding:8px 2px 12px;
  gap:20px;
  opacity:.985;
}
.dashboard-band--analysis .dashboard-section-title{
  font-size:clamp(16px,1.5vw,19px);
}
.dashboard-band--actions{
  padding:18px 16px 22px;
  margin:6px 0 4px;
  border-radius:var(--ds-radius-lg,20px);
  border:1px solid rgba(61,184,154,.14);
  background:linear-gradient(165deg,rgba(61,184,154,.06) 0%,rgba(18,24,32,.45) 50%,transparent 100%);
  box-shadow:0 6px 36px rgba(0,0,0,.16);
}
.dashboard-band--situation{
  padding:22px 18px 26px;
  margin:2px 0 6px;
  border-radius:var(--ds-radius-lg,20px);
  background:linear-gradient(165deg,rgba(82,148,247,.09) 0%,rgba(18,24,36,.55) 42%,rgba(12,16,24,.35) 100%);
  border:1px solid rgba(82,148,247,.16);
  box-shadow:0 8px 48px rgba(0,0,0,.22),0 0 0 1px rgba(255,255,255,.04) inset,0 1px 0 rgba(255,255,255,.06) inset;
}
.dashboard-band--secondary{
  padding:4px 2px 8px;
  gap:22px;
}
.dashboard-band--tertiary{
  padding:20px 14px 10px;
  margin-top:6px;
  border-radius:var(--ds-radius-lg,20px);
  border:1px solid rgba(148,163,184,.1);
  background:linear-gradient(180deg,rgba(255,255,255,.02) 0%,rgba(0,0,0,.06) 100%);
  box-shadow:0 -1px 0 rgba(255,255,255,.03) inset;
}
.dashboard-band--tertiary .dashboard-section-head{margin-bottom:12px}
.dashboard-band--tertiary .dashboard-section-kicker{opacity:.88}
.dashboard-band--tertiary .dashboard-section-title{font-size:clamp(17px,1.65vw,21px);letter-spacing:-.02em}
.dashboard-band--tertiary .dashboard-section-sub{font-size:12px;max-width:60ch}
/* Bloc principal direction / CEO */
.dashboard-ceo-hero{
  position:relative;
  overflow:hidden;
  margin:0;
  padding:22px 22px 26px;
  border-radius:var(--ds-radius-lg,22px);
  border:1px solid rgba(82,148,247,.28);
  background:linear-gradient(128deg,rgba(18,26,42,.98) 0%,rgba(14,20,34,.97) 38%,rgba(28,40,64,.94) 100%);
  box-shadow:0 16px 64px rgba(0,0,0,.35),0 0 0 1px rgba(255,255,255,.06) inset,0 1px 0 rgba(255,255,255,.09) inset;
}
.dashboard-ceo-hero::before{
  content:"";
  position:absolute;
  inset:0;
  pointer-events:none;
  background:radial-gradient(ellipse 85% 65% at 88% -15%,rgba(82,148,247,.28),transparent 52%),
    radial-gradient(ellipse 55% 45% at 4% 102%,rgba(61,184,154,.12),transparent 48%);
}
.dashboard-ceo-hero__topbar{
  position:relative;
  z-index:1;
  display:flex;
  flex-wrap:wrap;
  align-items:center;
  justify-content:space-between;
  gap:12px 16px;
  margin-bottom:18px;
}
.dashboard-ceo-hero__site{
  font-size:11px;
  font-weight:800;
  letter-spacing:.12em;
  text-transform:uppercase;
  color:rgba(186,210,255,.88);
}
.dashboard-ceo-hero__body{
  position:relative;
  z-index:1;
  display:grid;
  grid-template-columns:minmax(0,280px) minmax(0,1fr);
  gap:28px 36px;
  align-items:center;
}
@media (max-width:900px){
  .dashboard-ceo-hero__body{grid-template-columns:1fr;text-align:center}
  .dashboard-ceo-hero__text{text-align:left}
  .dashboard-ceo-hero__visual{margin:0 auto}
}
.dashboard-ceo-hero__visual{
  position:relative;
  display:flex;
  flex-direction:column;
  align-items:center;
  justify-content:center;
  padding:18px 14px 14px;
  border-radius:20px;
  border:1px solid rgba(148,163,184,.14);
  background:linear-gradient(165deg,rgba(0,0,0,.22) 0%,rgba(255,255,255,.04) 100%);
  box-shadow:0 8px 40px rgba(0,0,0,.2) inset,0 4px 24px rgba(0,0,0,.12);
  max-width:280px;
  width:100%;
  margin:0 auto;
}
.dashboard-ceo-hero__visual--ok{border-color:rgba(52,211,153,.22);box-shadow:0 0 0 1px rgba(52,211,153,.08),0 8px 40px rgba(0,0,0,.18) inset}
.dashboard-ceo-hero__visual--watch{border-color:rgba(251,191,36,.24)}
.dashboard-ceo-hero__visual--risk{border-color:rgba(248,113,113,.28)}
.dashboard-ceo-hero__status{
  position:absolute;
  top:14px;
  right:14px;
  font-size:10px;
  font-weight:800;
  letter-spacing:.1em;
  text-transform:uppercase;
  padding:6px 10px;
  border-radius:999px;
  border:1px solid rgba(148,163,184,.2);
  background:rgba(0,0,0,.25);
  color:var(--text2);
}
.dashboard-ceo-hero__status--ok{border-color:rgba(52,211,153,.45);color:#6ee7b7;background:rgba(52,211,153,.1)}
.dashboard-ceo-hero__status--watch{border-color:rgba(251,191,36,.5);color:#fde68a;background:rgba(245,158,11,.12)}
.dashboard-ceo-hero__status--risk{border-color:rgba(248,113,113,.55);color:#fecaca;background:rgba(239,91,107,.12)}
.dashboard-ceo-hero__ring-wrap{display:flex;justify-content:center;margin:4px 0 0;min-height:112px}
.dashboard-ceo-hero__svg{display:block;width:100%;max-width:200px;height:auto}
.dashboard-ceo-hero__scorenum{
  margin:6px 0 0;
  font-size:clamp(44px,6vw,56px);
  font-weight:800;
  letter-spacing:-.05em;
  line-height:1;
  font-variant-numeric:tabular-nums;
  color:var(--text);
  text-shadow:0 2px 28px rgba(0,0,0,.35);
}
.dashboard-ceo-hero__scorecaption{margin:10px 0 4px;font-size:13px;font-weight:700;line-height:1.35;color:var(--text);text-align:center;max-width:22ch}
.dashboard-ceo-hero__scorehint{margin:0;font-size:11px;line-height:1.4;color:var(--text3);text-align:center;max-width:26ch}
.dashboard-ceo-hero__text{min-width:0}
.dashboard-ceo-hero__eyebrow{margin:0 0 8px;font-size:10px;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:rgba(125,180,255,.9)}
.dashboard-ceo-hero__title{margin:0 0 14px;font-size:clamp(22px,2.4vw,30px);font-weight:800;letter-spacing:-.035em;line-height:1.15;color:var(--text)}
.dashboard-ceo-hero__brief{margin:0 0 16px;font-size:15px;line-height:1.6;font-weight:500;color:var(--text2);max-width:62ch}
.dashboard-ceo-hero__legal-wrap{margin:12px 0 0;max-width:62ch;border-radius:12px;border:1px solid rgba(148,163,184,.1);background:rgba(0,0,0,.12);padding:8px 12px 10px}
.dashboard-ceo-hero__legal-summary{
  cursor:pointer;
  font-size:11px;
  font-weight:700;
  color:var(--text3);
  list-style:none;
  user-select:none;
  line-height:1.4;
}
.dashboard-ceo-hero__legal-summary::-webkit-details-marker{display:none}
.dashboard-ceo-hero__legal-wrap[open] .dashboard-ceo-hero__legal-summary{color:var(--text2)}
.dashboard-ceo-hero__legal{margin:10px 0 0;font-size:11px;line-height:1.45;color:var(--text3);max-width:58ch;opacity:.95}
.dashboard-chart-interpret{
  margin:10px 0 0;
  padding:10px 12px;
  border-radius:var(--ds-radius-sm,10px);
  border-left:3px solid rgba(82,148,247,.55);
  background:rgba(82,148,247,.07);
  font-size:12px;
  line-height:1.5;
  font-weight:600;
  color:var(--text2);
}
.dashboard-priority-now__footer{
  margin-top:16px;
  padding-top:14px;
  border-top:1px dashed rgba(148,163,184,.2);
  display:flex;
  justify-content:flex-start;
}
.dashboard-priority-now__cta{
  min-height:44px!important;
  padding:0 22px!important;
  font-weight:800!important;
  letter-spacing:.02em!important;
}
/* Hero classique (autres pages) : relief + lecture */
.hero.dashboard-hero{
  position:relative;
  overflow:hidden;
  border:1px solid rgba(82,148,247,.2);
  background:linear-gradient(125deg,rgba(24,32,48,.98) 0%,rgba(16,22,34,.95) 45%,rgba(30,42,62,.92) 100%);
  box-shadow:0 12px 48px rgba(0,0,0,.24),0 0 0 1px rgba(255,255,255,.05) inset;
}
.hero.dashboard-hero::before{
  content:"";
  position:absolute;
  inset:0;
  pointer-events:none;
  background:radial-gradient(ellipse 90% 70% at 92% -10%,rgba(82,148,247,.2),transparent 50%),
    radial-gradient(ellipse 60% 50% at 0% 100%,rgba(61,184,154,.08),transparent 45%);
}
.dashboard-hero__shell{position:relative;z-index:1}
.dashboard-hero__title{text-shadow:0 1px 24px rgba(0,0,0,.25)}
.dashboard-hero__lead--primary{font-size:clamp(14px,1.35vw,16px);font-weight:600;color:var(--text);max-width:62ch}
.dashboard-hero__lead--secondary{opacity:.92}
.dashboard-hero__cta--featured{
  min-height:46px!important;
  padding:0 24px!important;
  font-size:14px!important;
  font-weight:800!important;
  letter-spacing:.02em;
  border-color:rgba(120,180,255,.45)!important;
  box-shadow:0 6px 28px rgba(82,148,247,.38),0 1px 0 rgba(255,255,255,.12) inset!important;
  transition:transform .18s ease,box-shadow .18s ease!important;
}
@media (prefers-reduced-motion:no-preference){
  .dashboard-hero__cta--featured:hover{
    transform:translateY(-2px);
    box-shadow:0 10px 36px rgba(82,148,247,.48),0 1px 0 rgba(255,255,255,.14) inset!important;
  }
}
.dashboard-hero .dashboard-block-link{
  min-height:38px;
  padding:8px 14px;
  font-weight:700;
  border-radius:10px;
}
/* Raccourcis : tuile principale */
.dashboard-shortcuts__tile--featured{
  border-color:rgba(239,91,107,.35)!important;
  background:linear-gradient(145deg,rgba(239,91,107,.12),rgba(255,255,255,.04))!important;
  box-shadow:0 4px 24px rgba(239,91,107,.15),0 1px 0 rgba(255,255,255,.05) inset;
}
.dashboard-shortcuts__tile--featured .dashboard-shortcuts__tile-label{font-size:14px;font-weight:800}
@media (prefers-reduced-motion:no-preference){
  .dashboard-shortcuts__tile--featured:hover{
    border-color:rgba(239,91,107,.5)!important;
    box-shadow:0 8px 32px rgba(239,91,107,.22);
  }
}
/* KPI cartes */
.dashboard-kpi-card{
  border:1px solid rgba(148,163,184,.14);
  background:linear-gradient(165deg,rgba(255,255,255,.05) 0%,rgba(255,255,255,.02) 100%);
  box-shadow:0 4px 20px rgba(0,0,0,.1),0 1px 0 rgba(255,255,255,.04) inset;
  transition:border-color .2s ease,box-shadow .2s ease,transform .15s ease;
}
@media (prefers-reduced-motion:no-preference){
  .dashboard-kpi-card:hover{
    border-color:rgba(82,148,247,.22);
    box-shadow:0 8px 28px rgba(0,0,0,.14);
    transform:translateY(-1px);
  }
}
.dashboard-connectivity-slot{display:flex;justify-content:center;padding:8px 16px 4px;width:100%;box-sizing:border-box}
.dashboard-connectivity-card{max-width:560px;width:100%;margin:0 auto;padding:18px 20px;border:1px solid rgba(243,179,79,.5);background:linear-gradient(165deg,rgba(243,179,79,.08),rgba(20,28,40,.5));box-shadow:0 8px 32px rgba(0,0,0,.2)}
.dashboard-connectivity-title{margin:0 0 10px;font-size:17px;font-weight:800;letter-spacing:-.02em;line-height:1.2;color:var(--text);text-align:center}
.dashboard-connectivity-lead{margin:0 0 14px;font-size:13px;line-height:1.5;color:var(--text2);text-align:center;max-width:48ch;margin-left:auto;margin-right:auto}
.dashboard-connectivity-api-label{margin:0 0 6px;font-size:10px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--text3);text-align:center}
.dashboard-connectivity-code{display:block;margin:0 auto 12px;padding:10px 12px;border-radius:var(--ds-radius-sm,10px);border:1px solid rgba(148,163,184,.2);background:rgba(0,0,0,.2);font-size:12px;font-weight:600;color:var(--accent-blue,#7dd3fc);text-align:center;word-break:break-all;max-width:100%;box-sizing:border-box}
.dashboard-connectivity-urlhint{margin:0 auto 12px;font-size:12px;line-height:1.45;color:var(--text2);text-align:center;max-width:48ch}
.dashboard-connectivity-filewarn{margin:0 auto 12px;padding:10px 12px;border-radius:var(--ds-radius-sm,10px);border:1px solid rgba(248,113,113,.4);background:rgba(248,113,113,.08);font-size:12px;font-weight:600;line-height:1.4;color:#fecaca;text-align:center;max-width:46ch}
.dashboard-connectivity-actions{display:flex;justify-content:center;margin:0 0 16px}
.dashboard-connectivity-retry{font-size:13px!important;padding:10px 18px!important}
.dashboard-connectivity-steps{margin:0;padding:0 0 0 22px;font-size:12px;line-height:1.55;color:var(--text2);max-width:52ch;margin-left:auto;margin-right:auto}
.dashboard-connectivity-steps li{margin-bottom:8px}
.dashboard-connectivity-steps li:last-child{margin-bottom:0}
.dashboard-section{display:flex;flex-direction:column;gap:12px;margin:0;padding:0 0 6px}
.dashboard-section--charts{gap:8px}
.dashboard-hero__actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:0;align-items:center}
.dashboard-hero__actions .dashboard-block-actions--hero{margin-left:auto}
@media (max-width:520px){.dashboard-hero__actions .dashboard-block-actions--hero{margin-left:0}}
.dashboard-left-stack{display:grid;gap:16px;min-width:0}
.dashboard-muted-lead{margin:6px 0 0;font-size:13px;line-height:1.45;color:var(--text2);max-width:52ch}
.dashboard-kpi-grid{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:12px}
.dashboard-charts-disclaimer{margin:0;padding:10px 14px;border-radius:var(--ds-radius-sm,12px);border:1px solid rgba(82,148,247,.22);background:linear-gradient(90deg,rgba(82,148,247,.1),rgba(82,148,247,.04));font-size:12px;line-height:1.5;color:var(--text2);max-width:100%;box-shadow:0 2px 12px rgba(82,148,247,.08)}
.dashboard-charts-global-actions{margin:4px 0 0;padding:0 2px 2px}
.dashboard-charts-global-actions .dashboard-block-actions{margin-top:8px;padding-top:10px;border-top:1px dashed rgba(148,163,184,.16)}
.dashboard-charts-disclaimer strong{color:var(--text);font-weight:700}
.dashboard-charts-disclaimer code{font-size:11px;font-weight:600;color:var(--accent-blue, #7dd3fc);word-break:break-all}
.dashboard-charts-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;align-items:stretch}
.dashboard-chart-card-head.content-card-head{margin-bottom:10px}
.content-card .dashboard-chart-h{margin:0 0 2px;font-size:16px;font-weight:800;letter-spacing:-.02em;line-height:1.25}
.dashboard-chart-lead{margin-top:4px;font-size:12px;line-height:1.35;max-width:none}
.dashboard-chart-card-inner{
  min-height:0;
  border:1px solid rgba(148,163,184,.14);
  background:linear-gradient(165deg,rgba(255,255,255,.045) 0%,rgba(255,255,255,.015) 55%,rgba(0,0,0,.04) 100%);
  box-shadow:0 6px 32px rgba(0,0,0,.14),0 1px 0 rgba(255,255,255,.04) inset;
}
.dashboard-band--analysis .dashboard-chart-card-inner:hover{
  border-color:rgba(82,148,247,.2);
  box-shadow:0 10px 40px rgba(0,0,0,.16);
}
.dashboard-line-chart-wrap{display:flex;flex-direction:column;gap:8px;width:100%}
.dashboard-line-chart-svg{width:100%;height:auto;max-height:200px;display:block;filter:drop-shadow(0 2px 12px rgba(82,148,247,.12))}
.dashboard-line-chart-grid{stroke:var(--ds-chart-grid, rgba(148,163,184,.18));stroke-width:1}
.dashboard-line-chart-grid--base{stroke:var(--ds-chart-grid, rgba(148,163,184,.22));stroke-width:1.25}
.dashboard-line-chart-grid--mid{stroke:rgba(148,163,184,.1);stroke-width:1;stroke-dasharray:4 4}
.dashboard-line-chart-area{fill:var(--ds-chart-fill-primary, rgba(82,148,247,.24))}
.dashboard-line-chart-line{stroke:var(--ds-chart-line-primary, rgba(96,165,250,.98));stroke-width:2.75;stroke-linecap:round;stroke-linejoin:round;filter:drop-shadow(0 1px 4px rgba(82,148,247,.35))}
.dashboard-line-chart-dot{fill:var(--ds-surface-1, #141c28);stroke:var(--ds-chart-line-primary, rgba(120,190,255,1));stroke-width:2.5;filter:drop-shadow(0 1px 3px rgba(0,0,0,.35))}
.dashboard-line-chart-values{display:flex;justify-content:space-between;gap:6px;font-size:13px;font-weight:800;color:var(--text);font-variant-numeric:tabular-nums;padding:4px 4px 0}
.dashboard-line-chart-labels{display:flex;justify-content:space-between;gap:6px;font-size:11px;font-weight:700;color:var(--text2);text-transform:capitalize;padding:0 4px 2px}
.dashboard-mix-foot{margin-top:4px}
.dashboard-chart-foot--tight{margin-top:8px}
.dashboard-mix-chart-wrap{display:flex;flex-direction:column;gap:10px}
.dashboard-mix-bar{display:flex;height:18px;border-radius:999px;overflow:hidden;background:rgba(255,255,255,.05);border:1px solid var(--ds-border-subtle, rgba(148,163,184,.14));box-shadow:0 2px 12px rgba(0,0,0,.12) inset}
.dashboard-mix-seg{min-width:4px;transition:flex .2s ease}
.dashboard-mix-seg--overdue{background:linear-gradient(90deg, rgba(232,93,108,.95), rgba(243,179,79,.75))}
.dashboard-mix-seg--done{background:linear-gradient(90deg, rgba(66,199,140,.88), rgba(61,184,154,.65))}
.dashboard-mix-seg--other{background:rgba(82,148,247,.35)}
.dashboard-mix-legend{list-style:none;margin:0;padding:0;display:grid;gap:6px;font-size:12px;color:var(--text2)}
.dashboard-mix-legend-item{display:flex;align-items:center;gap:8px}
.dashboard-mix-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0}
.dashboard-mix-dot--overdue{background:rgba(232,93,108,.9)}
.dashboard-mix-dot--done{background:rgba(66,199,140,.88)}
.dashboard-mix-dot--other{background:rgba(82,148,247,.65)}
.dashboard-breakdown-wrap{display:flex;flex-direction:column;gap:10px}
.dashboard-breakdown-row{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,2.2fr) auto;gap:10px;align-items:center;font-size:12px}
.dashboard-breakdown-label{color:var(--text2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dashboard-breakdown-track{height:10px;border-radius:999px;background:rgba(255,255,255,.07);overflow:hidden;border:1px solid rgba(148,163,184,.08)}
.dashboard-breakdown-fill{height:100%;border-radius:999px;background:linear-gradient(90deg, rgba(82,148,247,.65), rgba(61,184,154,.62));min-width:4px;box-shadow:0 0 12px rgba(82,148,247,.2)}
.dashboard-breakdown-count{font-weight:700;color:var(--text);font-variant-numeric:tabular-nums;min-width:1.5em;text-align:right}
.dashboard-priority-heading--nc .dashboard-priority-dot{background:rgba(229,184,77,.95);box-shadow:0 0 0 2px rgba(229,184,77,.22)}
.dashboard-priority-row--nc{border-left-color:rgba(229,184,77,.55);background:rgba(229,184,77,.06)}
.dashboard-alerts-panel{margin-top:0}
.dashboard-alerts-card{padding:16px 18px}
.dashboard-alerts-host{min-height:0}
.dashboard-activity-wrap{margin:0}
.dashboard-activity-section.content-card{margin-top:0;border-radius:var(--ds-radius-md,14px);box-shadow:0 4px 28px rgba(0,0,0,.12);border:1px solid rgba(148,163,184,.12)}
.dashboard-activity-section--body{box-shadow:0 4px 28px rgba(0,0,0,.12)}
.dashboard-activity-head.content-card-head{margin-bottom:14px;padding-bottom:4px}
.dashboard-activity-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:18px 20px;align-items:start}
.dashboard-activity-col{display:flex;flex-direction:column;gap:10px;min-width:0;border-left:1px solid var(--ds-border-subtle, rgba(148,163,184,.14));padding-left:18px}
.dashboard-activity-col:first-child{border-left:none;padding-left:0}
.dashboard-activity-col-title{margin:0 0 4px;font-size:10px;font-weight:800;letter-spacing:.12em;text-transform:uppercase;color:var(--accent-blue)}
.dashboard-activity-stack{display:flex;flex-direction:column;gap:8px;min-height:0}
.dashboard-activity-col-empty{margin:0;padding:10px 0;font-size:12px;line-height:1.45;color:var(--text3);font-style:italic}
.dashboard-activity-global-empty{padding:22px 18px;text-align:center;border-radius:var(--ds-radius-md, 14px);border:1px dashed rgba(148,163,184,.2);background:rgba(255,255,255,.03)}
.dashboard-activity-global-empty-msg{margin:0 0 8px;font-size:15px;font-weight:800;line-height:1.35;color:var(--text);letter-spacing:-.02em}
.dashboard-activity-global-empty-sub{margin:0 auto 16px;max-width:48ch;font-size:12px;line-height:1.5;color:var(--text2);font-weight:500}
.dashboard-activity-item{display:flex;flex-direction:column;gap:6px;padding:12px 14px;border-radius:var(--ds-radius-sm, 12px);background:rgba(255,255,255,.04);border:1px solid rgba(148,163,184,.11);min-width:0;text-align:left}
.dashboard-activity-item--link{cursor:pointer;transition:background .15s ease,border-color .15s ease,box-shadow .15s ease,transform .12s ease}
.dashboard-activity-item--link:hover,.dashboard-activity-item--link:focus{background:rgba(82,148,247,.09);border-color:rgba(82,148,247,.26);outline:none;transform:translateY(-1px)}
.dashboard-activity-item--link:focus-visible{box-shadow:var(--ds-shadow-focus, 0 0 0 3px rgba(82,148,247,.22))}
.dashboard-activity-item__head{margin:0 0 2px}
.dashboard-activity-item__kind{font-size:9px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--accent-blue)}
.dashboard-activity-item__top{display:flex;align-items:flex-start;justify-content:space-between;gap:8px;min-width:0}
.dashboard-activity-item__title{font-size:13px;font-weight:800;letter-spacing:-.02em;line-height:1.3;color:var(--text);flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}
.dashboard-activity-item__badge{flex-shrink:0;font-size:9px!important;padding:3px 8px!important;line-height:1.2;max-width:42%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dashboard-activity-item__ctx{margin:0;font-size:12px;line-height:1.45;color:var(--text2);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.dashboard-activity-item__status-row{display:flex;align-items:baseline;gap:10px;padding:8px 0;margin:2px 0 0;border-top:1px solid rgba(148,163,184,.1);border-bottom:1px solid rgba(148,163,184,.06)}
.dashboard-activity-item__status-k{font-size:9px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--text3);flex-shrink:0}
.dashboard-activity-item__status-v{font-size:12px;font-weight:600;color:var(--text);line-height:1.3;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dashboard-activity-item__foot{display:flex;flex-wrap:wrap;align-items:baseline;justify-content:space-between;gap:6px 10px;margin-top:4px;padding-top:8px}
.dashboard-activity-item__date{font-size:11px;font-weight:800;color:var(--text3);font-variant-numeric:tabular-nums}
.dashboard-activity-item__hint{font-size:11px;font-weight:700;color:var(--accent-blue);max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dashboard-chart-card .bar-chart{margin-top:4px}
.dashboard-bar-chart-wrap{display:flex;flex-direction:column;gap:0}
.dashboard-bar-chart--dashboard{display:grid;grid-template-columns:repeat(6,1fr);align-items:end;gap:10px;height:176px;padding-top:8px}
.dashboard-bar{position:relative;border-radius:14px 14px 10px 10px;background:linear-gradient(180deg,rgba(77,160,255,.88),rgba(34,196,131,.72));height:var(--bar-h,45%);min-height:12px;box-shadow:0 8px 20px rgba(0,0,0,.12)}
.dashboard-bar span{position:absolute;left:50%;transform:translateX(-50%);bottom:-24px;font-size:11px;font-weight:600;color:var(--text3);white-space:nowrap}
.dashboard-chart-axis{margin:0 0 4px;font-size:10px;font-weight:800;letter-spacing:.12em;text-transform:uppercase;color:var(--text3)}
.dashboard-chart-foot{margin-top:26px;font-size:12px;color:var(--text3);line-height:1.45;max-width:62ch}
.dashboard-situation-wrap{display:flex;flex-direction:column;gap:12px}
.dashboard-situation-list{list-style:none;margin:0;padding:0;display:grid;gap:0}
.dashboard-situation-item{display:flex;justify-content:space-between;align-items:baseline;gap:16px;padding:10px 0;border-bottom:1px solid rgba(255,255,255,.06);font-size:13px;line-height:1.4}
.dashboard-situation-item:last-child{border-bottom:none;padding-bottom:0}
.dashboard-situation-k{color:var(--text3);font-size:11px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;flex-shrink:0}
.dashboard-situation-v{font-weight:700;color:var(--text);text-align:right}
.dashboard-situation-note{margin:0;font-size:12px;line-height:1.45;color:var(--text3)}
.dashboard-priority-stack{display:grid;gap:14px}
.dashboard-priority-block{padding:0}
.dashboard-priority-heading{display:flex;align-items:center;gap:8px;margin:0 0 10px;font-size:11px;font-weight:800;letter-spacing:.12em;text-transform:uppercase;color:var(--text)}
.dashboard-priority-heading--incidents,.dashboard-priority-heading--actions{color:var(--text)}
.dashboard-priority-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0}
.dashboard-priority-heading--incidents .dashboard-priority-dot{background:rgba(239,91,107,.85);box-shadow:0 0 0 2px rgba(239,91,107,.2)}
.dashboard-priority-heading--actions .dashboard-priority-dot{background:rgba(243,179,79,.9);box-shadow:0 0 0 2px rgba(243,179,79,.2)}
.dashboard-priority-list.stack{gap:8px}
.dashboard-priority-row.list-row{border-left-width:3px;border-left-style:solid}
.dashboard-priority-row--incident{border-left-color:rgba(239,91,107,.5);background:rgba(239,91,107,.04)}
.dashboard-priority-row--action{border-left-color:rgba(243,179,79,.5);background:rgba(243,179,79,.05)}
@media (max-width:1200px){.dashboard-kpi-grid{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media (max-width:900px){.dashboard-charts-grid{grid-template-columns:1fr}}
@media (max-width:1100px){.dashboard-kpi-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media (max-width:760px){.dashboard-kpi-grid{grid-template-columns:1fr}}
@media (max-width:900px){.dashboard-activity-grid{grid-template-columns:1fr}.dashboard-activity-col{border-left:none;padding-left:0;border-top:1px solid var(--ds-border-subtle, rgba(148,163,184,.1));padding-top:14px}.dashboard-activity-col:first-child{border-top:none;padding-top:0}}
.dashboard-cockpit{
  border-radius:var(--ds-radius-lg,20px);
  border:1px solid rgba(148,163,184,.18);
  background:linear-gradient(165deg, rgba(26,34,50,.98) 0%, rgba(16,22,32,.92) 48%, rgba(82,148,247,.07) 100%);
  box-shadow:0 10px 44px rgba(0,0,0,.2),0 0 0 1px rgba(255,255,255,.04) inset;
  padding:22px 24px 20px;
}
.dashboard-cockpit__inner{display:flex;flex-direction:column;gap:18px;min-width:0}
.dashboard-cockpit__head{margin:0;padding:0 0 2px}
.dashboard-cockpit__kicker{display:block;font-size:10px;font-weight:800;letter-spacing:.12em;text-transform:uppercase;color:var(--accent-blue);margin:0 0 6px}
.dashboard-cockpit__title{margin:0;font-size:clamp(20px,2.2vw,26px);font-weight:800;letter-spacing:-.03em;line-height:1.15;color:var(--text)}
.dashboard-cockpit__card{border-radius:var(--ds-radius-md,14px);border:1px solid rgba(148,163,184,.1);background:rgba(255,255,255,.025);padding:16px 18px;transition:transform .2s ease, box-shadow .2s ease, border-color .2s ease;box-shadow:0 1px 0 rgba(255,255,255,.04) inset}
.dashboard-cockpit__card:hover{border-color:rgba(148,163,184,.22);box-shadow:none}
.dashboard-cockpit__card--focus{border-color:rgba(82,148,247,.22);background:linear-gradient(135deg, rgba(82,148,247,.09) 0%, rgba(255,255,255,.02) 100%);box-shadow:0 0 0 1px rgba(82,148,247,.08), 0 8px 32px rgba(0,0,0,.1)}
.dashboard-cockpit__card--focus:hover{border-color:rgba(82,148,247,.3)}
.dashboard-cockpit__card--analytics{background:rgba(0,0,0,.12);border-color:rgba(148,163,184,.08)}
.dashboard-cockpit__card--complement{padding:14px 16px;background:rgba(255,255,255,.02);border-color:rgba(148,163,184,.08)}
.dashboard-cockpit__card-head{margin:0 0 14px}
.dashboard-cockpit__card-head--compact{margin:0 0 10px}
.dashboard-cockpit__card-kicker{display:block;font-size:10px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--text3);margin:0 0 4px}
.dashboard-cockpit__card-title{margin:0;font-size:13px;font-weight:700;letter-spacing:-.02em;color:var(--text)}
.dashboard-cockpit__card--complement .dashboard-cockpit__card-title{font-size:11px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--text2)}
.dashboard-cockpit__situation{margin:0}
.dashboard-cockpit__intro{margin:0;font-size:14px;line-height:1.45;font-weight:600;color:var(--text);max-width:58ch}
.dashboard-cockpit__micro{margin:10px 0 0;font-size:12px;line-height:1.4;font-weight:600;color:var(--accent-blue)}
.dashboard-cockpit__situation-actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:14px;padding-top:14px;border-top:1px solid rgba(148,163,184,.1)}
.dashboard-cockpit__pill{padding:8px 14px;border-radius:999px;border:1px solid rgba(148,163,184,.2);background:rgba(255,255,255,.04);color:var(--text);font-size:12px;font-weight:600;cursor:pointer;transition:background .18s ease, border-color .18s ease, transform .15s ease, color .15s ease}
.dashboard-cockpit__pill:hover{background:rgba(82,148,247,.12);border-color:rgba(82,148,247,.35);transform:translateY(-1px)}
.dashboard-cockpit__pill--emph{background:rgba(82,148,247,.16);border-color:rgba(82,148,247,.4);color:var(--text)}
.dashboard-cockpit__pill--emph:hover{background:rgba(82,148,247,.24);border-color:rgba(82,148,247,.5)}
.dashboard-cockpit__pill:focus-visible{outline:none;box-shadow:var(--ds-shadow-focus)}
.dashboard-cockpit__chart{padding:0;margin:0;border:none;background:transparent;box-shadow:none}
.dashboard-cockpit__bars{display:flex;flex-direction:column;gap:12px}
.dashboard-cockpit__bar-row{display:grid;grid-template-columns:minmax(112px,1.1fr) minmax(0,2fr) 44px;gap:14px;align-items:center;font-size:13px}
.dashboard-cockpit__bar-label{color:var(--text);font-weight:600;line-height:1.25}
.dashboard-cockpit__bar-track{height:12px;border-radius:999px;background:rgba(255,255,255,.06);overflow:hidden;border:1px solid rgba(255,255,255,.06)}
.dashboard-cockpit__bar-fill{height:100%;border-radius:999px;background:linear-gradient(90deg, rgba(82,148,247,.85), rgba(61,184,154,.75));width:0%;min-width:0;transition:width .4s cubic-bezier(.25,.8,.25,1)}
.dashboard-cockpit__bar-row:nth-child(2) .dashboard-cockpit__bar-fill{background:linear-gradient(90deg, rgba(229,184,77,.88), rgba(232,93,108,.55))}
.dashboard-cockpit__bar-row:nth-child(3) .dashboard-cockpit__bar-fill{background:linear-gradient(90deg, rgba(82,148,247,.65), rgba(124,92,220,.45))}
.dashboard-cockpit__bar-row:nth-child(4) .dashboard-cockpit__bar-fill{background:linear-gradient(90deg, rgba(66,199,140,.75), rgba(82,148,247,.5))}
.dashboard-cockpit__bar-val{font-weight:800;font-size:14px;font-variant-numeric:tabular-nums;color:var(--text);text-align:right}
.dashboard-cockpit__chart-read{margin:14px 0 0;font-size:12px;font-weight:600;line-height:1.45;color:var(--text2);max-width:68ch}
.dashboard-cockpit__chart-note{margin:6px 0 0;font-size:10px;line-height:1.35;color:var(--text3);max-width:62ch;opacity:.88}
.dashboard-cockpit__chart-actions{margin-top:12px;padding-top:12px;border-top:1px solid rgba(148,163,184,.08)}
.dashboard-cockpit__textlink{padding:0;border:none;background:none;color:var(--accent-blue);font-size:12px;font-weight:700;cursor:pointer;text-align:left;transition:opacity .15s ease, color .15s ease}
.dashboard-cockpit__textlink:hover{opacity:.88;color:rgba(120,170,255,1)}
.dashboard-cockpit__textlink:focus-visible{outline:none;box-shadow:var(--ds-shadow-focus);border-radius:4px}
.dashboard-cockpit__watch{min-height:0}
.dashboard-cockpit__watch-empty{margin:0;font-size:12px;line-height:1.45;color:var(--text2);font-weight:500;max-width:56ch}
.dashboard-cockpit__watch-list{margin:0;padding:0;list-style:none;display:flex;flex-direction:column;gap:6px}
.dashboard-cockpit__watch-item{width:100%;text-align:left;padding:8px 10px;margin:0;border-radius:var(--ds-radius-sm,10px);border:1px solid rgba(148,163,184,.08);background:rgba(255,255,255,.03);color:var(--text);font-size:12px;font-weight:600;line-height:1.3;cursor:pointer;transition:background .18s ease, border-color .18s ease, transform .12s ease}
.dashboard-cockpit__watch-item:hover{background:rgba(82,148,247,.1);border-color:rgba(82,148,247,.22);transform:translateX(2px)}
.dashboard-cockpit__watch-item:focus-visible{outline:none;box-shadow:var(--ds-shadow-focus)}
.dashboard-cockpit__mini-val{font-size:11px;font-weight:700;line-height:1.25;color:var(--text);max-height:2.75em;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;text-align:center;hyphens:auto}
.dashboard-cockpit__alert{display:flex;flex-direction:column;gap:0;padding:0;border-radius:var(--ds-radius-md,14px);border:1px solid transparent;cursor:pointer;transition:background .2s ease, border-color .2s ease, transform .18s ease, box-shadow .2s ease;box-shadow:0 4px 20px rgba(0,0,0,.1);overflow:hidden}
.dashboard-cockpit__alert:hover{transform:translateY(-2px);box-shadow:0 10px 32px rgba(0,0,0,.14)}
.dashboard-cockpit__alert:focus{outline:none}
.dashboard-cockpit__alert:focus-visible{box-shadow:var(--ds-shadow-focus, 0 0 0 3px rgba(82,148,247,.22)), 0 4px 20px rgba(0,0,0,.1)}
.dashboard-cockpit__alert-body{display:flex;flex-wrap:wrap;align-items:flex-start;gap:8px 16px;padding:15px 18px;text-align:left}
.dashboard-cockpit__alert-secondary{padding:0 18px 12px 18px;border-top:1px solid rgba(255,255,255,.06)}
.dashboard-cockpit__alert-link{padding:4px 0;border:none;background:none;color:var(--accent-blue);font-size:12px;font-weight:700;cursor:pointer;text-decoration:underline;text-underline-offset:3px}
.dashboard-cockpit__alert-link:hover{opacity:.9}
.dashboard-cockpit__alert--ok{background:rgba(66,199,140,.11);border-color:rgba(66,199,140,.25)}
.dashboard-cockpit__alert--ok:hover{background:rgba(66,199,140,.15)}
.dashboard-cockpit__alert--warn{background:rgba(243,179,79,.12);border-color:rgba(243,179,79,.3)}
.dashboard-cockpit__alert--warn:hover{background:rgba(243,179,79,.17)}
.dashboard-cockpit__alert--nc{background:rgba(229,184,77,.12);border-color:rgba(229,184,77,.32)}
.dashboard-cockpit__alert--nc:hover{background:rgba(229,184,77,.17)}
.dashboard-cockpit__alert--risk{background:rgba(232,93,108,.12);border-color:rgba(232,93,108,.3)}
.dashboard-cockpit__alert--risk:hover{background:rgba(232,93,108,.17)}
.dashboard-cockpit__alert-k{font-size:10px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--text3);width:100%;flex-basis:100%}
.dashboard-cockpit__alert-msg{flex:1;min-width:min(100%,200px);font-size:15px;font-weight:600;color:var(--text);line-height:1.35}
.dashboard-cockpit__alert-cta{font-size:12px;font-weight:700;color:var(--accent-blue);white-space:nowrap;align-self:center}
.dashboard-cockpit__minis{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}
.dashboard-cockpit__minis--support{opacity:.94}
.dashboard-cockpit__mini{padding:12px 10px;border-radius:var(--ds-radius-sm,12px);background:rgba(255,255,255,.03);border:1px solid rgba(148,163,184,.09);text-align:center;transition:background .18s ease, border-color .18s ease, transform .15s ease}
.dashboard-cockpit__mini:hover{background:rgba(255,255,255,.05);border-color:rgba(148,163,184,.14);transform:translateY(-1px)}
.dashboard-cockpit__mini-label{display:block;font-size:9px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--text3);margin-bottom:6px}
.dashboard-shortcuts .dashboard-section-sub{max-width:52ch}
.dashboard-shortcuts__grid{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:10px}
.dashboard-shortcuts__tile{display:flex;flex-direction:column;align-items:flex-start;text-align:left;gap:4px;padding:12px 14px;border-radius:var(--ds-radius-md,14px);border:1px solid rgba(148,163,184,.12);background:rgba(255,255,255,.03);color:var(--text);cursor:pointer;transition:background .2s ease, border-color .2s ease, transform .15s ease, box-shadow .2s ease;min-height:64px;box-shadow:0 1px 0 rgba(255,255,255,.03) inset}
.dashboard-shortcuts__tile:hover{background:rgba(255,255,255,.06);border-color:rgba(82,148,247,.28);transform:translateY(-2px);box-shadow:0 8px 24px rgba(0,0,0,.12)}
.dashboard-shortcuts__tile:focus-visible{outline:none;box-shadow:var(--ds-shadow-focus)}
.dashboard-shortcuts__tile-label{font-size:13px;font-weight:700;line-height:1.25;letter-spacing:-.01em}
.dashboard-shortcuts__tile-hint{font-size:10px;font-weight:600;color:var(--text3);line-height:1.3}
.dashboard-shortcuts__tile--incident:hover{border-color:rgba(239,91,107,.35)}
.dashboard-shortcuts__tile--action:hover{border-color:rgba(243,179,79,.35)}
.dashboard-shortcuts__tile--audit:hover,.dashboard-shortcuts__tile--nc:hover{border-color:rgba(77,160,255,.35)}
.dashboard-shortcuts__tile--import:hover{border-color:rgba(167,139,250,.3)}
.dashboard-shortcuts__tile--export:hover{border-color:rgba(66,199,140,.35)}
@media (max-width:1100px){.dashboard-shortcuts__grid{grid-template-columns:repeat(3,minmax(0,1fr))}}
.dashboard-alerts-prio-card{
  padding:18px 20px 16px;
  border-radius:var(--ds-radius-md,16px);
  box-shadow:0 10px 40px rgba(0,0,0,.2),0 0 0 1px rgba(255,255,255,.04) inset;
  border:1px solid rgba(148,163,184,.18);
  background:linear-gradient(165deg,rgba(28,36,52,.95) 0%,rgba(18,24,36,.9) 100%);
}
.dashboard-band--alerts .dashboard-alerts-prio-card{
  border-color:rgba(232,93,108,.2);
  box-shadow:0 12px 44px rgba(0,0,0,.22),0 0 0 1px rgba(239,91,107,.08);
}
.dashboard-executive-panel{
  margin-bottom:4px;
  border:1px solid rgba(82,148,247,.18);
  background:linear-gradient(145deg,rgba(255,255,255,.04) 0%,rgba(82,148,247,.05) 40%,rgba(0,0,0,.06) 100%);
  box-shadow:0 6px 32px rgba(0,0,0,.14),0 1px 0 rgba(255,255,255,.04) inset;
}
.dashboard-executive-panel__grid{
  display:grid;
  grid-template-columns:minmax(0,1fr) minmax(200px,248px);
  gap:26px 28px;
  align-items:start;
}
@media (max-width:960px){
  .dashboard-executive-panel__grid{grid-template-columns:1fr}
}
.dashboard-executive-panel__kicker{color:rgba(125,180,255,.95)}
.dashboard-executive-panel__title{
  margin:6px 0 14px;
  font-size:clamp(19px,1.9vw,23px);
  font-weight:800;
  letter-spacing:-.03em;
  line-height:1.2;
  color:var(--text);
}
.dashboard-executive-panel__brief{
  margin:0;
  font-size:14px;
  line-height:1.65;
  color:var(--text2);
  font-weight:500;
  max-width:64ch;
}
.dashboard-exec-score{
  text-align:center;
  padding:16px 14px 14px;
  border-radius:16px;
  border:1px solid rgba(148,163,184,.14);
  background:linear-gradient(165deg,rgba(0,0,0,.12) 0%,rgba(255,255,255,.03) 100%);
  position:relative;
}
.dashboard-exec-score__ring{
  display:flex;
  justify-content:center;
  margin:0 auto 4px;
  height:84px;
}
.dashboard-exec-score__svg{display:block;width:140px;height:84px}
.dashboard-exec-score__value{
  font-size:38px;
  font-weight:800;
  letter-spacing:-.04em;
  line-height:1;
  font-variant-numeric:tabular-nums;
  color:var(--text);
  margin-top:-6px;
}
.dashboard-exec-score__label{
  display:block;
  margin:8px 0 4px;
  font-size:12px;
  font-weight:700;
  line-height:1.35;
  color:var(--text);
  padding:0 6px;
}
.dashboard-exec-score__hint{
  margin:0 0 10px;
  font-size:11px;
  line-height:1.4;
  color:var(--text3);
  padding:0 8px;
}
.dashboard-exec-score__micro{
  margin:0;
  font-size:10px;
  line-height:1.35;
  color:var(--text3);
  opacity:.85;
  padding:10px 8px 0;
  border-top:1px solid rgba(148,163,184,.1);
}
.dashboard-exec-score--ok{border-color:rgba(52,211,153,.22)}
.dashboard-exec-score--watch{border-color:rgba(251,191,36,.22)}
.dashboard-exec-score--risk{border-color:rgba(248,113,113,.22)}
.dashboard-priority-now{
  border:1px solid rgba(148,163,184,.14);
  background:linear-gradient(165deg,rgba(255,255,255,.035) 0%,rgba(0,0,0,.05) 100%);
  box-shadow:0 4px 24px rgba(0,0,0,.1);
}
.dashboard-priority-now__head{margin-bottom:12px}
.dashboard-priority-now__summary{
  display:flex;
  flex-wrap:wrap;
  gap:10px 12px;
  align-items:stretch;
  margin:0 0 14px;
  padding:12px 14px;
  border-radius:14px;
  border:1px solid rgba(148,163,184,.12);
  background:rgba(0,0,0,.06);
}
.dashboard-priority-now__summary-more{
  flex:1 0 100%;
  margin:2px 0 0;
  font-size:11px;
  font-weight:600;
  line-height:1.4;
  color:var(--text3);
  max-width:56ch;
}
.dashboard-priority-now__pill{
  display:flex;
  flex-direction:column;
  gap:4px;
  min-width:0;
  flex:1 1 104px;
  max-width:200px;
  padding:10px 12px;
  border-radius:12px;
  border:1px solid rgba(148,163,184,.1);
  background:rgba(255,255,255,.035);
}
.dashboard-priority-now__pill-value{
  font-size:clamp(18px,2.2vw,22px);
  font-weight:800;
  font-variant-numeric:tabular-nums;
  line-height:1;
  color:var(--text);
  letter-spacing:-.02em;
}
.dashboard-priority-now__pill-label{
  font-size:9px;
  font-weight:800;
  letter-spacing:.07em;
  text-transform:uppercase;
  color:var(--text3);
  line-height:1.25;
}
.dashboard-priority-now__pill--urgent{border-color:rgba(248,113,113,.3);background:rgba(239,91,107,.09)}
.dashboard-priority-now__pill--delay{border-color:rgba(251,191,36,.32);background:rgba(245,158,11,.08)}
.dashboard-priority-now__pill--nc{border-color:rgba(167,139,250,.3);background:rgba(139,92,246,.08)}
.dashboard-priority-now__pill--calm{border-color:rgba(148,163,184,.1)}
.dashboard-priority-now__kicker{color:rgba(52,211,153,.9)}
.dashboard-priority-now__title{margin:6px 0 6px;font-size:clamp(17px,1.6vw,20px);font-weight:800;letter-spacing:-.02em}
.dashboard-priority-now__sub{margin:0;font-size:12px;line-height:1.45;color:var(--text3);max-width:52ch}
.dashboard-priority-now__list{display:flex;flex-direction:column;gap:8px}
.dashboard-priority-now__empty{margin:0;padding:16px 12px;text-align:center;font-size:13px;line-height:1.5;color:var(--text2);border-radius:12px;border:1px dashed rgba(148,163,184,.18);background:rgba(255,255,255,.02)}
.dashboard-priority-now__row{
  display:grid;
  grid-template-columns:auto minmax(0,1fr) auto;
  gap:12px 14px;
  align-items:center;
  width:100%;
  text-align:left;
  padding:12px 14px;
  border-radius:12px;
  border:1px solid rgba(148,163,184,.12);
  background:rgba(255,255,255,.04);
  color:var(--text);
  font-family:inherit;
  cursor:pointer;
  transition:background .18s ease,border-color .18s ease,transform .12s ease,box-shadow .18s ease;
}
@media (prefers-reduced-motion:no-preference){
  .dashboard-priority-now__row:hover{
    background:rgba(82,148,247,.08);
    border-color:rgba(82,148,247,.28);
    transform:translateY(-1px);
    box-shadow:0 6px 20px rgba(0,0,0,.1);
  }
}
.dashboard-priority-now__row--urgent{border-left:4px solid rgba(248,113,113,.75)}
.dashboard-priority-now__row--delay{border-left:4px solid rgba(251,191,36,.8)}
.dashboard-priority-now__row--nc{border-left:4px solid rgba(167,139,250,.75)}
.dashboard-priority-now__chip{
  font-size:9px;
  font-weight:800;
  letter-spacing:.08em;
  text-transform:uppercase;
  padding:5px 8px;
  border-radius:8px;
  border:1px solid rgba(148,163,184,.15);
  color:var(--text3);
  white-space:nowrap;
}
.dashboard-priority-now__main{display:flex;flex-direction:column;gap:3px;min-width:0}
.dashboard-priority-now__row-title{font-size:13px;font-weight:800;line-height:1.3;letter-spacing:-.02em}
.dashboard-priority-now__row-meta{font-size:11px;color:var(--text3);line-height:1.35}
.dashboard-priority-now__go{font-size:12px;font-weight:700;color:var(--accent-blue);white-space:nowrap}
.dashboard-alerts-prio-host{display:flex;flex-direction:column;gap:6px;min-height:0}
.dashboard-alerts-prio-tier-strip{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin:0 0 14px}
.dashboard-alerts-prio-tier-pill{padding:10px 8px;border-radius:12px;border:1px solid rgba(148,163,184,.12);background:rgba(255,255,255,.035);text-align:center;display:flex;flex-direction:column;gap:4px;min-width:0}
.dashboard-alerts-prio-tier-pill-label{font-size:9px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--text3)}
.dashboard-alerts-prio-tier-pill-sub{font-size:11px;font-weight:600;color:var(--text2);line-height:1.25}
.dashboard-alerts-prio-tier-pill--urgent-idle{opacity:.72}
.dashboard-alerts-prio-tier-pill--watch-idle{opacity:.72}
.dashboard-alerts-prio-tier-pill--normal-active{
  border-color:rgba(52,211,153,.45);
  background:linear-gradient(145deg,rgba(52,211,153,.16),rgba(52,211,153,.06));
  box-shadow:0 2px 14px rgba(52,211,153,.12);
}
.dashboard-alerts-prio-tier-pill--normal-active .dashboard-alerts-prio-tier-pill-sub{color:var(--text)}
.dashboard-alerts-prio-tier-pill--urgent-idle{border-color:rgba(239,91,107,.12)}
.dashboard-alerts-prio-tier-pill--watch-idle{border-color:rgba(245,158,11,.12)}
.dashboard-alerts-prio-normal--stable{padding:2px 0 0;text-align:left;max-width:100%}
.dashboard-alerts-prio-normal-msg{margin:0 0 6px;font-size:14px;font-weight:800;line-height:1.35;color:var(--text);letter-spacing:-.02em}
.dashboard-alerts-prio-normal-watch{margin:0 0 8px;font-size:12px;line-height:1.45;color:var(--text2);font-weight:500;max-width:56ch}
.dashboard-alerts-prio-normal-watch-k{font-weight:800;letter-spacing:.06em;text-transform:uppercase;font-size:9px;color:var(--text3);margin-right:4px}
.dashboard-alerts-prio-micro{margin:0 0 6px;font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--text3)}
.dashboard-alerts-prio-lane-head{display:flex;align-items:center;justify-content:space-between;padding:8px 11px;margin-top:12px;border-radius:10px;font-size:10px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;gap:10px}
.dashboard-alerts-prio-lane-head:first-of-type{margin-top:4px}
.dashboard-alerts-prio-lane-head--urgent{
  background:linear-gradient(90deg,rgba(239,91,107,.22),rgba(239,91,107,.08));
  border:1px solid rgba(248,113,113,.4);
  color:#fecaca;
  box-shadow:0 2px 12px rgba(239,91,107,.12);
}
.dashboard-alerts-prio-lane-head--watch{
  background:linear-gradient(90deg,rgba(245,158,11,.2),rgba(245,158,11,.07));
  border:1px solid rgba(251,191,36,.38);
  color:#fde68a;
  box-shadow:0 2px 12px rgba(245,158,11,.1);
}
.dashboard-alerts-prio-lane-title{flex:1;min-width:0}
.dashboard-alerts-prio-lane-count{font-variant-numeric:tabular-nums;opacity:.9;padding:2px 8px;border-radius:999px;background:rgba(0,0,0,.2);font-size:11px;font-weight:800}
.dashboard-alerts-prio-icon{font-size:15px;line-height:1;text-align:center;opacity:.92;user-select:none}
.dashboard-alerts-prio-row{display:grid;grid-template-columns:26px 72px minmax(0,1fr) auto;gap:8px 10px;align-items:center;width:100%;padding:11px 12px;border-radius:var(--ds-radius-sm,12px);border:1px solid rgba(148,163,184,.11);background:rgba(255,255,255,.035);color:var(--text);cursor:pointer;text-align:left;transition:background .18s ease, border-color .18s ease, transform .12s ease, box-shadow .18s ease}
.dashboard-alerts-prio-row:hover{background:rgba(255,255,255,.07);border-color:rgba(82,148,247,.28);transform:translateY(-1px);box-shadow:0 6px 20px rgba(0,0,0,.1)}
.dashboard-alerts-prio-row:focus-visible{outline:none;box-shadow:var(--ds-shadow-focus)}
.dashboard-alerts-prio-row--urgent{
  border-left:4px solid rgba(248,113,113,.85);
  background:linear-gradient(90deg,rgba(239,91,107,.08),rgba(255,255,255,.03));
}
.dashboard-alerts-prio-row--watch{
  border-left:4px solid rgba(251,191,36,.75);
  background:linear-gradient(90deg,rgba(245,158,11,.07),rgba(255,255,255,.025));
}
.dashboard-alerts-prio-tier{font-size:9px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--text3);line-height:1.2}
.dashboard-alerts-prio-row--urgent .dashboard-alerts-prio-tier{color:rgba(248,113,113,.95)}
.dashboard-alerts-prio-row--watch .dashboard-alerts-prio-tier{color:rgba(251,191,36,.92)}
.dashboard-alerts-prio-main{display:flex;flex-direction:column;gap:3px;min-width:0}
.dashboard-alerts-prio-title{font-size:13px;font-weight:800;line-height:1.3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;letter-spacing:-.01em}
.dashboard-alerts-prio-meta{font-size:11px;color:var(--text2);line-height:1.25;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dashboard-alerts-prio-badge{flex-shrink:0;font-size:10px!important;padding:4px 9px!important;font-weight:700!important}
.dashboard-alerts-prio-more{margin:8px 0 0;font-size:11px;color:var(--text3);font-weight:600;text-align:center;padding:6px}
.dashboard-vigilance-card{padding:16px 18px;border-radius:var(--ds-radius-md,14px);border:1px solid rgba(243,179,79,.18);background:linear-gradient(145deg,rgba(243,179,79,.07),rgba(255,255,255,.025));box-shadow:0 4px 28px rgba(0,0,0,.12)}
.dashboard-vigilance-host{min-height:0}
.dashboard-vigilance-empty-block{padding:4px 0 2px}
.dashboard-vigilance-empty-lead{margin:0 0 8px;font-size:14px;font-weight:800;line-height:1.35;color:var(--text);letter-spacing:-.02em}
.dashboard-vigilance-empty-detail{margin:0;font-size:12px;line-height:1.5;color:var(--text2);max-width:58ch}
.dashboard-vigilance-rich-list{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:12px}
.dashboard-vigilance-rich-item{margin:0;padding:12px 14px;border-radius:12px;border:1px solid rgba(148,163,184,.12);background:rgba(255,255,255,.04)}
.dashboard-vigilance-rich-item--trend{border-left:3px solid rgba(82,148,247,.65)}
.dashboard-vigilance-rich-item--anomaly{border-left:3px solid rgba(243,179,79,.75)}
.dashboard-vigilance-rich-item--drift{border-left:3px solid rgba(232,93,108,.55)}
.dashboard-vigilance-rich-top{display:flex;align-items:center;gap:8px;margin:0 0 8px}
.dashboard-vigilance-rich-icon{font-size:16px;line-height:1;opacity:.95}
.dashboard-vigilance-rich-variant{font-size:9px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--text3)}
.dashboard-vigilance-rich-headline{margin:0 0 6px;font-size:13px;font-weight:800;line-height:1.35;color:var(--text);letter-spacing:-.02em}
.dashboard-vigilance-rich-detail{margin:0 0 10px;font-size:12px;line-height:1.45;color:var(--text2)}
.dashboard-vigilance-rich-cta{display:flex;flex-wrap:wrap;align-items:center;gap:10px 14px}
.dashboard-vigilance-investigate{padding:6px 14px;border-radius:999px;border:1px solid rgba(82,148,247,.4);background:rgba(82,148,247,.12);color:var(--accent-blue);font-size:11px;font-weight:800;cursor:pointer;font-family:inherit;transition:background .15s ease,border-color .15s ease}
.dashboard-vigilance-investigate:hover{background:rgba(82,148,247,.2);border-color:rgba(82,148,247,.55)}
.dashboard-vigilance-investigate:focus-visible{outline:none;box-shadow:var(--ds-shadow-focus)}
.dashboard-vigilance-rich-hint{font-size:11px;font-weight:600;color:var(--text3)}
.dashboard-auto-analysis-card{padding:0;border-radius:var(--ds-radius-lg,16px);border:0.5px solid rgba(82,148,247,.22);background:linear-gradient(165deg,rgba(82,148,247,.07),rgba(255,255,255,.02));box-shadow:none;overflow:hidden}
.dashboard-auto-analysis-strip{display:flex;flex-wrap:wrap;align-items:center;gap:10px 16px;padding:14px 18px 15px;border-bottom:0.5px solid rgba(148,163,184,.12);background:rgba(82,148,247,.06)}
.dashboard-auto-analysis-strip-badge{display:inline-flex;align-items:center;padding:5px 11px;border-radius:999px;font-size:10px;font-weight:700;letter-spacing:.09em;text-transform:uppercase;color:var(--accent-blue);background:rgba(82,148,247,.14);border:0.5px solid rgba(82,148,247,.32)}
.dashboard-auto-analysis-strip-text{margin:0;flex:1;min-width:min(100%,200px);font-size:12px;line-height:1.5;color:var(--text2)}
.dashboard-auto-analysis-host{min-height:0;padding:16px 18px 18px}
.dashboard-auto-analysis-empty-block{display:flex;gap:16px;align-items:flex-start;padding:6px 2px 4px}
.dashboard-auto-analysis-empty-icon{flex-shrink:0;width:46px;height:46px;border-radius:14px;display:grid;place-items:center;background:rgba(63,185,80,.12);border:0.5px solid rgba(63,185,80,.32)}
.dashboard-auto-analysis-empty-check{font-size:20px;line-height:1;color:rgba(63,185,80,.95);font-weight:700}
.dashboard-auto-analysis-empty-copy{flex:1;min-width:0}
.dashboard-auto-analysis-empty-lead{margin:0 0 8px;font-size:15px;font-weight:600;line-height:1.35;color:var(--text);letter-spacing:-.02em}
.dashboard-auto-analysis-empty-detail{margin:0;font-size:13px;line-height:1.55;color:var(--text2);max-width:58ch}
.dashboard-auto-analysis-list{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:12px}
.dashboard-auto-analysis-item{margin:0;padding:0;border-radius:14px;border:0.5px solid rgba(148,163,184,.12);background:rgba(255,255,255,.035);overflow:hidden;display:flex;gap:0;align-items:stretch}
.dashboard-auto-analysis-item--accent-actions{border-left:3px solid rgba(251,191,36,.88)}
.dashboard-auto-analysis-item--accent-incidents{border-left:3px solid rgba(96,165,250,.92)}
.dashboard-auto-analysis-item--accent-compliance{border-left:3px solid rgba(167,139,250,.9)}
.dashboard-auto-analysis-item--accent-calm{border-left:3px solid rgba(52,211,153,.78)}
.dashboard-auto-analysis-item-index{display:flex;align-items:flex-start;justify-content:center;min-width:42px;padding:16px 8px 16px 12px;font-size:13px;font-weight:700;font-variant-numeric:tabular-nums;color:var(--text3);background:rgba(255,255,255,.03);border-right:0.5px solid rgba(148,163,184,.1);line-height:1.4}
.dashboard-auto-analysis-item-body{flex:1;min-width:0;padding:14px 16px 16px 14px;display:flex;flex-direction:column;gap:0}
.dashboard-auto-analysis-field{margin:0 0 12px}
.dashboard-auto-analysis-field:last-of-type{margin-bottom:10px}
.dashboard-auto-analysis-field-lbl{display:block;margin:0 0 5px;font-size:9px;font-weight:700;letter-spacing:.11em;text-transform:uppercase;color:var(--text3)}
.dashboard-auto-analysis-msg{margin:0;font-size:14px;font-weight:600;line-height:1.45;color:var(--text);letter-spacing:-.015em}
.dashboard-auto-analysis-rec{margin:0;font-size:13px;line-height:1.55;color:var(--text2);font-weight:400}
.dashboard-auto-analysis-item-acts{display:flex;flex-wrap:wrap;gap:8px 10px;margin-top:4px;padding-top:14px;border-top:0.5px solid rgba(148,163,184,.1)}
.dashboard-auto-analysis-act{padding:8px 15px;border-radius:999px;border:0.5px solid rgba(148,163,184,.2);background:rgba(255,255,255,.05);color:var(--text);font-size:12px;font-weight:600;cursor:pointer;font-family:inherit;transition:background .15s ease,border-color .15s ease,transform .12s ease}
@media (prefers-reduced-motion:no-preference){.dashboard-auto-analysis-act:hover{transform:translateY(-1px)}}
.dashboard-auto-analysis-act:focus-visible{outline:none;box-shadow:var(--ds-shadow-focus)}
.dashboard-auto-analysis-act--see{border-color:rgba(82,148,247,.42);color:var(--accent-blue);background:rgba(82,148,247,.1)}
.dashboard-auto-analysis-act--see:hover{background:rgba(82,148,247,.16);border-color:rgba(82,148,247,.5)}
.dashboard-auto-analysis-act--apply{border-color:rgba(66,199,140,.38);color:#4ade80;background:rgba(66,199,140,.1)}
.dashboard-auto-analysis-act--apply:hover{background:rgba(66,199,140,.16);border-color:rgba(66,199,140,.48)}
.dashboard-block-actions{display:flex;flex-wrap:wrap;align-items:center;gap:6px 12px;margin-top:10px;padding-top:10px;border-top:1px solid rgba(148,163,184,.1)}
.dashboard-block-actions--hero{margin-top:0;padding-top:0;border-top:none;align-items:center}
.dashboard-block-actions--tight{margin-top:8px;padding-top:8px}
.dashboard-block-actions-sep{color:var(--text3);font-size:12px;font-weight:600;user-select:none}
.dashboard-block-link{
  padding:7px 14px;
  border-radius:10px;
  border:1px solid var(--color-border-tertiary, rgba(148,163,184,.18));
  background:var(--color-background-secondary, rgba(255,255,255,.06));
  color:var(--accent-blue);
  font-size:12px;
  font-weight:700;
  cursor:pointer;
  text-decoration:none;
  font-family:inherit;
  transition:background .18s ease,border-color .18s ease,box-shadow .18s ease;
  box-shadow:0 2px 8px rgba(0,0,0,.08);
}
.dashboard-block-link:hover{
  opacity:1;
  background:var(--color-background-info, rgba(88,166,255,.14));
  border-color:var(--color-border-info, rgba(88,166,255,.4));
  box-shadow:0 4px 16px rgba(82,148,247,.15);
}
.dashboard-block-link:focus-visible{outline:none;box-shadow:var(--ds-shadow-focus);border-radius:8px}
.dashboard-alerts-prio-footer{margin-top:6px;padding-top:8px;border-top:1px solid rgba(148,163,184,.08)}
.dashboard-alerts-prio-footer .dashboard-block-actions{margin-top:0;padding-top:0;border-top:none}
.dashboard-vigilance-actions,.dashboard-auto-analysis-actions{margin-top:10px;padding-top:10px;border-top:1px solid rgba(148,163,184,.08)}
.dashboard-vigilance-actions .dashboard-block-actions,.dashboard-auto-analysis-actions .dashboard-block-actions{margin-top:0;padding-top:0;border-top:none}
.dashboard-kpi-foot{margin-top:2px;padding:0 2px 4px}
.dashboard-kpi-foot .dashboard-block-actions{margin-top:8px;padding-top:10px;border-top:1px dashed rgba(148,163,184,.14)}
.dashboard-chart-card-footacts{padding:0 18px 14px;margin-top:-2px}
.dashboard-chart-card-footacts .dashboard-block-actions{margin-top:0;padding-top:8px;border-top:1px solid rgba(148,163,184,.08)}
.dashboard-sys-status__actions{margin-top:4px;padding-top:8px;border-top:1px solid rgba(148,163,184,.08)}
.dashboard-sys-status__actions .dashboard-block-actions{margin-top:0;padding-top:0;border-top:none}
.dashboard-activity-col-ctas{margin-top:8px;display:flex;flex-wrap:wrap;gap:6px 10px;align-items:center}
.dashboard-activity-global-ctas{margin-top:14px;display:flex;flex-wrap:wrap;gap:8px 12px;justify-content:center;align-items:center}
.dashboard-sys-status{display:grid;grid-template-columns:4px minmax(0,1fr);gap:0;padding:0;overflow:hidden;border-radius:var(--ds-radius-md,14px);min-height:0}
.dashboard-sys-status__strip{border-radius:3px 0 0 3px;min-height:88px;align-self:stretch}
.dashboard-sys-status__strip--stable{background:linear-gradient(180deg,rgba(66,199,140,.85),rgba(52,163,110,.45))}
.dashboard-sys-status__strip--watch{background:linear-gradient(180deg,rgba(243,179,79,.9),rgba(217,119,6,.5))}
.dashboard-sys-status__strip--fix{background:linear-gradient(180deg,rgba(239,91,107,.9),rgba(220,38,38,.55))}
.dashboard-sys-status__body{padding:12px 16px 14px 14px;display:flex;flex-direction:column;gap:8px;min-width:0}
.dashboard-sys-status__headline{margin:0;font-size:15px;font-weight:800;letter-spacing:-.02em;line-height:1.25;color:var(--text)}
.dashboard-sys-status__hint{margin:0;font-size:12px;line-height:1.35;color:var(--text2);font-weight:500;max-width:52ch}
.dashboard-sys-status__grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px 14px;margin-top:4px}
.dashboard-sys-status__cell{display:flex;flex-direction:column;gap:3px;padding:8px 10px;border-radius:var(--ds-radius-sm,10px);background:rgba(255,255,255,.04);border:1px solid rgba(148,163,184,.08);min-width:0}
.dashboard-sys-status__label{font-size:9px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--text3);line-height:1.2}
.dashboard-sys-status__value{font-size:14px;font-weight:800;color:var(--text);line-height:1.25;font-variant-numeric:tabular-nums}
.dashboard-sys-status--stable .dashboard-sys-status__body{background:linear-gradient(135deg,rgba(66,199,140,.06),transparent)}
.dashboard-sys-status--watch .dashboard-sys-status__body{background:linear-gradient(135deg,rgba(243,179,79,.07),transparent)}
.dashboard-sys-status--fix .dashboard-sys-status__body{background:linear-gradient(135deg,rgba(239,91,107,.07),transparent)}
@media (max-width:900px){.dashboard-sys-status__grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media (max-width:600px){.dashboard-cockpit{padding:18px 16px}.dashboard-cockpit__minis{grid-template-columns:repeat(2,1fr)}.dashboard-cockpit__bar-row{grid-template-columns:minmax(96px,1fr) minmax(0,1.6fr) 40px;gap:10px}.dashboard-shortcuts__grid{grid-template-columns:repeat(2,minmax(0,1fr))}.dashboard-alerts-prio-tier-strip{grid-template-columns:1fr}.dashboard-alerts-prio-row{grid-template-columns:24px 1fr auto;grid-template-areas:"icon tier badge" "icon main main"}.dashboard-alerts-prio-icon{grid-area:icon;align-self:start;padding-top:2px}.dashboard-alerts-prio-tier{grid-area:tier}.dashboard-alerts-prio-main{grid-area:main}.dashboard-alerts-prio-badge{grid-area:badge;justify-self:end}}
.dashboard-kpi-sticky {
  position: sticky;
  top: 0;
  z-index: 89;
  background: var(--bg, #0f172a);
  padding: 8px 0 12px;
  border-bottom: 1px solid rgba(255,255,255,.07);
  margin-bottom: 20px;
}
.dashboard-extended[data-expanded="false"]{display:none}
.dashboard-extended[data-expanded="true"]{display:block}
.dashboard-toggle-row{
  display:flex;justify-content:center;
  padding:6px 0 2px;
}
.dashboard-toggle-btn{
  display:flex;align-items:center;gap:8px;
  background:none;
  border:1px solid rgba(255,255,255,.1);
  border-radius:20px;padding:6px 18px;
  color:var(--text2,rgba(255,255,255,.5));
  font-size:12px;cursor:pointer;
  transition:border-color 150ms,color 150ms;
}
.dashboard-toggle-btn:hover{
  border-color:rgba(255,255,255,.2);
  color:var(--text,rgba(255,255,255,.85));
}
[data-display-mode="simple"] .dashboard-toggle-row{
  display:none;
}
/* Espacement entre bandes — respiration premium */
.dashboard-band { margin-bottom: 8px; }
.dashboard-band + .dashboard-band { margin-top: 4px; }
.dashboard-band--ceo { margin-bottom: 0; }
.dashboard-band--priority { margin-top: 0; }

/* Réduction opacité des éléments secondaires */
.section-kicker {
  font-size: 11px;
  font-weight: 700;
  letter-spacing: .1em;
  text-transform: uppercase;
  opacity: .55;
}
.dashboard-section-sub {
  font-size: 13px;
  opacity: .6;
  max-width: 52ch;
}

/* Titres de section plus tranchés */
.dashboard-section-title {
  font-size: clamp(18px, 1.8vw, 24px);
  font-weight: 800;
  letter-spacing: -.025em;
  line-height: 1.15;
}

/* CEO Hero — le rendre dominant */
.dashboard-ceo-hero__scorenum {
  font-size: clamp(56px, 6vw, 80px);
  font-weight: 900;
  line-height: 1;
  letter-spacing: -.04em;
}

/* Convention couleur sémantique stricte */
.dashboard-band--priority .dashboard-section-kicker,
.section-kicker--alert { color: rgba(239,91,107,.9); }

.dashboard-band--cockpit .dashboard-section-kicker,
.section-kicker--info { color: rgba(82,148,247,.9); }

.dashboard-band--analysis .dashboard-section-kicker,
.section-kicker--analysis { color: rgba(148,103,254,.9); }

/* Suppression des bordures parasites sur les cartes secondaires */
.dashboard-band--tertiary .content-card {
  border-color: rgba(255,255,255,.05);
}

/* Démo — CEO hero dominant (fin de feuille, surcharge) */
.dashboard-ceo-hero__scorenum,
.dashboard-ceo-hero__score-num,
.dashboard-score-value {
  font-size: clamp(64px, 7vw, 88px) !important;
  font-weight: 900 !important;
  letter-spacing: -.04em !important;
  line-height: 1 !important;
}
.dashboard-ceo-hero {
  min-height: 220px;
}
.dashboard-section-title {
  font-size: clamp(19px, 1.9vw, 26px);
  font-weight: 800;
  letter-spacing: -.025em;
  line-height: 1.15;
}
.section-kicker {
  font-size: 11px;
  font-weight: 700;
  letter-spacing: .1em;
  text-transform: uppercase;
  opacity: .5;
}
.dashboard-section-sub,
.dashboard-muted-lead,
.content-card-lead {
  font-size: 13px;
  line-height: 1.55;
  opacity: .65;
  max-width: 58ch;
}
.dashboard-band + .dashboard-band {
  margin-top: 6px;
}
.dashboard-band--ceo {
  margin-bottom: 2px;
}

/* ── Convention sémantique stricte ──────────────── */
/* Rouge = action requise / urgent                   */
.dashboard-band--priority .section-kicker,
.dashboard-band--alerts .section-kicker,
.dashboard-section-kicker--alert {
  color: rgba(239, 91, 107, .85);
  opacity: 1;
}

/* Bleu = information / pilotage                     */
.dashboard-band--cockpit .section-kicker,
.dashboard-band--ceo .section-kicker,
.dashboard-section-kicker--info {
  color: rgba(82, 148, 247, .85);
  opacity: 1;
}

/* Violet = analyse / IA                             */
.dashboard-band--analysis .section-kicker,
.dashboard-band--secondary .section-kicker,
.dashboard-section-kicker--analysis {
  color: rgba(148, 103, 254, .85);
  opacity: 1;
}

/* Vert = situation normale / activité               */
.dashboard-band--situation .section-kicker,
.dashboard-band--tertiary .section-kicker,
.dashboard-section-kicker--ok {
  color: rgba(52, 211, 153, .85);
  opacity: 1;
}

/* ── Cartes secondaires plus légères ────────────── */
.dashboard-band--tertiary .content-card {
  border-color: rgba(255, 255, 255, .04);
  background: rgba(255, 255, 255, .015);
}

/* ── Metric cards — valeurs plus lisibles ───────── */
.metric-value {
  font-size: clamp(28px, 3vw, 38px);
  font-weight: 800;
  letter-spacing: -.03em;
  line-height: 1.1;
}
.metric-label {
  font-size: 11px;
  font-weight: 700;
  letter-spacing: .08em;
  text-transform: uppercase;
  opacity: .55;
}
.metric-note {
  font-size: 12px;
  opacity: .5;
  line-height: 1.4;
}

/* Sections dupliquées — masquées au profit du cockpit premium */
.dashboard-band--cockpit,
.dashboard-band--situation,
.dashboard-band--priority {
  display: none !important;
}

/* Hero CEO « Cockpit QHSE » — masqué (cockpit premium suffit) */
.dashboard-band--ceo {
  display: none !important;
}

.dashboard-ceo-hero__legal-wrap {
  display: none !important;
}
.dashboard-ceo-hero {
  padding: 14px 20px !important;
  min-height: unset !important;
}
.dashboard-ceo-hero__body {
  align-items: center !important;
}
.dashboard-ceo-hero__visual {
  max-width: 110px !important;
}

.shortcut-live-badge {
  font-size: 10px;
  font-weight: 800;
  padding: 1px 7px;
  border-radius: 20px;
  background: rgba(239, 91, 107, 0.15);
  color: rgba(239, 91, 107, 0.9);
  margin-left: 6px;
  flex-shrink: 0;
}

.activity-row {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 12px;
  border-radius: 8px;
  border-bottom: 0.5px solid rgba(255, 255, 255, 0.05);
  transition: background 120ms;
  cursor: pointer;
  min-height: 0;
  max-height: 48px;
  box-sizing: border-box;
}
.activity-row:hover {
  background: rgba(255, 255, 255, 0.04);
}
.activity-row:last-child {
  border-bottom: none;
}
.activity-row__type {
  font-size: 9px;
  font-weight: 800;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  padding: 2px 6px;
  border-radius: 4px;
  background: rgba(82, 148, 247, 0.12);
  color: rgba(82, 148, 247, 0.9);
  flex-shrink: 0;
  width: 56px;
  text-align: center;
}
.activity-row__title {
  flex: 1;
  font-size: 12px;
  font-weight: 500;
  color: rgba(226, 232, 240, 0.85);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.activity-row__status {
  font-size: 11px;
  color: rgba(148, 163, 184, 0.55);
  flex-shrink: 0;
}
.activity-row__date {
  font-size: 11px;
  color: rgba(148, 163, 184, 0.4);
  flex-shrink: 0;
}
.activity-row__link {
  font-size: 12px;
  color: rgba(96, 165, 250, 0.6);
  flex-shrink: 0;
}
`;

export function ensureDashboardStyles() {
  if (document.getElementById(STYLE_ID)) return;
  const el = document.createElement('style');
  el.id = STYLE_ID;
  el.textContent = CSS;
  document.head.append(el);
}
