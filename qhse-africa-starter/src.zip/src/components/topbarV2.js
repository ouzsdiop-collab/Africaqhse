import { pageTopbarById, getFlattenedNavItems, getBreadcrumbForPage } from '../data/navigation.js';
import { canAccessNavPage } from '../utils/permissionsUi.js';
import { getDisplayMode, setDisplayMode } from '../utils/displayMode.js';

const STYLE_ID = 'qhse-topbar-v2-styles';

function ensureTopbarV2Styles() {
  if (document.getElementById(STYLE_ID)) return;
  const el = document.createElement('style');
  el.id = STYLE_ID;
  el.textContent = `
.topbar-v2 {
  position: sticky;
  top: 0;
  z-index: var(--z-topbar);
  flex-shrink: 0;
  height: 56px;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  padding: 0 var(--space-4);
  background: var(--color-surface);
  border-bottom: 1px solid var(--color-border);
  box-shadow: var(--shadow-sm);
  font-family: var(--font-body);
}
.topbar-v2__inner {
  display: flex;
  align-items: center;
  gap: var(--space-4);
  width: 100%;
  min-width: 0;
  height: 100%;
}
.topbar-v2__breadcrumb {
  flex: 0 1 auto;
  min-width: 0;
}
.topbar-v2__breadcrumb-nav {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: var(--space-2);
  margin: 0;
  padding: 0;
  font-size: 13px;
  line-height: 1.3;
}
.topbar-v2__breadcrumb-sep {
  color: var(--color-text-muted);
  user-select: none;
  font-weight: 500;
}
.topbar-v2__breadcrumb-link {
  border: none;
  background: none;
  padding: 0;
  margin: 0;
  font: inherit;
  font-weight: 500;
  color: var(--color-text-secondary);
  cursor: pointer;
  transition: color 150ms ease;
  text-decoration: none;
  max-width: 200px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.topbar-v2__breadcrumb-link:hover {
  color: var(--color-primary-text);
}
.topbar-v2__breadcrumb-current {
  font-weight: 600;
  color: var(--color-text);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  max-width: 280px;
}
.topbar-v2__breadcrumb-static {
  font-weight: 500;
  color: var(--color-text-secondary);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  max-width: 160px;
}
.topbar-v2__center {
  flex: 1 1 200px;
  min-width: 0;
  display: flex;
  justify-content: center;
}
.topbar-v2 .shell-quick-search {
  position: relative;
  width: 100%;
  max-width: 420px;
}
.topbar-v2 .shell-search-icon {
  position: absolute;
  left: var(--space-3);
  top: 50%;
  transform: translateY(-50%);
  display: flex;
  color: var(--color-text-muted);
  pointer-events: none;
}
.topbar-v2 .shell-quick-search-input {
  width: 100%;
  box-sizing: border-box;
  padding: var(--space-2) var(--space-3) var(--space-2) 40px;
  border-radius: var(--radius-md);
  border: 1px solid var(--color-border);
  background: var(--color-subtle);
  color: var(--color-text);
  font-family: inherit;
  font-size: 14px;
  line-height: 1.4;
  transition: border-color 150ms ease, background 150ms ease, box-shadow 150ms ease;
}
.topbar-v2 .shell-quick-search-input:hover {
  border-color: var(--color-primary-border);
  background: var(--color-surface);
}
.topbar-v2 .shell-quick-search-input:focus {
  outline: none;
  border-color: var(--color-primary-border);
  background: var(--color-surface);
  box-shadow: 0 0 0 2px var(--color-primary-bg);
}
.topbar-v2 .shell-quick-search:focus-within .shell-search-icon {
  color: var(--color-primary-text);
}
.topbar-v2 .shell-quick-search-results {
  position: absolute;
  top: calc(100% + var(--space-1));
  left: 0;
  right: 0;
  margin: 0;
  padding: var(--space-2);
  list-style: none;
  border-radius: var(--radius-md);
  border: 1px solid var(--color-border);
  background: var(--color-surface);
  box-shadow: var(--shadow-md);
  max-height: 320px;
  overflow-y: auto;
  z-index: calc(var(--z-topbar) + 1);
}
.topbar-v2 .shell-search-result-btn {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: var(--space-1);
  width: 100%;
  padding: var(--space-2) var(--space-3);
  border: none;
  border-radius: var(--radius-sm);
  background: transparent;
  text-align: left;
  cursor: pointer;
  font-family: inherit;
  transition: background 150ms ease;
}
.topbar-v2 .shell-search-result-btn:hover {
  background: var(--color-subtle);
}
.topbar-v2 .shell-search-result-title {
  font-size: 14px;
  font-weight: 600;
  color: var(--color-text);
}
.topbar-v2 .shell-search-result-group {
  font-size: 12px;
  color: var(--color-text-muted);
}
.topbar-v2 .shell-search-empty {
  padding: var(--space-3);
  font-size: 13px;
  color: var(--color-text-muted);
}
.topbar-v2__trailing {
  flex: 0 0 auto;
  display: flex;
  align-items: center;
  gap: var(--space-2);
  min-width: 0;
}
.topbar-v2__ai {
  display: inline-flex;
  align-items: center;
  gap: var(--space-2);
  min-height: 36px;
  padding: var(--space-2) var(--space-3);
  border-radius: var(--radius-md);
  border: 1px solid var(--color-border);
  background: var(--color-subtle);
  color: var(--color-text);
  font-family: inherit;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  transition: background 150ms ease, border-color 150ms ease, color 150ms ease;
}
.topbar-v2__ai:hover {
  background: var(--color-primary-bg);
  border-color: var(--color-primary-border);
  color: var(--color-primary-text);
}
.topbar-v2__cta {
  min-height: 36px;
  padding: var(--space-2) var(--space-4);
  border-radius: var(--radius-md);
  border: 1px solid var(--color-primary-border);
  background: var(--color-primary-bg);
  color: var(--color-primary-text);
  font-family: inherit;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  transition: background 150ms ease, border-color 150ms ease, transform 150ms ease;
  white-space: nowrap;
}
.topbar-v2__cta:hover {
  filter: brightness(var(--effect-brightness-hover));
}
.display-mode-toggle {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 5px 12px;
  border-radius: 20px;
  border: 1px solid rgba(255, 255, 255, 0.15);
  background: transparent;
  color: var(--text2, rgba(255, 255, 255, 0.6));
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
  transition: all 150ms ease;
  white-space: nowrap;
}
.display-mode-toggle:hover {
  border-color: rgba(255, 255, 255, 0.28);
  color: var(--text, rgba(255, 255, 255, 0.9));
}
[data-display-mode="simple"] .display-mode-toggle {
  border-color: rgba(82, 148, 247, 0.5);
  color: rgba(130, 180, 255, 0.9);
  background: rgba(82, 148, 247, 0.1);
}
.topbar-v2__notif {
  position: relative;
  width: 40px;
  height: 40px;
  padding: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: var(--radius-md);
  border: 1px solid var(--color-border);
  background: transparent;
  color: var(--color-text-secondary);
  cursor: pointer;
  transition: background 150ms ease, border-color 150ms ease, color 150ms ease;
}
.topbar-v2__notif:hover {
  background: var(--color-subtle);
  color: var(--color-text);
  border-color: var(--color-border);
}
.topbar-v2__notif-icon {
  display: flex;
  align-items: center;
  justify-content: center;
}
.topbar-v2__notif-badge {
  position: absolute;
  top: 4px;
  right: 4px;
  min-width: 18px;
  height: 18px;
  padding: 0 5px;
  border-radius: 999px;
  font-size: 10px;
  font-weight: 800;
  line-height: 18px;
  text-align: center;
  background: var(--color-danger-bg);
  color: var(--color-danger-text);
  border: 2px solid var(--color-surface);
  box-sizing: border-box;
  display: none;
}
.topbar-v2__notif-badge--visible {
  display: inline-block;
}
.topbar-v2__avatar {
  width: 36px;
  height: 36px;
  border-radius: var(--radius-md);
  display: grid;
  place-items: center;
  font-size: 12px;
  font-weight: 800;
  color: var(--color-primary-text);
  background: var(--color-primary-bg);
  border: 1px solid var(--color-primary-border);
  flex-shrink: 0;
}
`;
  document.head.append(el);
}

function navigateByHash(pageId) {
  window.location.hash = pageId;
}

const ICON_BELL_SVG = `<svg class="topbar-v2-bell-svg" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M10.3 21a1.94 1.94 0 0 0 4 0" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`;

/** @param {{ name?: string; email?: string } | null | undefined} user */
function userInitials(user) {
  const raw = (user?.name || user?.email || 'Utilisateur').trim();
  const parts = raw.split(/\s+/).filter(Boolean);
  if (parts.length >= 2) {
    const a = parts[0][0] || '';
    const b = parts[parts.length - 1][0] || '';
    return (a + b).toUpperCase();
  }
  return raw.slice(0, 2).toUpperCase() || 'U';
}

function renderBreadcrumb(host, currentPage, onNavigate) {
  host.replaceChildren();
  const crumbs = getBreadcrumbForPage(currentPage);
  const nav = document.createElement('nav');
  nav.className = 'topbar-v2__breadcrumb-nav';
  nav.setAttribute('aria-label', 'Fil d\'Ariane');

  crumbs.forEach((crumb, i) => {
    if (i > 0) {
      const sep = document.createElement('span');
      sep.className = 'topbar-v2__breadcrumb-sep';
      sep.setAttribute('aria-hidden', 'true');
      sep.textContent = '›';
      nav.append(sep);
    }

    const isLast = i === crumbs.length - 1;

    if (isLast) {
      const span = document.createElement('span');
      span.className = 'topbar-v2__breadcrumb-current';
      span.textContent = crumb.label;
      span.setAttribute('aria-current', 'page');
      nav.append(span);
    } else if (crumb.pageId) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'topbar-v2__breadcrumb-link';
      btn.textContent = crumb.label;
      btn.addEventListener('click', () => {
        if (typeof onNavigate === 'function') onNavigate(crumb.pageId);
        else navigateByHash(crumb.pageId);
      });
      nav.append(btn);
    } else {
      const span = document.createElement('span');
      span.className = 'topbar-v2__breadcrumb-static';
      span.textContent = crumb.label;
      nav.append(span);
    }
  });

  host.append(nav);
}

export function createTopbar({
  currentPage,
  sessionUser,
  unreadCount,
  onToggleNotifications,
  onNavigate
}) {
  ensureTopbarV2Styles();

  const header = document.createElement('header');
  header.className = 'topbar-v2';

  const meta = pageTopbarById[currentPage] || {};
  const cta = meta.cta;
  const role = sessionUser?.role;

  const safeUnread = Math.max(0, Number(unreadCount) || 0);
  const badgeLabel = safeUnread > 99 ? '99+' : String(safeUnread);
  const mode = getDisplayMode();

  header.innerHTML = `
    <div class="topbar-v2__inner">
      <div class="topbar-v2__breadcrumb" data-tb2-breadcrumb></div>
      <div class="topbar-v2__center">
        <div class="shell-quick-search" role="search">
          <label class="visually-hidden" for="tb2-shell-quick-search-input">Rechercher un module</label>
          <span class="shell-search-icon" aria-hidden="true">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
          </span>
          <input
            id="tb2-shell-quick-search-input"
            type="search"
            class="shell-quick-search-input"
            placeholder="Rechercher…"
            autocomplete="off"
            spellcheck="false"
          />
          <ul class="shell-quick-search-results" hidden></ul>
        </div>
      </div>
      <div class="topbar-v2__trailing">
        <button type="button" class="topbar-v2__ai topbar-ai-btn" aria-label="Ouvrir le Centre IA">
          <span class="ghost-chip-icon" aria-hidden="true">✦</span>
          <span>Centre IA</span>
        </button>
        ${
          cta
            ? `<button type="button" class="topbar-v2__cta topbar-cta">${cta.label}</button>`
            : ''
        }
        <button type="button" class="display-mode-toggle" data-mode="${mode}" aria-label="Basculer le mode d'affichage">
          <svg class="display-mode-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="3" y="3" width="8" height="8" rx="1"/>
            <rect x="13" y="3" width="8" height="8" rx="1"/>
            <rect x="3" y="13" width="8" height="8" rx="1"/>
            <rect x="13" y="13" width="8" height="8" rx="1" opacity="0.4"/>
          </svg>
          <span class="display-mode-label">${mode === 'simple' ? 'Expert' : 'Simplifié'}</span>
        </button>
        <button type="button" class="topbar-v2__notif notification-toggle" aria-label="Notifications${safeUnread ? ` (${safeUnread} non lues)` : ''}">
          <span class="topbar-v2__notif-icon" aria-hidden="true">${ICON_BELL_SVG}</span>
          <span class="topbar-v2__notif-badge${safeUnread ? ' topbar-v2__notif-badge--visible' : ''}" ${safeUnread ? '' : 'hidden'} data-notif-badge>${badgeLabel}</span>
        </button>
        <div class="topbar-v2__avatar-wrap" role="group" aria-label="Utilisateur connecté">
          <span class="topbar-v2__avatar" aria-hidden="true"></span>
          <span class="visually-hidden topbar-v2__user-name"></span>
        </div>
      </div>
    </div>
  `;

  const breadcrumbHost = header.querySelector('[data-tb2-breadcrumb]');
  if (breadcrumbHost) {
    renderBreadcrumb(breadcrumbHost, currentPage, onNavigate);
  }

  const avatarEl = header.querySelector('.topbar-v2__avatar');
  const nameHidden = header.querySelector('.topbar-v2__user-name');

  function allAccessibleItems() {
    return getFlattenedNavItems().filter((item) => canAccessNavPage(role, item.id));
  }

  if (avatarEl) {
    avatarEl.textContent = userInitials(sessionUser);
  }
  if (nameHidden) {
    nameHidden.textContent = sessionUser?.name || sessionUser?.email || 'Utilisateur';
  }

  const searchInput = header.querySelector('.shell-quick-search-input');
  const searchResults = header.querySelector('.shell-quick-search-results');
  const searchWrap = header.querySelector('.shell-quick-search');

  function renderSearchResults(query) {
    if (!searchResults) return;
    const q = (query || '').trim().toLowerCase();
    searchResults.replaceChildren();
    if (!q) {
      searchResults.hidden = true;
      return;
    }
    const items = allAccessibleItems().filter(
      (it) =>
        it.label.toLowerCase().includes(q) || it.groupLabel.toLowerCase().includes(q)
    );
    const max = 8;
    items.slice(0, max).forEach((it) => {
      const li = document.createElement('li');
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'shell-search-result-btn';
      btn.innerHTML = `<span class="shell-search-result-title">${it.label}</span><span class="shell-search-result-group">${it.groupLabel}</span>`;
      btn.addEventListener('click', () => {
        if (searchInput) searchInput.value = '';
        searchResults.hidden = true;
        if (typeof onNavigate === 'function') onNavigate(it.id);
        else navigateByHash(it.id);
      });
      li.append(btn);
      searchResults.append(li);
    });
    if (items.length === 0) {
      const li = document.createElement('li');
      li.className = 'shell-search-empty';
      li.textContent = 'Aucun module correspondant';
      searchResults.append(li);
    }
    searchResults.hidden = false;
  }

  function closeSearchOnOutside(ev) {
    if (searchWrap && !searchWrap.contains(ev.target)) {
      if (searchResults) searchResults.hidden = true;
      document.removeEventListener('click', closeSearchOnOutside, true);
    }
  }

  if (searchInput && searchResults) {
    searchInput.addEventListener('input', () => renderSearchResults(searchInput.value));
    searchInput.addEventListener('focus', () => {
      document.addEventListener('click', closeSearchOnOutside, true);
      if (searchInput.value.trim()) renderSearchResults(searchInput.value);
    });
    searchInput.addEventListener('keydown', (ev) => {
      if (ev.key === 'Escape') {
        searchResults.hidden = true;
        searchInput.blur();
      }
    });
  }

  const modeToggle = header.querySelector('.display-mode-toggle');
  if (modeToggle) {
    modeToggle.addEventListener('click', () => {
      const currentMode = modeToggle.dataset.mode;
      const newMode = currentMode === 'simple' ? 'expert' : 'simple';
      setDisplayMode(newMode);
      modeToggle.dataset.mode = newMode;
      const label = modeToggle.querySelector('.display-mode-label');
      if (label) label.textContent = newMode === 'simple' ? 'Expert' : 'Simplifié';
    });
  }

  const notifBtn = header.querySelector('.notification-toggle');
  if (notifBtn) {
    notifBtn.addEventListener('click', onToggleNotifications);
  }

  const aiBtn = header.querySelector('.topbar-ai-btn');
  if (aiBtn && role && !canAccessNavPage(role, 'ai-center')) {
    aiBtn.style.display = 'none';
  }
  if (aiBtn) {
    aiBtn.addEventListener('click', () => {
      if (typeof onNavigate === 'function') onNavigate('ai-center');
      else navigateByHash('ai-center');
    });
  }

  const ctaBtn = header.querySelector('.topbar-cta');
  if (ctaBtn && cta) {
    ctaBtn.addEventListener('click', () => {
      if (typeof onNavigate === 'function') onNavigate(cta.pageId);
      else navigateByHash(cta.pageId);
    });
  }

  return header;
}
