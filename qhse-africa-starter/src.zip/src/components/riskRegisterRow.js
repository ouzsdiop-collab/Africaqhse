import { riskCriticalityFromMeta } from './riskMatrixPanel.js';

function toneClass(tone) {
  if (tone === 'red') return 'red';
  if (tone === 'amber') return 'amber';
  return 'blue';
}

/** @param {number} tier 1..5 */
function tierToRowTone(tier) {
  if (tier >= 5) return 'red';
  if (tier >= 3) return 'amber';
  return 'blue';
}

/**
 * Ligne de registre : criticité alignée sur G×P (score + palier) quand le meta est parsable.
 */
export function createRiskRegisterRow(risk) {
  const crit = riskCriticalityFromMeta(risk.meta);
  const toneKey = crit ? tierToRowTone(crit.tier) : toneClass(risk.tone);

  const row = document.createElement('article');
  row.className = `risk-register-row risk-register-row--${toneKey}`;

  const head = document.createElement('div');
  head.className = 'risk-register-row__head';

  const title = document.createElement('strong');
  title.className = 'risk-register-row__title';
  title.textContent = risk.title;

  const badge = document.createElement('span');
  badge.className = `badge ${toneKey} risk-register-row__badge`;
  badge.textContent = crit ? crit.label : risk.status;

  head.append(title, badge);

  const critRow = document.createElement('div');
  critRow.className = 'risk-register-row__crit';

  if (crit) {
    const gpEl = document.createElement('span');
    gpEl.className = 'risk-register-row__gp';
    gpEl.textContent = `G${crit.g} × P${crit.p}`;

    const scoreEl = document.createElement('span');
    scoreEl.className = 'risk-register-row__score';
    scoreEl.textContent = `Score ${crit.product}`;

    const tierEl = document.createElement('span');
    tierEl.className = `risk-register-row__tier-chip risk-register-row__tier-chip--t${crit.tier}`;
    tierEl.textContent = crit.label;

    critRow.append(gpEl, scoreEl, tierEl);
  } else {
    const raw = risk.meta != null && String(risk.meta).trim() ? String(risk.meta).trim() : '';
    const fallback = document.createElement('span');
    fallback.className = 'risk-register-row__crit-fallback';
    fallback.textContent = raw || 'Criticité non renseignée';
    const hint = document.createElement('span');
    hint.className = 'risk-register-row__crit-hint';
    hint.textContent = raw
      ? 'Format attendu : G1–5 × P1–5 (ex. G3 × P4) pour calculer score et palier.'
      : 'Indiquez G × P sur la fiche pour aligner registre et matrice.';
    critRow.append(fallback, hint);
  }

  const desc = document.createElement('p');
  desc.className = 'risk-register-row__desc';
  desc.textContent = risk.detail;

  row.append(head, critRow, desc);
  return row;
}
