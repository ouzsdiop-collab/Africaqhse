/**
 * Matrice G × P + outil de pilotage : priorités, raccourcis vers les cases occupées, filtre registre.
 */

const GP_RE = /G\s*([1-5])\s*[×xX*]\s*P\s*([1-5])/;

export function parseRiskMatrixGp(meta) {
  const m = GP_RE.exec(String(meta ?? '').trim());
  if (!m) return null;
  const g = Number(m[1]);
  const p = Number(m[2]);
  if (!Number.isFinite(g) || !Number.isFinite(p)) return null;
  if (g < 1 || g > 5 || p < 1 || p > 5) return null;
  return { g, p };
}

export function riskScoreProduct(g, p) {
  return g * p;
}

export function riskTierFromGp(g, p) {
  const s = g * p;
  if (s >= 20) return 5;
  if (s >= 12) return 4;
  if (s >= 7) return 3;
  if (s >= 3) return 2;
  return 1;
}

const TIER_LABELS = {
  1: 'Faible',
  2: 'Modéré',
  3: 'Élevé',
  4: 'Très élevé',
  5: 'Critique'
};

export function riskLevelLabelFromTier(tier) {
  return TIER_LABELS[Math.min(5, Math.max(1, tier))] || '—';
}

export function riskCriticalityFromMeta(meta) {
  const gp = parseRiskMatrixGp(meta);
  if (!gp) return null;
  const product = riskScoreProduct(gp.g, gp.p);
  const tier = riskTierFromGp(gp.g, gp.p);
  return {
    g: gp.g,
    p: gp.p,
    product,
    tier,
    label: riskLevelLabelFromTier(tier)
  };
}

const P_TITLE = {
  1: 'Improbable',
  2: 'Rare',
  3: 'Occasionnelle',
  4: 'Probable',
  5: 'Fréquente'
};
const G_TITLE = {
  1: 'Négligeable',
  2: 'Mineure',
  3: 'Modérée',
  4: 'Majeure',
  5: 'Catastrophique'
};

function tierForCell(g, p) {
  return riskTierFromGp(g, p);
}

/**
 * @param {object} opts
 * @param {(filter: { g: number, p: number } | null) => void} [opts.onFilterChange]
 * @param {'default'|'embedded'} [opts.variant] — `embedded` : libellés courts + espacements resserrés (panneau secondaire)
 */
export function createRiskMatrixPanel(opts = {}) {
  const { onFilterChange, variant = 'default' } = opts;

  const wrap = document.createElement('div');
  wrap.className =
    variant === 'embedded'
      ? 'risk-matrix-panel risk-matrix-panel--embedded'
      : 'risk-matrix-panel';

  const tool = document.createElement('div');
  tool.className = 'risk-matrix-tool';

  const toolHead = document.createElement('div');
  toolHead.className = 'risk-matrix-tool__head';
  toolHead.innerHTML =
    variant === 'embedded'
      ? '<strong class="risk-matrix-tool__title">Synthèse G×P</strong><p class="risk-matrix-tool__lede">Compteurs et pastilles filtrent le registre. Grille ci-dessous pour affiner par case.</p>'
      : '<strong class="risk-matrix-tool__title">Pilotage par criticité</strong><p class="risk-matrix-tool__lede">Les compteurs ci-dessous suivent vos fiches (G×P). Les pastilles ouvrent le filtre sur le registre — pas besoin de chercher la case dans la grille.</p>';

  const priorityRow = document.createElement('div');
  priorityRow.className = 'risk-matrix-priority-row';
  priorityRow.setAttribute('aria-label', 'Répartition par palier');

  const hotspotsSection = document.createElement('div');
  hotspotsSection.className = 'risk-matrix-hotspots-section';

  const hotspotsLabel = document.createElement('div');
  hotspotsLabel.className = 'risk-matrix-hotspots-section__label';
  hotspotsLabel.textContent = 'Raccourcis — cases avec fiches';

  const hotspots = document.createElement('div');
  hotspots.className = 'risk-matrix-hotspots';
  hotspots.setAttribute('role', 'toolbar');
  hotspots.setAttribute('aria-label', 'Filtrer par case G×P');

  const statusRow = document.createElement('div');
  statusRow.className = 'risk-matrix-status-row';

  const stats = document.createElement('p');
  stats.className = 'risk-matrix-panel__stats';
  stats.setAttribute('aria-live', 'polite');

  const resetBtn = document.createElement('button');
  resetBtn.type = 'button';
  resetBtn.className = 'btn btn-secondary risk-matrix-panel__reset';
  resetBtn.textContent = 'Tout afficher';
  resetBtn.hidden = true;

  statusRow.append(stats, resetBtn);

  hotspotsSection.append(hotspotsLabel, hotspots);
  tool.append(toolHead, priorityRow, hotspotsSection, statusRow);

  const gridWrap = document.createElement('div');
  gridWrap.className = 'risk-matrix-grid-wrap';

  const gridLabel = document.createElement('div');
  gridLabel.className = 'risk-matrix-grid-wrap__label';
  gridLabel.innerHTML =
    'Grille <span class="risk-matrix-grid-wrap__hint">(G = gravité, P = probabilité — détails au survol des en-têtes)</span>';

  const grid = document.createElement('div');
  grid.className = 'risk-matrix-grid';
  grid.setAttribute('role', 'grid');
  grid.setAttribute('aria-label', 'Matrice gravité × probabilité');

  const legend = document.createElement('div');
  legend.className = 'risk-matrix-legend';
  legend.innerHTML = `
    <span class="risk-matrix-legend__compact" title="Couleur selon score G×P (1–25)">
      <span class="risk-matrix-legend__compact-label">Palier</span>
      <span class="risk-matrix-legend__sw risk-matrix-legend__sw--1">F</span>
      <span class="risk-matrix-legend__sw risk-matrix-legend__sw--2">M</span>
      <span class="risk-matrix-legend__sw risk-matrix-legend__sw--3">É</span>
      <span class="risk-matrix-legend__sw risk-matrix-legend__sw--4">T</span>
      <span class="risk-matrix-legend__sw risk-matrix-legend__sw--5">C</span>
    </span>
  `;

  gridWrap.append(gridLabel, grid);

  let activeFilter = null;
  /** @type {Array<{ title?: string, meta?: string }>} */
  let lastRisks = [];

  const cellButtons = new Map();

  function cellKey(g, p) {
    return `${g}-${p}`;
  }

  function selectCellFilter(g, p) {
    const btn = cellButtons.get(cellKey(g, p));
    const n = Number(btn?.dataset.count || '0');
    if (n === 0) return;
    activeFilter = { g, p };
    if (typeof onFilterChange === 'function') onFilterChange(activeFilter);
    sync();
  }

  function buildGrid() {
    grid.replaceChildren();
    cellButtons.clear();

    const corner = document.createElement('div');
    corner.className = 'risk-matrix-grid__corner';
    corner.innerHTML = '<span>G</span><span>P →</span>';
    corner.title = 'Lignes : gravité 5 (haut) → 1. Colonnes : probabilité 1 → 5.';

    grid.append(corner);

    for (let p = 1; p <= 5; p++) {
      const h = document.createElement('div');
      h.className = 'risk-matrix-grid__colhead';
      h.textContent = `P${p}`;
      h.title = `Probabilité ${p}/5 — ${P_TITLE[p]}`;
      grid.append(h);
    }

    for (let g = 5; g >= 1; g--) {
      const rh = document.createElement('div');
      rh.className = 'risk-matrix-grid__rowhead';
      rh.textContent = `G${g}`;
      rh.title = `Gravité ${g}/5 — ${G_TITLE[g]}`;
      grid.append(rh);

      for (let p = 1; p <= 5; p++) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'risk-matrix-cell';
        btn.dataset.g = String(g);
        btn.dataset.p = String(p);
        const tier = tierForCell(g, p);
        btn.classList.add(`risk-matrix-cell--t${tier}`);
        const prod = g * p;
        btn.setAttribute(
          'aria-label',
          `Gravité ${g}, probabilité ${p}, score ${prod}, ${riskLevelLabelFromTier(tier)}`
        );
        btn.addEventListener('click', () => onCellClick(g, p));
        grid.append(btn);
        cellButtons.set(cellKey(g, p), btn);
      }
    }
  }

  function onCellClick(g, p) {
    const at = cellKey(g, p);
    const btn = cellButtons.get(at);
    const n = Number(btn?.dataset.count || '0');
    if (n === 0) {
      if (activeFilter && activeFilter.g === g && activeFilter.p === p) {
        activeFilter = null;
        if (typeof onFilterChange === 'function') onFilterChange(null);
        sync();
      }
      return;
    }
    if (activeFilter && activeFilter.g === g && activeFilter.p === p) {
      activeFilter = null;
    } else {
      activeFilter = { g, p };
    }
    if (typeof onFilterChange === 'function') onFilterChange(activeFilter);
    sync();
  }

  resetBtn.addEventListener('click', () => {
    activeFilter = null;
    if (typeof onFilterChange === 'function') onFilterChange(null);
    sync();
  });

  function sync() {
    const bucket = {};
    let unplaced = 0;
    for (let g = 1; g <= 5; g++) {
      for (let p = 1; p <= 5; p++) {
        bucket[cellKey(g, p)] = { titles: [], gp: { g, p } };
      }
    }

    let zCrit = 0;
    let zElev = 0;
    let zLow = 0;

    lastRisks.forEach((r) => {
      const gp = parseRiskMatrixGp(r.meta);
      if (!gp) {
        unplaced += 1;
        return;
      }
      const c = riskCriticalityFromMeta(r.meta);
      if (c) {
        if (c.tier >= 5) zCrit += 1;
        else if (c.tier >= 3) zElev += 1;
        else zLow += 1;
      }
      const k = cellKey(gp.g, gp.p);
      if (!bucket[k]) return;
      const t = (r.title || 'Sans titre').trim();
      if (t) bucket[k].titles.push(t);
    });

    priorityRow.replaceChildren();

    function addPriorityCard(classMod, value, label, hint) {
      const card = document.createElement('div');
      card.className = `risk-matrix-priority-card ${classMod}`;
      const v = document.createElement('span');
      v.className = 'risk-matrix-priority-card__value';
      v.textContent = String(value);
      const txt = document.createElement('div');
      txt.className = 'risk-matrix-priority-card__text';
      const lb = document.createElement('span');
      lb.className = 'risk-matrix-priority-card__label';
      lb.textContent = label;
      const ht = document.createElement('span');
      ht.className = 'risk-matrix-priority-card__hint';
      ht.textContent = hint;
      txt.append(lb, ht);
      card.append(v, txt);
      priorityRow.append(card);
    }

    addPriorityCard(
      'risk-matrix-priority-card--crit',
      zCrit,
      'Critique',
      'Palier max (score G×P ≥ 20)'
    );
    addPriorityCard(
      'risk-matrix-priority-card--warn',
      zElev,
      'Élevé',
      'Palier 3–4 (score 7 à 19)'
    );
    addPriorityCard(
      'risk-matrix-priority-card--ok',
      zLow,
      'Modéré / faible',
      'Palier 1–2 (score ≤ 6)'
    );

    if (unplaced > 0) {
      const card = document.createElement('div');
      card.className = 'risk-matrix-priority-card risk-matrix-priority-card--muted';
      const v = document.createElement('span');
      v.className = 'risk-matrix-priority-card__value';
      v.textContent = String(unplaced);
      const txt = document.createElement('div');
      txt.className = 'risk-matrix-priority-card__text';
      const lb = document.createElement('span');
      lb.className = 'risk-matrix-priority-card__label';
      lb.textContent = 'Sans G×P';
      const ht = document.createElement('span');
      ht.className = 'risk-matrix-priority-card__hint';
      ht.textContent = 'Non visibles sur la matrice';
      txt.append(lb, ht);
      card.append(v, txt);
      priorityRow.append(card);
    }

    hotspots.replaceChildren();
    const occupied = [];
    for (let g = 1; g <= 5; g++) {
      for (let p = 1; p <= 5; p++) {
        const k = cellKey(g, p);
        const n = bucket[k].titles.length;
        if (n > 0) {
          occupied.push({
            g,
            p,
            n,
            product: g * p,
            tier: tierForCell(g, p),
            titles: bucket[k].titles
          });
        }
      }
    }
    occupied.sort((a, b) => b.product - a.product || b.n - a.n);

    if (occupied.length === 0) {
      const empty = document.createElement('p');
      empty.className = 'risk-matrix-hotspots-empty';
      empty.textContent =
        'Aucune fiche positionnée : renseignez G×P (ex. G3 × P4) sur chaque risque pour activer la matrice et ces raccourcis.';
      hotspots.append(empty);
    } else {
      occupied.forEach(({ g, p, n, product, tier, titles }) => {
        const chip = document.createElement('button');
        chip.type = 'button';
        chip.className = `risk-matrix-hotspot-chip risk-matrix-hotspot-chip--t${tier}`;
        if (activeFilter && activeFilter.g === g && activeFilter.p === p) {
          chip.classList.add('risk-matrix-hotspot-chip--active');
        }
        chip.innerHTML = `<span class="risk-matrix-hotspot-chip__gp">G${g}×P${p}</span><span class="risk-matrix-hotspot-chip__mid"><strong>${n}</strong> fiche${n > 1 ? 's' : ''}</span><span class="risk-matrix-hotspot-chip__score">score ${product}</span>`;
        chip.title = `${riskLevelLabelFromTier(tier)} — ${titles.slice(0, 3).join(' · ')}${titles.length > 3 ? '…' : ''}`;
        chip.addEventListener('click', () => selectCellFilter(g, p));
        hotspots.append(chip);
      });
    }

    let placed = 0;
    for (let g = 1; g <= 5; g++) {
      for (let p = 1; p <= 5; p++) {
        const k = cellKey(g, p);
        const btn = cellButtons.get(k);
        if (!btn) continue;
        const { titles } = bucket[k];
        const n = titles.length;
        placed += n;
        btn.dataset.count = String(n);
        btn.classList.toggle('risk-matrix-cell--empty', n === 0);
        btn.classList.toggle('risk-matrix-cell--has-data', n > 0);
        btn.classList.toggle(
          'risk-matrix-cell--active',
          Boolean(activeFilter && activeFilter.g === g && activeFilter.p === p)
        );
        const prod = g * p;
        const lvl = riskLevelLabelFromTier(tierForCell(g, p));
        btn.replaceChildren();
        if (n > 0) {
          const countEl = document.createElement('span');
          countEl.className = 'risk-matrix-cell__count';
          countEl.textContent = String(n);
          btn.append(countEl);
        }
        btn.setAttribute(
          'title',
          n === 0
            ? `Case G${g}×P${p} — score ${prod} (${lvl}) — vide`
            : `G${g}×P${p} — score ${prod} (${lvl}) — ${n} fiche(s). Clic : filtre / second clic : tout.`
        );
      }
    }

    const total = lastRisks.length;
    if (activeFilter) {
      const m = lastRisks.filter((r) => {
        const gp = parseRiskMatrixGp(r.meta);
        return gp && gp.g === activeFilter.g && gp.p === activeFilter.p;
      }).length;
      const sc = activeFilter.g * activeFilter.p;
      const lv = riskLevelLabelFromTier(riskTierFromGp(activeFilter.g, activeFilter.p));
      stats.textContent = `Liste filtrée : G${activeFilter.g}×P${activeFilter.p} · score ${sc} (${lv}) · ${m} fiche(s).`;
      resetBtn.hidden = false;
    } else {
      const parts = [`${total} fiche(s)`, `${placed} sur la matrice`];
      if (unplaced > 0) parts.push(`${unplaced} sans position`);
      stats.textContent = parts.join(' · ');
      resetBtn.hidden = true;
    }
  }

  buildGrid();
  wrap.append(tool, gridWrap, legend);

  return {
    element: wrap,
    setRisks(risks) {
      lastRisks = Array.isArray(risks) ? [...risks] : [];
      if (activeFilter) {
        const still = lastRisks.some((r) => {
          const gp = parseRiskMatrixGp(r.meta);
          return gp && gp.g === activeFilter.g && gp.p === activeFilter.p;
        });
        if (!still) {
          activeFilter = null;
          if (typeof onFilterChange === 'function') onFilterChange(null);
        }
      }
      sync();
    },
    clearFilter() {
      activeFilter = null;
      if (typeof onFilterChange === 'function') onFilterChange(null);
      sync();
    },
    getFilter() {
      return activeFilter;
    }
  };
}
