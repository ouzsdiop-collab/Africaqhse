const STYLE_ID = 'qhse-iso-compliance-assist-styles';

const CSS = `
.iso-ca-overlay{
  position:fixed;inset:0;z-index:200;
  background:rgba(0,0,0,.55);
  display:flex;align-items:center;justify-content:center;
  padding:20px;box-sizing:border-box;
  backdrop-filter:blur(6px);
}
.iso-ca-panel{
  width:100%;max-width:560px;max-height:min(90vh,720px);
  overflow:auto;display:flex;flex-direction:column;gap:0;
  padding:0!important;
  border:1px solid rgba(148,163,184,.18);
  box-shadow:0 24px 64px rgba(0,0,0,.4);
}
.iso-ca-head{
  display:flex;align-items:flex-start;justify-content:space-between;gap:12px;
  padding:18px 20px 12px;
  border-bottom:1px solid rgba(148,163,184,.1);
}
.iso-ca-kicker{margin-bottom:4px}
.iso-ca-title{margin:0 0 6px;font-size:18px;font-weight:800;letter-spacing:-.02em}
.iso-ca-sub{margin:0;font-size:13px;line-height:1.45;color:var(--text2);max-width:48ch}
.iso-ca-close{flex-shrink:0;min-width:40px;padding:8px 12px!important}
.iso-ca-body{padding:16px 20px 20px}
.iso-ca-loading-text{margin:0 0 8px;font-size:15px;font-weight:700;color:var(--text)}
.iso-ca-loading-hint{margin:0;font-size:12px;line-height:1.5;color:var(--text3);max-width:52ch}
.iso-ca-proposed{display:flex;flex-wrap:wrap;align-items:center;gap:10px;margin-bottom:14px}
.iso-ca-proposed-label{font-size:10px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--text3)}
.iso-ca-status-pill{
  display:inline-flex;align-items:center;padding:8px 14px;border-radius:999px;
  font-size:14px;font-weight:800;letter-spacing:.02em;
}
.iso-ca-status-pill--conforme{background:rgba(52,211,153,.15);color:#6ee7b7;border:1px solid rgba(52,211,153,.35)}
.iso-ca-status-pill--partiel{background:rgba(251,191,36,.14);color:#fde68a;border:1px solid rgba(251,191,36,.38)}
.iso-ca-status-pill--non_conforme{background:rgba(248,113,113,.14);color:#fecaca;border:1px solid rgba(248,113,113,.38)}
.iso-ca-explain{margin:0 0 16px;font-size:14px;line-height:1.55;color:var(--text2)}
.iso-ca-block{margin-bottom:14px}
.iso-ca-h4{margin:0 0 8px;font-size:11px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--text3)}
.iso-ca-list{margin:0;padding-left:1.2rem;font-size:13px;line-height:1.55;color:var(--text2)}
.iso-ca-list li{margin-bottom:6px}
.iso-ca-docs{margin:0;padding-left:0;list-style:none;font-size:13px;line-height:1.45;color:var(--text2)}
.iso-ca-docs li{margin-bottom:10px;padding-bottom:10px;border-bottom:1px dashed rgba(148,163,184,.12)}
.iso-ca-docs li:last-child{border-bottom:none;margin-bottom:0;padding-bottom:0}
.iso-ca-doc-meta{display:block;margin-top:4px;font-size:11px;color:var(--text3);font-weight:600}
.iso-ca-disclaimer{margin:14px 0 0;padding:12px 14px;border-radius:12px;border:1px solid rgba(125,211,252,.22);
  background:rgba(125,211,252,.06);font-size:11px;line-height:1.5;color:var(--text3)}
.iso-ca-human{margin-top:18px;padding-top:16px;border-top:1px solid rgba(148,163,184,.12)}
.iso-ca-human-title{margin:0 0 6px;font-size:13px;font-weight:800;color:var(--text)}
.iso-ca-human-text{margin:0 0 14px;font-size:12px;line-height:1.5;color:var(--text2)}
.iso-ca-actions-row{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:14px}
.iso-ca-override-label{margin:0 0 8px;font-size:11px;font-weight:700;color:var(--text3)}
.iso-ca-override-row{display:flex;flex-wrap:wrap;gap:8px}
.iso-ca-error-msg{margin:0 0 12px;font-size:13px;color:#fecaca;line-height:1.45}
`;

export function ensureIsoComplianceAssistStyles() {
  if (document.getElementById(STYLE_ID)) return;
  const el = document.createElement('style');
  el.id = STYLE_ID;
  el.textContent = CSS;
  document.head.append(el);
}
