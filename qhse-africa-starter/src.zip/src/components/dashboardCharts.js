/**
 * Graphiques dashboard — SVG / barres CSS, données injectées (pas de lib externe).
 */

/**
 * @param {Array<{ createdAt?: string }>} incidents
 * @returns {{ label: string; value: number }[]}
 */
export function buildIncidentMonthlySeries(incidents) {
  if (!Array.isArray(incidents)) return [];
  const now = new Date();
  const buckets = [];
  for (let i = 5; i >= 0; i -= 1) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    buckets.push({
      key: `${d.getFullYear()}-${d.getMonth()}`,
      label: d.toLocaleDateString('fr-FR', { month: 'short' })
    });
  }
  const counts = buckets.map((b) => ({ label: b.label, value: 0 }));
  incidents.forEach((inc) => {
    if (!inc?.createdAt) return;
    const dt = new Date(inc.createdAt);
    if (Number.isNaN(dt.getTime())) return;
    const key = `${dt.getFullYear()}-${dt.getMonth()}`;
    const idx = buckets.findIndex((b) => b.key === key);
    if (idx >= 0) counts[idx].value += 1;
  });
  return counts;
}

/**
 * @param {{ label: string; value: number }[]} safe
 */
function interpretIncidentTrend(safe) {
  const vals = safe.map((p) => (Number.isFinite(p.value) ? p.value : 0));
  const total = vals.reduce((a, b) => a + b, 0);
  if (total === 0) {
    return 'Aucun incident sur six mois.';
  }
  const last3 = vals.slice(-3).reduce((a, b) => a + b, 0);
  const first3 = vals.slice(0, 3).reduce((a, b) => a + b, 0);
  if (first3 > 0 && last3 > first3 * 1.25) {
    return `La période récente est plus dense qu’au début des six mois (${total} incident${total > 1 ? 's' : ''} au total) — à regarder de près.`;
  }
  if (first3 > 0 && last3 < first3 * 0.75) {
    return `Le volume d’incidents semble en baisse sur la fin de période (${total} sur six mois) — dynamique plutôt favorable sur cet échantillon.`;
  }
  return `Rythme stable d’un mois à l’autre (${total} sur six mois).`;
}

/**
 * @param {{ overdue: number; done: number; other: number }} parts
 */
function interpretActionsMixParts(parts) {
  const o = Math.max(0, Number(parts.overdue) || 0);
  const d = Math.max(0, Number(parts.done) || 0);
  const r = Math.max(0, Number(parts.other) || 0);
  const sum = o + d + r;
  if (sum === 0) return 'Aucune donnée sur cette période.';
  const ratio = o / sum;
  if (ratio > 0.28) {
    return 'Une part importante des actions est en retard.';
  }
  if (o === 0) {
    return 'Aucun retard sur les actions affichées.';
  }
  return `Environ ${Math.round(ratio * 100)} % des actions sont en retard.`;
}

/**
 * @param {Array<{ type: string; count: number }>} list
 */
function interpretIncidentTypesList(list) {
  if (!list.length) return '';
  const top = list[0];
  const second = list[1];
  if (second && top.count >= second.count * 1.6) {
    return `Le type « ${top.type} » domine (${top.count} cas) : un focus causes sur ce thème peut payer vite.`;
  }
  return `Répartition hétérogène ; le type le plus fréquent est « ${top.type} » (${top.count}).`;
}

/**
 * @param {{ label: string; value: number }[]} series
 */
export function createDashboardLineChart(series) {
  const wrap = document.createElement('div');
  wrap.className = 'dashboard-line-chart-wrap';

  const safe = Array.isArray(series) && series.length ? series : [{ label: '—', value: 0 }];
  const max = Math.max(1, ...safe.map((p) => (Number.isFinite(p.value) ? p.value : 0)));
  const w = 320;
  const h = 152;
  const pad = 14;
  const n = safe.length;
  const step = n > 1 ? (w - pad * 2) / (n - 1) : 0;
  const pts = safe.map((p, i) => {
    const x = pad + (n === 1 ? (w - pad * 2) / 2 : i * step);
    const y = h - pad - (p.value / max) * (h - pad * 2);
    return { x, y, ...p };
  });
  const d = pts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ');

  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', `0 0 ${w} ${h}`);
  svg.setAttribute('class', 'dashboard-line-chart-svg');
  svg.setAttribute('role', 'img');
  svg.setAttribute(
    'aria-label',
    'Courbe du nombre d’incidents déclarés par mois sur les six derniers mois.'
  );

  const gridBase = document.createElementNS('http://www.w3.org/2000/svg', 'line');
  gridBase.setAttribute('x1', String(pad));
  gridBase.setAttribute('y1', String(h - pad));
  gridBase.setAttribute('x2', String(w - pad));
  gridBase.setAttribute('y2', String(h - pad));
  gridBase.setAttribute('class', 'dashboard-line-chart-grid dashboard-line-chart-grid--base');

  const midY = pad + (h - pad * 2) / 2;
  const gridMid = document.createElementNS('http://www.w3.org/2000/svg', 'line');
  gridMid.setAttribute('x1', String(pad));
  gridMid.setAttribute('y1', String(midY));
  gridMid.setAttribute('x2', String(w - pad));
  gridMid.setAttribute('y2', String(midY));
  gridMid.setAttribute('class', 'dashboard-line-chart-grid dashboard-line-chart-grid--mid');

  const areaPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  const areaD = `${d} L ${pts[pts.length - 1].x} ${h - pad} L ${pts[0].x} ${h - pad} Z`;
  areaPath.setAttribute('d', areaD);
  areaPath.setAttribute('class', 'dashboard-line-chart-area');

  const linePath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  linePath.setAttribute('d', d);
  linePath.setAttribute('fill', 'none');
  linePath.setAttribute('class', 'dashboard-line-chart-line');

  svg.append(gridBase, gridMid, areaPath, linePath);
  pts.forEach((p) => {
    const c = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    c.setAttribute('cx', String(p.x));
    c.setAttribute('cy', String(p.y));
    c.setAttribute('r', '5');
    c.setAttribute('class', 'dashboard-line-chart-dot');
    svg.append(c);
  });

  const valuesRow = document.createElement('div');
  valuesRow.className = 'dashboard-line-chart-values';
  safe.forEach((p) => {
    const s = document.createElement('span');
    s.textContent = String(p.value);
    s.title = `${p.value} incident(s)`;
    valuesRow.append(s);
  });

  const labels = document.createElement('div');
  labels.className = 'dashboard-line-chart-labels';
  safe.forEach((p) => {
    const s = document.createElement('span');
    s.textContent = p.label;
    labels.append(s);
  });

  const foot = document.createElement('p');
  foot.className = 'dashboard-chart-foot dashboard-chart-foot--tight';
  const total = safe.reduce((a, p) => a + p.value, 0);
  foot.textContent = total === 0 ? 'Aucune donnée sur cette période.' : '';

  const interpret = document.createElement('p');
  interpret.className = 'dashboard-chart-interpret';
  interpret.textContent = interpretIncidentTrend(safe);

  wrap.append(svg, valuesRow, labels, foot, interpret);
  return wrap;
}

/**
 * @param {{ overdue: number; done: number; other: number }} parts
 */
export function createActionsMixChart(parts) {
  const wrap = document.createElement('div');
  wrap.className = 'dashboard-mix-chart-wrap';

  const o = Math.max(0, Number(parts.overdue) || 0);
  const d = Math.max(0, Number(parts.done) || 0);
  const r = Math.max(0, Number(parts.other) || 0);
  const sum = o + d + r || 1;

  const bar = document.createElement('div');
  bar.className = 'dashboard-mix-bar';
  bar.setAttribute('role', 'img');
  bar.setAttribute('aria-label', 'Répartition des actions : en retard, terminées, autres statuts.');

  const segO = document.createElement('div');
  segO.className = 'dashboard-mix-seg dashboard-mix-seg--overdue';
  segO.style.flex = `${(o / sum) * 100}`;
  segO.title = `En retard : ${o}`;

  const segD = document.createElement('div');
  segD.className = 'dashboard-mix-seg dashboard-mix-seg--done';
  segD.style.flex = `${(d / sum) * 100}`;
  segD.title = `Terminées : ${d}`;

  const segR = document.createElement('div');
  segR.className = 'dashboard-mix-seg dashboard-mix-seg--other';
  segR.style.flex = `${(r / sum) * 100}`;
  segR.title = `Autres : ${r}`;

  bar.append(segO, segD, segR);

  const legend = document.createElement('ul');
  legend.className = 'dashboard-mix-legend';
  [
    { label: 'En retard', value: o, cls: 'dashboard-mix-dot--overdue' },
    { label: 'Terminées / clos', value: d, cls: 'dashboard-mix-dot--done' },
    { label: 'En cours / autre', value: r, cls: 'dashboard-mix-dot--other' }
  ].forEach(({ label, value, cls }) => {
    const li = document.createElement('li');
    li.className = 'dashboard-mix-legend-item';
    const dot = document.createElement('span');
    dot.className = `dashboard-mix-dot ${cls}`;
    const txt = document.createElement('span');
    txt.textContent = `${label} — ${value}`;
    li.append(dot, txt);
    legend.append(li);
  });

  const foot = document.createElement('p');
  foot.className = 'dashboard-chart-foot dashboard-mix-foot';
  foot.textContent = '';

  const interpret = document.createElement('p');
  interpret.className = 'dashboard-chart-interpret';
  interpret.textContent = interpretActionsMixParts({ overdue: o, done: d, other: r });

  wrap.append(bar, legend, foot, interpret);
  return wrap;
}

/**
 * @param {Array<{ type: string; count: number }>} entries max 5
 */
export function createIncidentTypeBreakdown(entries) {
  const wrap = document.createElement('div');
  wrap.className = 'dashboard-breakdown-wrap';

  const list = Array.isArray(entries) ? entries.slice(0, 5) : [];
  const max = Math.max(1, ...list.map((e) => Number(e.count) || 0));

  if (!list.length) {
    const p = document.createElement('p');
    p.className = 'dashboard-situation-note';
    p.textContent = 'Aucune donnée sur cette période.';
    wrap.append(p);
    return wrap;
  }

  list.forEach((e) => {
    const row = document.createElement('div');
    row.className = 'dashboard-breakdown-row';
    const lab = document.createElement('div');
    lab.className = 'dashboard-breakdown-label';
    lab.textContent = e.type || '—';
    const track = document.createElement('div');
    track.className = 'dashboard-breakdown-track';
    const fill = document.createElement('div');
    fill.className = 'dashboard-breakdown-fill';
    const c = Number(e.count) || 0;
    fill.style.width = `${Math.round((c / max) * 100)}%`;
    const num = document.createElement('span');
    num.className = 'dashboard-breakdown-count';
    num.textContent = String(c);
    track.append(fill);
    row.append(lab, track, num);
    wrap.append(row);
  });

  const foot = document.createElement('p');
  foot.className = 'dashboard-chart-foot dashboard-chart-foot--tight';
  foot.textContent = '';

  const interpret = document.createElement('p');
  interpret.className = 'dashboard-chart-interpret';
  interpret.textContent = interpretIncidentTypesList(list);

  wrap.append(foot, interpret);

  return wrap;
}

/**
 * @param {Array<{ status?: string }>} actions
 */
export function classifyActionsForMix(actions) {
  if (!Array.isArray(actions)) return { overdue: 0, done: 0, other: 0 };
  let overdue = 0;
  let done = 0;
  let other = 0;
  actions.forEach((a) => {
    const s = String(a?.status || '').toLowerCase();
    if (s.includes('retard')) overdue += 1;
    else if (
      /termin|clos|ferm|clôtur|realis|réalis|effectu|complete|complété|fait/.test(s)
    )
      done += 1;
    else other += 1;
  });
  return { overdue, done, other };
}

/**
 * @param {Array<{ type?: string }>} incidents
 */
export function buildTopIncidentTypes(incidents, take = 5) {
  if (!Array.isArray(incidents)) return [];
  const map = new Map();
  incidents.forEach((inc) => {
    const t = String(inc?.type || 'Autre').trim() || 'Autre';
    map.set(t, (map.get(t) || 0) + 1);
  });
  return [...map.entries()]
    .map(([type, count]) => ({ type, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, take);
}
