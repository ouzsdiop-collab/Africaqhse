import { parseActionMeta } from './actionMeta.js';
import { showToast } from './toast.js';

function formatDueShort(iso) {
  if (!iso) return null;
  try {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return null;
    return d.toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  } catch {
    return null;
  }
}

/**
 * @param {string} columnKey
 * @param {string | null | undefined} dueIso
 */
function computePriorityBadge(columnKey, dueIso) {
  if (columnKey === 'overdue') {
    return { label: 'Retard', mod: 'action-card__prio--danger' };
  }
  if (columnKey === 'done') {
    return { label: 'Terminé', mod: 'action-card__prio--ok' };
  }
  if (dueIso) {
    const d = new Date(dueIso);
    if (!Number.isNaN(d.getTime())) {
      const now = Date.now();
      const ms = d.getTime() - now;
      const days = ms / 86400000;
      if (days < 0) return { label: 'Date dépassée', mod: 'action-card__prio--danger' };
      if (days <= 3) return { label: 'Urgent', mod: 'action-card__prio--warn' };
      if (days <= 14) return { label: 'Priorité normale', mod: 'action-card__prio--info' };
    }
  }
  return { label: 'Planifié', mod: 'action-card__prio--neutral' };
}

/**
 * Clé pour filtre client « priorité » (hors colonne Terminé).
 * @param {string} columnKey
 * @param {string | null | undefined} dueIso
 * @returns {'retard'|'urgent'|'normal'|'planifie'}
 */
export function getActionPriorityFilterKey(columnKey, dueIso) {
  if (columnKey === 'overdue') return 'retard';
  if (columnKey === 'done') return 'planifie';
  if (dueIso) {
    const d = new Date(dueIso);
    if (!Number.isNaN(d.getTime())) {
      const days = (d.getTime() - Date.now()) / 86400000;
      if (days < 0) return 'retard';
      if (days <= 3) return 'urgent';
      if (days <= 14) return 'normal';
    }
  }
  return 'planifie';
}

function statusPillClass(columnKey) {
  if (columnKey === 'overdue') return 'action-card__status action-card__status--overdue';
  if (columnKey === 'doing') return 'action-card__status action-card__status--doing';
  if (columnKey === 'done') return 'action-card__status action-card__status--done';
  return 'action-card__status action-card__status--todo';
}

/**
 * Carte action Kanban — lecture claire + actions rapides (détail ; terminer / modifier limités par API).
 * @param {object} item — title, detail, actionId, assigneeId, assigneeName, users, onAssign, canAssign,
 *   dueDateIso?, statusLabel?, rawRow?, onOpenDetail?(row, columnKey)
 * @param {string} columnKey
 */
export function createActionKanbanCard(item, columnKey) {
  const card = document.createElement('article');
  card.className = `action-card action-card--v2 action-card--col-${columnKey}`;

  const parsed = parseActionMeta(item.detail || '');
  const { site } = parsed;
  const hasNamedAssignee =
    item.assigneeName != null && String(item.assigneeName).trim() !== '';
  const displayOwner = (hasNamedAssignee ? String(item.assigneeName).trim() : parsed.owner) || '—';

  const dueFormatted = formatDueShort(item.dueDateIso) || parsed.echeance;
  const prio = computePriorityBadge(columnKey, item.dueDateIso);

  const top = document.createElement('div');
  top.className = 'action-card__top';

  const title = document.createElement('h4');
  title.className = 'action-card__title';
  title.textContent = item.title;

  const prioEl = document.createElement('span');
  prioEl.className = `action-card__prio ${prio.mod}`;
  prioEl.textContent = prio.label;

  top.append(title, prioEl);

  const statusEl = document.createElement('span');
  statusEl.className = statusPillClass(columnKey);
  statusEl.textContent = item.statusLabel || '—';

  const meta = document.createElement('div');
  meta.className = 'action-card__meta';

  const ownerRow = document.createElement('div');
  ownerRow.className = 'action-card__meta-row';
  ownerRow.innerHTML = `<span class="action-card__meta-k">Responsable</span><span class="action-card__meta-v">${escapeAttr(displayOwner)}</span>`;

  const dueRow = document.createElement('div');
  dueRow.className = 'action-card__meta-row action-card__meta-row--due';
  const dueClass =
    columnKey === 'overdue' || (item.dueDateIso && new Date(item.dueDateIso) < new Date())
      ? 'action-card__meta-v action-card__meta-v--late'
      : 'action-card__meta-v';
  dueRow.innerHTML = `<span class="action-card__meta-k">Échéance</span><span class="${dueClass}">${escapeAttr(dueFormatted || '—')}</span>`;

  const siteRow = document.createElement('div');
  siteRow.className = 'action-card__meta-row';
  siteRow.innerHTML = `<span class="action-card__meta-k">Périmètre</span><span class="action-card__meta-v">${escapeAttr(site)}</span>`;

  meta.append(ownerRow, dueRow, siteRow);

  const actions = document.createElement('div');
  actions.className = 'action-card__quick';

  const btnDetail = document.createElement('button');
  btnDetail.type = 'button';
  btnDetail.className = 'action-card__quick-btn';
  btnDetail.textContent = 'Voir le détail';
  btnDetail.addEventListener('click', () => {
    if (typeof item.onOpenDetail === 'function' && item.rawRow) {
      item.onOpenDetail(item.rawRow, columnKey);
    }
  });

  const btnEdit = document.createElement('button');
  btnEdit.type = 'button';
  btnEdit.className = 'action-card__quick-btn';
  btnEdit.textContent = 'Modifier';
  btnEdit.title =
    'Consultation : la mise à jour complète nécessite une évolution API (PATCH action).';
  btnEdit.addEventListener('click', () => {
    if (typeof item.onOpenEdit === 'function' && item.rawRow) {
      item.onOpenEdit(item.rawRow, columnKey);
    } else if (typeof item.onOpenDetail === 'function' && item.rawRow) {
      item.onOpenDetail(item.rawRow, columnKey);
      showToast('Modification en ligne : prévoir endpoint API dédié.', 'info');
    }
  });

  const btnDone = document.createElement('button');
  btnDone.type = 'button';
  btnDone.className = 'action-card__quick-btn action-card__quick-btn--primary';
  btnDone.textContent = 'Terminer';
  btnDone.disabled = columnKey === 'done';
  btnDone.title =
    columnKey === 'done'
      ? 'Action déjà terminée'
      : 'Le passage au statut « terminé » nécessite une API de mise à jour (non exposée ici).';
  btnDone.addEventListener('click', () => {
    showToast(
      'Clôture : à brancher sur PATCH /api/actions/:id (statut) — non disponible dans cette version.',
      'info'
    );
  });

  actions.append(btnDetail, btnEdit, btnDone);

  card.append(top, statusEl, meta, actions);

  if (
    item.canAssign !== false &&
    item.actionId &&
    Array.isArray(item.users) &&
    typeof item.onAssign === 'function'
  ) {
    const assignWrap = document.createElement('div');
    assignWrap.className = 'action-card__assign-wrap';
    const lab = document.createElement('label');
    lab.className = 'action-card__assign-label';
    lab.htmlFor = `assign-${item.actionId}`;
    lab.textContent = 'Réassigner';
    const sel = document.createElement('select');
    sel.id = `assign-${item.actionId}`;
    sel.className = 'action-card__assign-select';
    sel.setAttribute('aria-label', 'Assigner un responsable');

    const optNone = document.createElement('option');
    optNone.value = '';
    optNone.textContent = 'Non assigné';
    sel.append(optNone);

    item.users.forEach((u) => {
      const o = document.createElement('option');
      o.value = u.id;
      o.textContent = `${u.name} (${u.role})`;
      if (item.assigneeId && u.id === item.assigneeId) o.selected = true;
      sel.append(o);
    });

    if (item.assigneeId && !item.users.some((u) => u.id === item.assigneeId)) {
      const o = document.createElement('option');
      o.value = item.assigneeId;
      o.textContent = item.assigneeName || 'Responsable (hors liste)';
      o.selected = true;
      sel.append(o);
    }

    sel.addEventListener('change', () => {
      item.onAssign(item.actionId, sel.value || null);
    });

    assignWrap.append(lab, sel);
    card.append(assignWrap);
  }

  return card;
}

function escapeAttr(s) {
  const t = String(s ?? '');
  return t
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
