const STYLE_ID = 'qhse-audit-plus-styles';

const CSS = `
.audit-plus-page .audit-kpi-strip{margin-bottom:14px}
.audit-last-card .audit-last-lead{margin:0}
.audit-plan-card{margin-bottom:14px}
.audit-plan-table-wrap{overflow-x:auto;margin-top:10px;border-radius:12px;border:1px solid rgba(148,163,184,.1)}
.audit-plan-table{min-width:640px;display:grid;gap:0}
.audit-plan-head,.audit-plan-row{display:grid;grid-template-columns:minmax(100px,0.9fr) minmax(120px,1.1fr) minmax(100px,0.85fr) minmax(90px,0.75fr) minmax(100px,0.9fr);gap:8px;padding:10px 12px;align-items:center;font-size:12px}
.audit-plan-head{font-weight:800;letter-spacing:.06em;text-transform:uppercase;color:var(--text3);background:rgba(0,0,0,.18);border-bottom:1px solid rgba(148,163,184,.12)}
.audit-plan-row{border-bottom:1px solid rgba(148,163,184,.08)}
.audit-plan-row:last-child{border-bottom:none}
.audit-plan-ref{font-weight:700;color:var(--text)}
.audit-plan-actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px;justify-content:flex-end}
.audit-last-progress{margin-top:14px}
.audit-last-progress-top{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:6px;font-size:12px;color:var(--text2)}
.audit-progress-bar{height:8px;border-radius:999px;background:rgba(255,255,255,.08);overflow:hidden}
.audit-progress-bar > span{display:block;height:100%;border-radius:999px;background:linear-gradient(90deg,rgba(77,160,255,.9),rgba(52,211,153,.85))}
.audit-last-status-row{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-top:10px}
.audit-last-status-row .badge{font-size:11px}
.audit-field-panel{margin-top:14px;padding:0;border-radius:14px;border:1px solid rgba(77,160,255,.22);background:rgba(77,160,255,.04);overflow:hidden}
.audit-field-panel[hidden]{display:none!important}
.audit-field-panel-head{padding:14px 16px;border-bottom:1px solid rgba(148,163,184,.12);background:rgba(0,0,0,.12)}
.audit-field-panel-head h4{margin:0 0 4px;font-size:15px;font-weight:800}
.audit-field-panel-head p{margin:0;font-size:13px;color:var(--text2);line-height:1.45}
.audit-field-stack{padding:14px 16px;display:grid;gap:12px}
.audit-field-item{border-radius:12px;border:1px solid rgba(148,163,184,.12);background:rgba(0,0,0,.1);padding:12px 14px}
.audit-field-item__title{margin:0 0 10px;font-size:14px;font-weight:700;line-height:1.35;color:var(--text)}
.audit-field-toggles{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:10px}
.audit-field-toggles button{min-height:38px;padding:0 14px;border-radius:10px;border:1px solid rgba(148,163,184,.2);background:rgba(0,0,0,.15);color:var(--text);font-size:12px;font-weight:700;cursor:pointer}
.audit-field-toggles button.is-on.conforme{border-color:rgba(52,211,153,.45)!important;background:rgba(52,211,153,.12)!important;color:#86efac!important}
.audit-field-toggles button.is-on.nonconforme{border-color:rgba(239,91,107,.45)!important;background:rgba(239,91,107,.1)!important;color:#fecaca!important}
.audit-field-comment{width:100%;min-height:56px;padding:8px 10px;border-radius:10px;border:1px solid rgba(148,163,184,.18);background:rgba(0,0,0,.2);color:var(--text);font-size:13px;resize:vertical;box-sizing:border-box}
.audit-nc-block{margin-top:14px;padding:14px 16px;border-top:1px solid rgba(148,163,184,.1);background:rgba(239,91,107,.05)}
.audit-nc-block h5{margin:0 0 10px;font-size:11px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:#fecaca}
.audit-nc-list{display:grid;gap:10px}
.audit-nc-card{border-radius:12px;border:1px solid rgba(239,91,107,.35);background:rgba(0,0,0,.2);padding:12px 14px;display:grid;gap:8px}
.audit-nc-card__ref{font-size:11px;font-weight:800;letter-spacing:.06em;color:#fca5a5}
.audit-nc-card__text{font-size:13px;line-height:1.45;color:var(--text2);margin:0}
.audit-nc-card__actions{display:flex;flex-wrap:wrap;gap:8px;justify-content:flex-end}
.audit-main-actions{display:flex;flex-wrap:wrap;gap:10px;justify-content:flex-end;margin-top:14px;align-items:center}
@media (max-width:900px){
  .audit-plan-head{display:none}
  .audit-plan-row{grid-template-columns:1fr;gap:6px;padding:12px}
}
`;

export function ensureAuditPlusStyles() {
  if (document.getElementById(STYLE_ID)) return;
  const el = document.createElement('style');
  el.id = STYLE_ID;
  el.textContent = CSS;
  document.head.append(el);
}
