import { navigationGroups, siteOptions } from '../data/navigation.js';
import { appState } from '../utils/state.js';
import { fetchSitesCatalog } from '../services/sitesCatalog.service.js';
import {
  getSessionUser,
  setSessionUser,
  getAuthToken,
  clearAuthSession
} from '../data/sessionUser.js';
import { qhseFetch } from '../utils/qhseFetch.js';
import { canAccessNavPage } from '../utils/permissionsUi.js';

const STYLE_ID = 'qhse-sidebar-v2-styles';

function ensureSidebarV2Styles() {
  if (document.getElementById(STYLE_ID)) return;
  const el = document.createElement('style');
  el.id = STYLE_ID;
  el.textContent = `
.sidebar-v2 {
  width: 280px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  min-height: 100dvh;
  max-height: 100dvh;
  position: sticky;
  top: 0;
  align-self: flex-start;
  z-index: var(--z-sidebar);
  background: var(--color-surface);
  border-right: 1px solid var(--color-border);
  box-shadow: var(--shadow-sm);
  font-family: var(--font-body);
}
.sidebar-v2__brand {
  flex-shrink: 0;
  display: flex;
  align-items: center;
  gap: var(--space-3);
  padding: var(--space-4) var(--space-4) var(--space-5);
  border-bottom: 1px solid var(--color-border);
}
.sidebar-v2__brand-mark {
  width: 44px;
  height: 44px;
  border-radius: var(--radius-md);
  display: grid;
  place-items: center;
  flex-shrink: 0;
  color: var(--color-primary-text);
  background: var(--color-primary-bg);
  border: 1px solid var(--color-primary-border);
}
.sidebar-v2__brand-mark svg {
  width: 24px;
  height: 24px;
}
.sidebar-v2__brand-text {
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
}
.sidebar-v2__brand-title {
  font-family: 'Inter', var(--font-body);
  font-size: 15px;
  font-weight: 500;
  line-height: 1.25;
  color: var(--color-text);
  letter-spacing: -0.02em;
}
.sidebar-v2__brand-badge {
  font-size: 9px;
  font-weight: 600;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  padding: var(--space-1) var(--space-2);
  border-radius: var(--radius-sm);
  border: 1px solid var(--color-border);
  color: var(--color-text-muted);
  background: var(--color-subtle);
  align-self: flex-start;
}
.sidebar-v2__nav {
  flex: 1 1 0%;
  min-height: 0;
  overflow-x: hidden;
  overflow-y: auto;
  padding: var(--space-3) var(--space-2) var(--space-4);
  scrollbar-width: thin;
  scrollbar-color: var(--color-border) transparent;
}
.sidebar-v2__group {
  margin-bottom: var(--space-5);
}
.sidebar-v2__group:last-child {
  margin-bottom: 0;
}
.sidebar-v2__group-label {
  margin: 0 0 var(--space-2) var(--space-2);
  font-size: 11px;
  font-weight: 600;
  line-height: 1.2;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: var(--color-text-muted);
}
.sidebar-v2__items {
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
}
.sidebar-v2__item {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  width: 100%;
  text-align: left;
  border: none;
  border-radius: var(--radius-md);
  padding: var(--space-2) var(--space-3);
  padding-left: calc(var(--space-3) + 3px);
  margin: 0;
  font-family: inherit;
  font-size: 14px;
  font-weight: 500;
  color: var(--color-text-secondary);
  background: transparent;
  cursor: pointer;
  position: relative;
  transition: background 150ms ease, color 150ms ease, box-shadow 150ms ease;
}
.sidebar-v2__item::before {
  content: '';
  position: absolute;
  left: 0;
  top: 50%;
  transform: translateY(-50%);
  width: 3px;
  height: 0;
  border-radius: 0 2px 2px 0;
  background: var(--color-primary-text);
  opacity: 0;
  transition: height 150ms ease, opacity 150ms ease;
}
.sidebar-v2__item:hover {
  background: var(--color-subtle);
  color: var(--color-text);
}
.sidebar-v2__item--active {
  color: var(--color-text);
  background: var(--color-primary-bg);
}
.sidebar-v2__item--active::before {
  height: 60%;
  min-height: 20px;
  opacity: 1;
}
.sidebar-v2__item-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  color: inherit;
  opacity: 0.9;
}
.sidebar-v2__item-icon .shell-nav-svg {
  width: 20px;
  height: 20px;
}
.sidebar-v2__footer {
  flex-shrink: 0;
  padding: var(--space-4);
  border-top: 1px solid var(--color-border);
  display: flex;
  flex-direction: column;
  gap: var(--space-4);
  background: var(--color-subtle);
}
.sidebar-v2__footer-label {
  display: block;
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--color-text-muted);
  margin-bottom: var(--space-2);
}
.sidebar-v2__context .control-select,
.sidebar-v2 .shell-account-slot > .control-select {
  width: 100%;
  border-radius: var(--radius-md);
  border: 1px solid var(--color-border);
  background: var(--color-surface);
  color: var(--color-text);
  padding: var(--space-2) var(--space-3);
  font-family: inherit;
  font-size: 13px;
}
.sidebar-v2 .shell-account-actions {
  display: flex;
  flex-direction: column;
  gap: 0;
}
.sidebar-v2__account-card {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  padding: var(--space-3);
  border-radius: var(--radius-md);
  border: 1px solid var(--color-border);
  background: var(--color-surface);
}
.sidebar-v2__account-avatar {
  width: 40px;
  height: 40px;
  border-radius: var(--radius-md);
  display: grid;
  place-items: center;
  font-size: 13px;
  font-weight: 700;
  color: var(--color-primary-text);
  background: var(--color-primary-bg);
  border: 1px solid var(--color-primary-border);
  flex-shrink: 0;
}
.sidebar-v2__account-meta {
  min-width: 0;
  flex: 1;
}
.sidebar-v2__account-name {
  font-size: 14px;
  font-weight: 600;
  color: var(--color-text);
  line-height: 1.3;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.sidebar-v2__account-role {
  font-size: 12px;
  color: var(--color-text-muted);
  margin-top: var(--space-1);
  text-transform: uppercase;
  letter-spacing: 0.04em;
}
.sidebar-v2__btn-logout {
  width: 100%;
  margin-top: var(--space-3);
  padding: var(--space-2) var(--space-3);
  border-radius: var(--radius-md);
  border: 1px solid var(--color-border);
  background: transparent;
  color: var(--color-text-secondary);
  font-family: inherit;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  transition: background 150ms ease, border-color 150ms ease, color 150ms ease;
}
.sidebar-v2__btn-logout:hover {
  background: var(--color-surface);
  border-color: var(--color-primary-border);
  color: var(--color-text);
}
.sidebar-v2__btn-ghost {
  width: 100%;
  margin-top: var(--space-2);
  padding: var(--space-2) var(--space-3);
  border-radius: var(--radius-md);
  border: 1px solid var(--color-border);
  background: var(--color-surface);
  color: var(--color-text-secondary);
  font-family: inherit;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  transition: background 150ms ease, color 150ms ease;
}
.sidebar-v2__btn-ghost:hover {
  background: var(--color-subtle);
  color: var(--color-text);
}
.sidebar-v2__btn-link {
  display: block;
  width: 100%;
  margin-top: var(--space-2);
  padding: var(--space-1) 0;
  border: none;
  background: none;
  font-family: inherit;
  font-size: 12px;
  font-weight: 500;
  color: var(--color-info-text);
  text-decoration: underline;
  text-underline-offset: 3px;
  cursor: pointer;
  transition: color 150ms ease;
}
.sidebar-v2__btn-link:hover {
  color: var(--color-primary-text);
}
`;
  document.head.append(el);
}

/** Icônes SVG 20×20, stroke — cohérentes et sobres. */
const NAV_ICON_SVG = {
  dashboard:
    '<svg class="shell-nav-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/></svg>',
  sites:
    '<svg class="shell-nav-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 21h18"/><path d="M5 21V7l8-4v18"/><path d="M19 21V11l-6-4"/><path d="M9 9v.01"/><path d="M9 12v.01"/><path d="M9 15v.01"/><path d="M9 18v.01"/></svg>',
  incidents:
    '<svg class="shell-nav-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>',
  risks:
    '<svg class="shell-nav-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
  actions:
    '<svg class="shell-nav-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="M22 4L12 14.01l-3-3"/></svg>',
  iso:
    '<svg class="shell-nav-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>',
  audits:
    '<svg class="shell-nav-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M9 15l2 2 4-4"/></svg>',
  products:
    '<svg class="shell-nav-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>',
  imports:
    '<svg class="shell-nav-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>',
  'activity-log':
    '<svg class="shell-nav-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>',
  analytics:
    '<svg class="shell-nav-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>',
  'ai-center':
    '<svg class="shell-nav-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 2a4 4 0 0 1 4 4v2a4 4 0 0 1-8 0V6a4 4 0 0 1 4-4z"/><path d="M16 14v2a4 4 0 0 1-8 0v-2"/><path d="M8 10h8"/><path d="M12 18v4"/></svg>'
};

const SHIELD_LOGO_SVG = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>`;

function navIconFor(id) {
  return NAV_ICON_SVG[id] || NAV_ICON_SVG.dashboard;
}

export function createSidebar({
  currentPage,
  onNavigate,
  onSiteChange,
  onSessionUserChange
}) {
  ensureSidebarV2Styles();

  const aside = document.createElement('aside');
  aside.className = 'sidebar-v2';

  aside.innerHTML = `
    <div class="sidebar-v2__brand">
      <div class="sidebar-v2__brand-mark" aria-hidden="true">${SHIELD_LOGO_SVG}</div>
      <div class="sidebar-v2__brand-text">
        <span class="sidebar-v2__brand-title">QHSE Control</span>
        <span class="sidebar-v2__brand-badge" title="Démonstration">Démo</span>
      </div>
    </div>
    <nav class="sidebar-v2__nav" aria-label="Navigation principale"></nav>
    <div class="sidebar-v2__footer">
      <div class="sidebar-v2__block">
        <span class="sidebar-v2__footer-label">Périmètre</span>
        <div class="sidebar-v2__context context-card"></div>
      </div>
      <div class="sidebar-v2__block sidebar-v2__block--account">
        <span class="sidebar-v2__footer-label">Compte</span>
        <div class="shell-account-slot"></div>
      </div>
    </div>
  `;

  const select = document.createElement('select');
  select.className = 'control-select context-select shell-context-select';
  select.setAttribute('aria-label', 'Choisir le site ou la vue groupe');

  function syncContextSelectFromState() {
    const id = appState.activeSiteId;
    if (id) {
      const hit = [...select.options].find((o) => o.value === id);
      if (hit) {
        select.value = id;
        return;
      }
    }
    const legacy = [...select.options].find(
      (o) => o.dataset.legacy === '1' && o.textContent === appState.currentSite
    );
    if (legacy) {
      select.value = legacy.value;
      return;
    }
    select.value = '';
  }

  async function loadContextSiteOptions() {
    select.innerHTML = '';
    const groupe = document.createElement('option');
    groupe.value = '';
    groupe.textContent = 'Vue groupe (tous sites)';
    select.append(groupe);

    let fromApi = false;
    try {
      const list = await fetchSitesCatalog();
      if (Array.isArray(list) && list.length > 0) {
        fromApi = true;
        list.forEach((s) => {
          if (!s?.id) return;
          const o = document.createElement('option');
          o.value = s.id;
          o.textContent = s.code ? `${s.name} (${s.code})` : s.name;
          select.append(o);
        });
      }
    } catch {
      /* ignore */
    }

    if (!fromApi) {
      siteOptions.forEach((label) => {
        const o = document.createElement('option');
        o.value = `leg:${encodeURIComponent(label)}`;
        o.textContent = label;
        o.dataset.legacy = '1';
        select.append(o);
      });
    }

    syncContextSelectFromState();
  }

  select.addEventListener('change', () => {
    const v = select.value;
    const opt = select.selectedOptions[0];
    const label = opt ? opt.textContent.trim() : '';
    if (!v) {
      onSiteChange(null, 'Vue groupe (tous sites)');
      return;
    }
    if (v.startsWith('leg:')) {
      try {
        onSiteChange(null, decodeURIComponent(v.slice(4)));
      } catch {
        onSiteChange(null, label);
      }
      return;
    }
    onSiteChange(v, label);
  });

  aside.querySelector('.context-card').append(select);
  loadContextSiteOptions();

  const profileSlot = aside.querySelector('.shell-account-slot');

  function mountAuthProfile() {
    profileSlot.replaceChildren();
    const token = getAuthToken();

    if (token) {
      const u = getSessionUser();
      const card = document.createElement('div');
      card.className = 'sidebar-v2__account-card';
      const av = document.createElement('div');
      av.className = 'sidebar-v2__account-avatar';
      const initials = (u?.name || 'U')
        .split(/\s+/)
        .map((p) => p[0])
        .join('')
        .slice(0, 2)
        .toUpperCase();
      av.textContent = initials;
      const meta = document.createElement('div');
      meta.className = 'sidebar-v2__account-meta';
      const nameEl = document.createElement('div');
      nameEl.className = 'sidebar-v2__account-name';
      nameEl.textContent = u?.name || 'Utilisateur';
      const roleEl = document.createElement('div');
      roleEl.className = 'sidebar-v2__account-role';
      roleEl.textContent = u?.role || '';
      meta.append(nameEl, roleEl);
      card.append(av, meta);
      profileSlot.append(card);

      const actions = document.createElement('div');
      actions.className = 'shell-account-actions';
      const logoutBtn = document.createElement('button');
      logoutBtn.type = 'button';
      logoutBtn.className = 'sidebar-v2__btn-logout';
      logoutBtn.textContent = 'Déconnexion';
      logoutBtn.addEventListener('click', () => {
        qhseFetch('/api/auth/logout', { method: 'POST' }).catch(() => {});
        clearAuthSession();
        if (typeof onSessionUserChange === 'function') onSessionUserChange();
      });
      const switchBtn = document.createElement('button');
      switchBtn.type = 'button';
      switchBtn.className = 'sidebar-v2__btn-link';
      switchBtn.textContent = 'Changer de compte';
      switchBtn.addEventListener('click', () => {
        qhseFetch('/api/auth/logout', { method: 'POST' }).catch(() => {});
        clearAuthSession();
        if (typeof onSessionUserChange === 'function') onSessionUserChange();
        window.location.hash = 'login';
      });
      actions.append(logoutBtn, switchBtn);
      profileSlot.append(actions);
      return;
    }

    const profileSelect = document.createElement('select');
    profileSelect.className = 'control-select context-select shell-context-select';
    profileSelect.setAttribute('aria-label', 'Choisir un utilisateur pour les permissions');
    profileSelect.title = 'Profil démo : filtre les entrées du menu selon le rôle.';
    const optProf0 = document.createElement('option');
    optProf0.value = '';
    optProf0.textContent = '— Mode libre —';
    profileSelect.append(optProf0);
    profileSlot.append(profileSelect);

    (async function loadProfileUsers() {
      try {
        const res = await qhseFetch('/api/users');
        if (!res.ok) return;
        const list = await res.json();
        if (!Array.isArray(list)) return;
        list.forEach((userRow) => {
          if (!userRow?.id) return;
          const o = document.createElement('option');
          o.value = userRow.id;
          o.textContent = `${userRow.name} (${userRow.role})`;
          profileSelect.append(o);
        });
        const cur = getSessionUser();
        if (cur && list.some((x) => x.id === cur.id)) {
          profileSelect.value = cur.id;
        }
      } catch {
        /* ignore */
      }
    })();

    profileSelect.addEventListener('change', () => {
      const id = profileSelect.value;
      if (!id) {
        setSessionUser(null);
      } else {
        const opt = profileSelect.selectedOptions[0];
        const name = opt ? opt.textContent.replace(/\s*\([^)]+\)\s*$/, '').trim() : '';
        const roleMatch = /\(([^)]+)\)\s*$/.exec(opt?.textContent || '');
        const role = roleMatch ? roleMatch[1].trim() : 'TERRAIN';
        setSessionUser({ id, name, role });
      }
      if (typeof onSessionUserChange === 'function') onSessionUserChange();
    });

    const loginNav = document.createElement('button');
    loginNav.type = 'button';
    loginNav.className = 'sidebar-v2__btn-ghost';
    loginNav.textContent = 'Connexion';
    loginNav.addEventListener('click', () => {
      window.location.hash = 'login';
    });
    profileSlot.append(loginNav);
  }

  mountAuthProfile();

  const nav = aside.querySelector('.sidebar-v2__nav');

  navigationGroups.forEach((group) => {
    const section = document.createElement('section');
    section.className = 'sidebar-v2__group';

    const title = document.createElement('p');
    title.className = 'sidebar-v2__group-label';
    title.textContent = group.label;
    section.append(title);

    const list = document.createElement('div');
    list.className = 'sidebar-v2__items';

    const role = getSessionUser()?.role;

    group.items.forEach((item) => {
      if (!canAccessNavPage(role, item.id)) return;
      const button = document.createElement('button');
      button.type = 'button';
      const isActive = currentPage === item.id;
      button.className = `sidebar-v2__item${isActive ? ' sidebar-v2__item--active' : ''}`;
      button.setAttribute('aria-current', isActive ? 'page' : 'false');

      const iconWrap = document.createElement('span');
      iconWrap.className = 'sidebar-v2__item-icon';
      iconWrap.innerHTML = navIconFor(item.id);

      const text = document.createElement('span');
      text.className = 'sidebar-v2__item-text';
      text.textContent = item.label;

      button.append(iconWrap, text);
      button.addEventListener('click', () => onNavigate(item.id));
      list.append(button);
    });

    section.append(list);
    nav.append(section);
  });

  return aside;
}
