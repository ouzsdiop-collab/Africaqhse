const STYLE_ID = 'qhse-pilotage-module-styles';

const CSS = `
/* —— Page Risques : structure & blocs —— */
.risks-page{display:flex;flex-direction:column;gap:1.5rem}
.risks-page__kpi{
  padding:16px 18px;
  border-radius:16px;
  border:1px solid rgba(255,255,255,.08);
  background:linear-gradient(165deg,rgba(255,255,255,.045) 0%,rgba(255,255,255,.02) 100%);
  box-shadow:0 1px 0 rgba(255,255,255,.04) inset;
}
[data-theme='dark'] .risks-page__kpi{
  border-color:rgba(240,246,252,.1);
  background:linear-gradient(165deg,rgba(30,38,52,.65) 0%,rgba(18,24,32,.5) 100%);
}
.risks-page__insights{
  padding:18px 20px 20px;
  border-radius:16px;
  border:1px solid rgba(255,255,255,.08);
  background:linear-gradient(165deg,rgba(255,255,255,.04) 0%,rgba(255,255,255,.015) 100%);
  box-shadow:0 1px 0 rgba(255,255,255,.04) inset;
  min-width:0;
}
[data-theme='dark'] .risks-page__insights{
  border-color:rgba(240,246,252,.1);
  background:linear-gradient(165deg,rgba(28,36,48,.55) 0%,rgba(16,22,30,.45) 100%);
}
.risks-insights__head{
  display:flex;
  flex-wrap:wrap;
  align-items:flex-start;
  justify-content:space-between;
  gap:16px 24px;
  margin-bottom:18px;
}
.risks-insights__intro{min-width:0;flex:1;max-width:52ch}
.risks-insights__title{margin:4px 0 6px;font-size:1.1rem;font-weight:800;letter-spacing:-.02em;line-height:1.25;color:var(--text)}
.risks-insights__lead{margin:0;font-size:12.5px;line-height:1.5;color:var(--text2)}
.risks-insights__kpi-inline{display:flex;flex-wrap:wrap;gap:10px}
.risks-insights__kpi-item{
  min-width:140px;
  padding:10px 14px;
  border-radius:12px;
  border:1px solid rgba(255,255,255,.08);
  background:rgba(0,0,0,.12);
  display:flex;
  flex-direction:column;
  gap:2px;
}
.risks-insights__kpi-item--alert{border-color:rgba(239,91,107,.22);background:rgba(239,91,107,.06)}
.risks-insights__kpi-value{font-size:22px;font-weight:800;font-variant-numeric:tabular-nums;line-height:1;color:var(--text)}
.risks-insights__kpi-item--alert .risks-insights__kpi-value{color:#fca5a5}
.risks-insights__kpi-label{font-size:11px;font-weight:800;color:var(--text)}
.risks-insights__kpi-hint{font-size:10px;color:var(--text3);line-height:1.3}
.risks-insights__bar-wrap{margin-bottom:16px}
.risks-insights__bar{
  display:flex;
  height:8px;
  border-radius:999px;
  overflow:hidden;
  background:rgba(255,255,255,.06);
  border:1px solid rgba(255,255,255,.06);
}
.risks-insights__bar-seg{min-width:0;transition:width .25s ease}
.risks-insights__bar-seg--crit{background:linear-gradient(90deg,rgba(239,91,107,.85),rgba(239,91,107,.55))}
.risks-insights__bar-seg--elev{background:linear-gradient(90deg,rgba(243,179,79,.9),rgba(243,179,79,.55))}
.risks-insights__bar-seg--mod{background:linear-gradient(90deg,rgba(34,196,131,.75),rgba(77,160,255,.45))}
.risks-insights__bar-seg--empty{background:rgba(255,255,255,.04)}
.risks-insights__bar-legend{
  display:flex;
  flex-wrap:wrap;
  gap:12px 18px;
  margin-top:10px;
  font-size:11px;
  color:var(--text2);
}
.risks-insights__bar-legend strong{font-weight:800;color:var(--text)}
.risks-insights__dot{
  display:inline-block;
  width:8px;height:8px;border-radius:99px;
  margin-right:6px;vertical-align:middle;
}
.risks-insights__dot--crit{background:rgba(239,91,107,.85)}
.risks-insights__dot--elev{background:rgba(243,179,79,.85)}
.risks-insights__dot--mod{background:rgba(34,196,131,.75)}
.risks-insights__tier-row{
  display:flex;
  flex-wrap:wrap;
  align-items:center;
  gap:10px 14px;
  margin-bottom:16px;
  padding-bottom:16px;
  border-bottom:1px solid rgba(255,255,255,.06);
}
.risks-insights__tier-label{
  font-size:10px;
  font-weight:800;
  letter-spacing:.1em;
  text-transform:uppercase;
  color:var(--text3);
}
.risks-insights__tier-pills{display:flex;flex-wrap:wrap;gap:8px}
.risks-tier-pill{
  font-family:inherit;
  font-size:11px;
  font-weight:700;
  padding:7px 12px;
  border-radius:999px;
  border:1px solid rgba(255,255,255,.12);
  background:rgba(255,255,255,.04);
  color:var(--text2);
  cursor:pointer;
  transition:background .15s ease,border-color .15s ease,color .15s ease,box-shadow .15s ease;
}
.risks-tier-pill:hover{
  background:rgba(255,255,255,.09);
  border-color:rgba(255,255,255,.18);
  color:var(--text);
}
.risks-tier-pill--active{
  background:rgba(77,160,255,.12);
  border-color:rgba(77,160,255,.35);
  color:#bae6fd;
  box-shadow:0 0 0 1px rgba(77,160,255,.2);
}
.risks-insights__top-title{
  font-size:10px;
  font-weight:800;
  letter-spacing:.1em;
  text-transform:uppercase;
  color:var(--text3);
  margin-bottom:10px;
}
.risks-insights__top-list{
  margin:0;
  padding:0;
  list-style:none;
  display:flex;
  flex-direction:column;
  gap:8px;
}
.risks-insights__top-item,.risks-insights__top-empty{
  display:flex;
  align-items:flex-start;
  gap:12px;
  padding:10px 12px;
  border-radius:12px;
  border:1px solid rgba(255,255,255,.07);
  background:rgba(0,0,0,.1);
}
.risks-insights__top-empty{font-size:12px;color:var(--text2);line-height:1.45}
.risks-insights__top-rank{
  flex-shrink:0;
  width:22px;height:22px;
  border-radius:8px;
  display:grid;
  place-items:center;
  font-size:11px;
  font-weight:800;
  background:rgba(255,255,255,.08);
  color:var(--text2);
}
.risks-insights__top-main{min-width:0;flex:1;display:flex;flex-direction:column;gap:2px}
.risks-insights__top-name{font-size:13px;font-weight:700;color:var(--text);line-height:1.35}
.risks-insights__top-sub{font-size:11px;color:var(--text3);line-height:1.35}
.risks-page__active-filters{
  display:flex;
  flex-wrap:wrap;
  align-items:center;
  gap:10px 14px;
  margin-bottom:14px;
  padding:10px 14px;
  border-radius:12px;
  border:1px solid rgba(77,160,255,.22);
  background:rgba(77,160,255,.06);
}
.risks-page__active-filters-label{
  font-size:10px;
  font-weight:800;
  letter-spacing:.08em;
  text-transform:uppercase;
  color:#93c5fd;
}
.risks-page__active-filters-actions{display:flex;flex-wrap:wrap;gap:8px}
.risks-page__active-filters-btn{font-size:11px!important;font-weight:700!important;padding:6px 12px!important;min-height:34px!important}
.risks-page__active-filters-btn--ghost{border-style:dashed;opacity:.95}
.risks-page__matrix-section{margin:0;min-width:0}
.risks-matrix-details{
  border-radius:14px;
  border:1px solid rgba(255,255,255,.08);
  background:rgba(0,0,0,.1);
  overflow:hidden;
  box-shadow:0 1px 0 rgba(255,255,255,.03) inset;
}
[data-theme='dark'] .risks-matrix-details{
  border-color:rgba(240,246,252,.1);
  background:linear-gradient(180deg,rgba(22,28,38,.5) 0%,rgba(14,18,24,.4) 100%);
}
.risks-matrix-details__summary{
  list-style:none;
  cursor:pointer;
  display:flex;
  flex-wrap:wrap;
  align-items:center;
  gap:8px 14px;
  padding:12px 16px;
  user-select:none;
  transition:background .15s ease;
}
.risks-matrix-details__summary::-webkit-details-marker{display:none}
.risks-matrix-details__summary::marker{content:''}
.risks-matrix-details__summary:hover{background:rgba(255,255,255,.04)}
.risks-matrix-details__summary-title{
  font-size:13px;
  font-weight:800;
  color:var(--text);
  letter-spacing:-.01em;
}
.risks-matrix-details__summary-meta{font-size:12px;font-weight:600;color:var(--text2)}
.risks-matrix-details__summary-warn{color:#fcd34d;font-weight:700}
.risks-matrix-details__summary-hint{
  margin-left:auto;
  font-size:11px;
  font-weight:600;
  color:var(--text3);
}
.risks-matrix-details__summary-pill{
  margin-left:auto;
  font-size:11px;
  font-weight:700;
  padding:4px 10px;
  border-radius:999px;
  background:rgba(77,160,255,.15);
  border:1px solid rgba(77,160,255,.3);
  color:#bae6fd;
}
@media (max-width:640px){
  .risks-matrix-details__summary-hint,.risks-matrix-details__summary-pill{margin-left:0}
}
.risks-matrix-details__summary::after{
  content:'';
  width:7px;height:7px;
  margin-left:4px;
  border-right:2px solid var(--text3);
  border-bottom:2px solid var(--text3);
  transform:rotate(45deg);
  transition:transform .2s ease;
  flex-shrink:0;
}
.risks-matrix-details[open] > .risks-matrix-details__summary::after{
  transform:rotate(-135deg);
  margin-top:4px;
}
.risks-matrix-details__body{
  padding:0 14px 16px;
  border-top:1px solid rgba(255,255,255,.06);
}
.risks-page__panel{
  display:flex;
  flex-direction:column;
  gap:0;
  min-width:0;
}
.risks-page__panel.content-card{padding-bottom:22px}
.risks-page__panel--register{min-height:0}
.risks-page__panel-head.content-card-head{margin-bottom:0;padding-bottom:16px;border-bottom:1px solid rgba(255,255,255,.07)}
.risks-page__panel-head.content-card-head--split{align-items:flex-start;gap:14px 18px}
.risks-page__panel-intro{min-width:0;flex:1}
.risks-page__panel-intro h3{margin:4px 0 8px;font-size:1.25rem;font-weight:800;letter-spacing:-.02em;line-height:1.25}
.risks-page__panel-lead{margin:0;max-width:58ch;font-size:13px;line-height:1.55;color:var(--text2)}
.risks-page__list-region{
  flex:1;
  min-height:0;
  margin-top:18px;
  display:flex;
  flex-direction:column;
  min-width:0;
}
.risks-page__list-stack{
  display:flex;
  flex-direction:column;
  gap:12px;
  min-width:0;
}
.risks-page__list-empty{
  padding:28px 20px;
  text-align:center;
  border-radius:14px;
  border:1px dashed rgba(255,255,255,.12);
  background:rgba(0,0,0,.12);
}
.risks-page__list-empty-title{margin:0 0 8px;font-size:15px;font-weight:800;color:var(--text)}
.risks-page__list-empty-sub{margin:0;font-size:13px;line-height:1.5;color:var(--text2);max-width:42ch;margin-inline:auto}
.risks-page__matrix-shell{
  margin-top:6px;
  padding:0;
  min-width:0;
}
.risks-page__matrix-shell .risk-matrix-grid{max-width:100%;width:100%}
.qhse-kpi-strip{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px}
.qhse-kpi-strip .metric-card{padding:14px 16px}
.qhse-kpi-strip .metric-value{font-size:28px}
.content-card-head--split{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;flex-wrap:wrap}
.content-card-lead{margin:0;font-size:13px;line-height:1.5;color:var(--text2)}
.content-card-lead--narrow{max-width:52ch}
.content-card-head--split .content-card-lead{max-width:56ch}
.content-card-head--split .content-card-lead--narrow{max-width:52ch}
.btn--pilotage-cta{white-space:nowrap;min-height:44px;font-weight:800}
.kanban-board--pilotage{
  margin-top:8px;
  display:grid;
  grid-template-columns:repeat(4,minmax(0,1fr));
  gap:16px;
  align-items:start;
}
@media (max-width:1280px){
  .kanban-board--pilotage{grid-template-columns:repeat(2,minmax(0,1fr))}
}
@media (max-width:700px){
  .kanban-board--pilotage{grid-template-columns:1fr}
}
.kanban-column--pilotage{
  background:rgba(255,255,255,.025);
  border-radius:14px;
  border:1px solid rgba(255,255,255,.08);
  padding:14px 12px 16px;
  min-height:140px;
  box-shadow:0 1px 0 rgba(255,255,255,.04) inset;
}
.kanban-column-head{margin-bottom:14px;padding-bottom:10px;border-bottom:1px solid rgba(255,255,255,.06)}
.kanban-column-title{margin:0 0 4px;font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:var(--text);font-weight:800}
.kanban-column-hint{margin:0;font-size:11px;color:var(--text3);line-height:1.4;max-width:36ch}
.kanban-column--todo{border-top:3px solid rgba(77,160,255,.55)}
.kanban-column--doing{border-top:3px solid rgba(243,179,79,.6)}
.kanban-column--overdue{border-top:3px solid rgba(239,91,107,.6)}
.kanban-column--done{border-top:3px solid rgba(34,196,131,.55)}
.action-card{border-left:3px solid transparent;border-radius:12px}
.action-card--todo,.action-card--col-todo{border-left-color:rgba(77,160,255,.55)}
.action-card--doing,.action-card--col-doing{border-left-color:rgba(243,179,79,.55)}
.action-card--overdue,.action-card--col-overdue{border-left-color:rgba(239,91,107,.55)}
.action-card--done,.action-card--col-done{border-left-color:rgba(34,196,131,.5)}
.action-card--v2{
  padding:12px 12px 10px;
  margin-bottom:10px;
  background:rgba(0,0,0,.18);
  border:1px solid rgba(255,255,255,.07);
  border-left-width:3px;
}
.action-card--v2:last-child{margin-bottom:0}
.action-card__top{display:flex;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:8px}
.action-card__title{
  margin:0;
  font-size:14px;
  font-weight:800;
  line-height:1.35;
  letter-spacing:-.01em;
  color:var(--text);
  flex:1;
  min-width:0;
}
.action-card__prio{
  flex-shrink:0;
  font-size:10px;
  font-weight:800;
  letter-spacing:.04em;
  text-transform:uppercase;
  padding:4px 8px;
  border-radius:8px;
  border:1px solid rgba(255,255,255,.1);
  background:rgba(255,255,255,.06);
  color:var(--text2);
}
.action-card__prio--danger{border-color:rgba(239,91,107,.35);background:rgba(239,91,107,.12);color:#fecaca}
.action-card__prio--warn{border-color:rgba(243,179,79,.35);background:rgba(243,179,79,.12);color:#fde68a}
.action-card__prio--info{border-color:rgba(77,160,255,.35);background:rgba(77,160,255,.1);color:#bae6fd}
.action-card__prio--neutral{border-color:rgba(148,163,184,.2);background:rgba(255,255,255,.04);color:var(--text3)}
.action-card__prio--ok{border-color:rgba(34,196,131,.35);background:rgba(34,196,131,.12);color:#a7f3d0}
.action-card__status{
  display:inline-block;
  font-size:10px;
  font-weight:800;
  letter-spacing:.06em;
  text-transform:uppercase;
  padding:4px 10px;
  border-radius:999px;
  margin-bottom:10px;
  border:1px solid rgba(255,255,255,.1);
  color:var(--text2);
}
.action-card__status--todo{background:rgba(77,160,255,.1);color:#bae6fd}
.action-card__status--doing{background:rgba(243,179,79,.12);color:#fde68a}
.action-card__status--overdue{background:rgba(239,91,107,.14);color:#fecaca}
.action-card__status--done{background:rgba(34,196,131,.12);color:#a7f3d0}
.action-card__meta{display:flex;flex-direction:column;gap:6px;margin-bottom:10px}
.action-card__meta-row{display:flex;justify-content:space-between;align-items:baseline;gap:10px;font-size:12px;line-height:1.35}
.action-card__meta-k{font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--text3);flex-shrink:0}
.action-card__meta-v{color:var(--text2);text-align:right;min-width:0;word-break:break-word}
.action-card__meta-v--late{color:#fecaca;font-weight:800}
.action-card__quick{display:flex;flex-wrap:wrap;gap:6px;margin-top:4px}
.action-card__quick-btn{
  font-family:inherit;
  font-size:11px;
  font-weight:700;
  padding:6px 10px;
  border-radius:8px;
  border:1px solid rgba(255,255,255,.12);
  background:rgba(255,255,255,.05);
  color:var(--text);
  cursor:pointer;
  transition:background .15s ease,border-color .15s ease;
}
.action-card__quick-btn:hover{background:rgba(255,255,255,.1);border-color:rgba(255,255,255,.18)}
.action-card__quick-btn:disabled{opacity:.45;cursor:not-allowed}
.action-card__quick-btn--primary{border-color:rgba(34,196,131,.35);background:rgba(34,196,131,.1);color:#a7f3d0}
.action-card__assign-wrap{margin-top:10px;padding-top:10px;border-top:1px dashed rgba(255,255,255,.08)}
.action-card__assign-label{display:block;font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--text3);margin-bottom:4px}
.action-card__field{font-size:12px;color:var(--text2);margin-bottom:6px}
.action-card__label{display:block;font-size:10px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--text3);margin-bottom:2px}
.action-card__value{display:block;margin-top:2px}
.action-card__field--due .action-card__value{font-size:13px;font-weight:800;color:var(--text)}
.action-card__assign-select{width:100%;margin-top:0;padding:8px 10px;font-size:12px;font-weight:600;border-radius:10px;border:1px solid rgba(255,255,255,.12);background:rgba(0,0,0,.25);color:var(--text)}
.action-detail-dialog{
  border:none;
  border-radius:18px;
  padding:0;
  max-width:min(520px,94vw);
  background:var(--surface,#151821);
  color:var(--text);
  box-shadow:0 24px 80px rgba(0,0,0,.45);
}
.action-detail-dialog::backdrop{background:rgba(0,0,0,.55);backdrop-filter:blur(4px)}
.action-detail-dialog__inner{padding:22px 22px 18px;max-height:min(88vh,720px);overflow-y:auto}
.action-detail-dialog__head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:12px}
.action-detail-dialog__title{margin:0;font-size:1.15rem;font-weight:800;letter-spacing:-.02em;line-height:1.25;flex:1;min-width:0}
.action-detail-dialog__badges{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:14px}
.action-detail-dialog__pill{
  font-size:10px;
  font-weight:800;
  letter-spacing:.05em;
  text-transform:uppercase;
  padding:4px 10px;
  border-radius:999px;
  border:1px solid rgba(255,255,255,.12);
}
.action-detail-dialog__pill--danger{background:rgba(239,91,107,.15);color:#fecaca;border-color:rgba(239,91,107,.3)}
.action-detail-dialog__pill--warn{background:rgba(243,179,79,.15);color:#fde68a;border-color:rgba(243,179,79,.3)}
.action-detail-dialog__pill--info{background:rgba(77,160,255,.12);color:#bae6fd;border-color:rgba(77,160,255,.28)}
.action-detail-dialog__pill--ok{background:rgba(34,196,131,.12);color:#a7f3d0;border-color:rgba(34,196,131,.28)}
.action-detail-dialog__grid{
  display:grid;
  grid-template-columns:auto 1fr;
  gap:6px 14px;
  font-size:13px;
  margin:0 0 16px;
}
.action-detail-dialog__grid dt{margin:0;font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--text3)}
.action-detail-dialog__grid dd{margin:0;color:var(--text2);word-break:break-word}
.action-detail-dialog__id{font-size:12px;font-weight:600;color:var(--text)}
.action-detail-dialog__api code{font-size:11px;word-break:break-all;color:var(--text3)}
.action-detail-dialog__block{margin-bottom:16px}
.action-detail-dialog__block-label{font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--text3);margin-bottom:6px}
.action-detail-dialog__detail{margin:0;font-size:13px;line-height:1.5;color:var(--text2);white-space:pre-wrap}
.action-detail-dialog__foot{display:flex;flex-wrap:wrap;gap:8px;justify-content:flex-end;padding-top:4px;border-top:1px solid rgba(255,255,255,.06)}
.actions-filter-toolbar{margin-top:12px;display:flex;flex-wrap:wrap;gap:10px 16px;align-items:flex-end}
.actions-filter-toolbar .actions-filter-group{display:flex;flex-direction:column;gap:4px;min-width:min(200px,100%)}
.actions-filter-toolbar label{font-size:10px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--text3)}
.actions-filter-toolbar select{padding:8px 10px;font-size:12px;font-weight:600;border-radius:10px;border:1px solid rgba(255,255,255,.12);background:rgba(0,0,0,.25);color:var(--text);min-width:180px;max-width:100%}
.risk-register-row{
  border-radius:14px;
  border:1px solid rgba(255,255,255,.08);
  background:rgba(255,255,255,.035);
  padding:16px 18px;
  border-left-width:4px;
  border-left-style:solid;
  transition:background .15s ease,border-color .15s ease,box-shadow .15s ease;
}
.risk-register-row:hover{
  background:rgba(255,255,255,.055);
  border-color:rgba(255,255,255,.11);
  box-shadow:0 4px 20px rgba(0,0,0,.12);
}
.risk-register-row--red{border-left-color:rgba(239,91,107,.45)}
.risk-register-row--amber{border-left-color:rgba(243,179,79,.45)}
.risk-register-row--blue{border-left-color:rgba(77,160,255,.45)}
.risk-register-row__head{display:flex;flex-wrap:wrap;align-items:flex-start;justify-content:space-between;gap:10px}
.risk-register-row__title{font-size:15px;line-height:1.3}
.risk-register-row__badge{font-size:11px;font-weight:800}
.risk-register-row__crit{display:flex;flex-wrap:wrap;align-items:center;gap:8px 14px;margin-top:12px;padding-top:12px;border-top:1px solid rgba(255,255,255,.07)}
.risk-register-row__gp{font-size:13px;font-weight:800;font-variant-numeric:tabular-nums;letter-spacing:.02em;color:var(--text)}
.risk-register-row__score{font-size:11px;font-weight:700;padding:4px 9px;border-radius:999px;background:rgba(255,255,255,.08);color:var(--text2)}
.risk-register-row__tier-chip{font-size:10px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;padding:4px 10px;border-radius:8px;border:1px solid rgba(255,255,255,.12)}
.risk-register-row__tier-chip--t1,.risk-register-row__tier-chip--t2{background:rgba(34,196,131,.15);color:#b6f0d2}
.risk-register-row__tier-chip--t3{background:rgba(243,179,79,.22);color:#fde68a}
.risk-register-row__tier-chip--t4{background:rgba(255,144,70,.22);color:#fed7aa}
.risk-register-row__tier-chip--t5{background:rgba(239,91,107,.22);color:#fecaca}
.risk-register-row__crit-fallback{font-size:12px;font-weight:600;color:var(--text2)}
.risk-register-row__crit-hint{font-size:11px;color:var(--text3);line-height:1.4;flex:1 1 100%}
.risk-register-row__desc{margin:10px 0 0;font-size:13px;line-height:1.45;color:var(--text2)}
.risks-create-dialog{border:none;border-radius:18px;padding:0;max-width:min(560px,94vw);background:var(--surface,#151821);color:var(--text);box-shadow:0 24px 80px rgba(0,0,0,.45)}
.risks-create-dialog::backdrop{background:rgba(0,0,0,.55);backdrop-filter:blur(4px)}
.risks-create-dialog__inner{padding:22px 22px 18px;max-height:min(88vh,720px);overflow-y:auto;-webkit-overflow-scrolling:touch}
.risks-create-dialog__head{margin:0 0 6px;font-size:18px;font-weight:800;letter-spacing:-.02em}
.risks-create-dialog__lead{margin:0 0 16px;font-size:13px;line-height:1.45;color:var(--text2);max-width:52ch}
.risks-form-grid{display:grid;gap:12px}
.risks-form-grid label{display:flex;flex-direction:column;gap:5px;font-size:10px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--text3)}
.risks-form-grid input,.risks-form-grid select,.risks-form-grid textarea{padding:10px 12px;font-size:13px;font-weight:600;border-radius:10px;border:1px solid rgba(255,255,255,.12);background:rgba(0,0,0,.22);color:var(--text);width:100%;box-sizing:border-box;font-family:inherit}
.risks-form-grid textarea{min-height:88px;resize:vertical;line-height:1.45}
.risks-form-actions-row{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-top:14px}
.risks-form-actions-row .btn{min-height:42px}
.risks-ai-panel{margin-top:14px;padding:14px 14px 12px;border-radius:12px;border:1px dashed rgba(77,160,255,.35);background:rgba(77,160,255,.06)}
.risks-ai-panel[hidden]{display:none!important}
.risks-ai-panel__disclaimer{margin:0 0 10px;font-size:11px;line-height:1.4;color:var(--text2);font-weight:600}
.risks-ai-panel__list{margin:0;padding-left:18px;font-size:12px;line-height:1.45;color:var(--text2)}
.risks-ai-panel__list li{margin-bottom:4px}
.risks-ai-panel__kv{display:grid;gap:6px;margin-bottom:10px;font-size:12px}
.risks-ai-panel__kv span{color:var(--text3);font-weight:700;text-transform:uppercase;font-size:10px;letter-spacing:.06em}
.risks-ai-panel__kv strong{color:var(--text);font-weight:700}
.risks-ai-panel__actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}
.risks-ai-panel--loading{opacity:.72;pointer-events:none}
.risk-matrix-panel{display:flex;flex-direction:column;gap:1.35rem;width:100%}
.risk-matrix-panel--embedded{gap:.95rem}
.risk-matrix-panel--embedded .risk-matrix-tool{
  padding:12px 14px 12px;
  gap:.85rem;
  border-radius:12px;
}
.risk-matrix-panel--embedded .risk-matrix-priority-row{gap:8px}
.risk-matrix-panel--embedded .risk-matrix-priority-card{padding:10px 12px;gap:10px}
.risk-matrix-panel--embedded .risk-matrix-priority-card__value{font-size:18px}
.risk-matrix-panel--embedded .risk-matrix-hotspot-chip{padding:7px 11px;font-size:11px}
.risk-matrix-panel--embedded .risk-matrix-grid{
  gap:6px;
  grid-template-rows:auto repeat(5,minmax(40px,1fr));
}
.risk-matrix-panel--embedded .risk-matrix-cell{min-height:40px;padding:4px;border-radius:10px}
.risk-matrix-panel--embedded .risk-matrix-cell__count{font-size:15px}
.risk-matrix-panel--embedded .risk-matrix-grid__colhead{padding:6px 2px 8px;font-size:11px}
.risk-matrix-panel--embedded .risk-matrix-grid__rowhead{font-size:11px;padding-right:8px}
.risk-matrix-panel--embedded .risk-matrix-legend{padding-top:8px;margin-top:4px}
.risk-matrix-tool{
  display:flex;
  flex-direction:column;
  gap:1.1rem;
  padding:18px 18px 16px;
  border-radius:14px;
  border:1px solid rgba(255,255,255,.1);
  background:rgba(0,0,0,.14);
  box-shadow:0 1px 0 rgba(255,255,255,.04) inset;
}
.risk-matrix-tool__head{margin:0}
.risk-matrix-tool__title{display:block;font-size:13px;font-weight:800;letter-spacing:.02em;margin-bottom:8px;color:var(--text)}
.risk-matrix-tool__lede{margin:0;font-size:12px;line-height:1.55;color:var(--text2);max-width:56ch}
.risk-matrix-priority-row{
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(132px,1fr));
  gap:10px;
}
.risk-matrix-priority-card{
  display:flex;
  align-items:flex-start;
  gap:12px;
  padding:12px 14px;
  border-radius:12px;
  border:1px solid rgba(255,255,255,.08);
  background:rgba(255,255,255,.03);
}
.risk-matrix-priority-card__value{
  font-size:22px;
  font-weight:800;
  line-height:1;
  font-variant-numeric:tabular-nums;
  flex-shrink:0;
  min-width:1.5ch;
}
.risk-matrix-priority-card__text{display:flex;flex-direction:column;gap:3px;min-width:0}
.risk-matrix-priority-card__label{font-size:12px;font-weight:800;color:var(--text)}
.risk-matrix-priority-card__hint{font-size:10px;line-height:1.35;color:var(--text3)}
.risk-matrix-priority-card--crit .risk-matrix-priority-card__value{color:#fca5a5}
.risk-matrix-priority-card--crit{border-color:rgba(239,91,107,.25);background:rgba(239,91,107,.06)}
.risk-matrix-priority-card--warn .risk-matrix-priority-card__value{color:#fcd34d}
.risk-matrix-priority-card--warn{border-color:rgba(243,179,79,.22);background:rgba(243,179,79,.06)}
.risk-matrix-priority-card--ok .risk-matrix-priority-card__value{color:#86efac}
.risk-matrix-priority-card--ok{border-color:rgba(34,196,131,.2);background:rgba(34,196,131,.05)}
.risk-matrix-priority-card--muted .risk-matrix-priority-card__value{color:var(--text3)}
.risk-matrix-priority-card--muted{opacity:.92}
.risk-matrix-hotspots-section__label{
  font-size:10px;
  font-weight:800;
  letter-spacing:.1em;
  text-transform:uppercase;
  color:var(--text3);
  margin-bottom:10px;
}
.risk-matrix-hotspots{display:flex;flex-wrap:wrap;gap:8px;align-items:flex-start}
.risk-matrix-hotspots-empty{margin:0;font-size:12px;line-height:1.5;color:var(--text2);max-width:48ch}
.risk-matrix-hotspot-chip{
  display:inline-flex;
  flex-wrap:wrap;
  align-items:baseline;
  gap:6px 10px;
  padding:10px 14px;
  border-radius:999px;
  border:1px solid rgba(255,255,255,.12);
  background:rgba(255,255,255,.06);
  color:var(--text);
  font-family:inherit;
  font-size:12px;
  cursor:pointer;
  transition:background .15s ease,transform .12s ease,box-shadow .15s ease;
  text-align:left;
}
.risk-matrix-hotspot-chip:hover{background:rgba(255,255,255,.1);transform:translateY(-1px)}
.risk-matrix-hotspot-chip--active{
  box-shadow:0 0 0 2px rgba(88,166,255,.65);
  border-color:rgba(88,166,255,.4);
}
.risk-matrix-hotspot-chip__gp{font-weight:800;font-variant-numeric:tabular-nums}
.risk-matrix-hotspot-chip__mid strong{font-size:13px}
.risk-matrix-hotspot-chip__score{font-size:10px;font-weight:700;opacity:.75}
.risk-matrix-hotspot-chip--t1{background:rgba(34,196,131,.12)}
.risk-matrix-hotspot-chip--t2{background:rgba(110,205,100,.14)}
.risk-matrix-hotspot-chip--t3{background:rgba(243,179,79,.16)}
.risk-matrix-hotspot-chip--t4{background:rgba(255,144,70,.18)}
.risk-matrix-hotspot-chip--t5{background:rgba(239,91,107,.18)}
.risk-matrix-status-row{
  display:flex;
  flex-wrap:wrap;
  align-items:center;
  justify-content:space-between;
  gap:10px 14px;
  padding-top:4px;
}
.risk-matrix-panel__stats{margin:0;font-size:12px;font-weight:600;color:var(--text2);line-height:1.45;flex:1;min-width:12rem}
.risk-matrix-panel__reset{font-size:12px;font-weight:700;padding:8px 14px;min-height:40px;white-space:nowrap}
.risk-matrix-grid-wrap{margin-top:4px}
.risk-matrix-grid-wrap__label{
  font-size:11px;
  font-weight:800;
  letter-spacing:.06em;
  text-transform:uppercase;
  color:var(--text3);
  margin-bottom:12px;
}
.risk-matrix-grid-wrap__hint{
  font-weight:600;
  text-transform:none;
  letter-spacing:0;
  color:var(--text3);
  font-size:11px;
}
.risk-matrix-grid{
  display:grid;
  grid-template-columns:minmax(40px,auto) repeat(5,minmax(0,1fr));
  grid-template-rows:auto repeat(5,minmax(56px,1fr));
  gap:10px;
  align-items:stretch;
  width:100%;
  max-width:100%;
}
.risk-matrix-grid__corner{
  grid-column:1;
  grid-row:1;
  display:flex;
  flex-direction:column;
  justify-content:flex-end;
  gap:6px;
  padding:6px 8px 12px 0;
  font-size:10px;
  font-weight:800;
  letter-spacing:.08em;
  color:var(--text3);
  line-height:1.2;
}
.risk-matrix-grid__colhead{
  grid-row:1;
  font-size:12px;
  font-weight:800;
  text-align:center;
  color:var(--text2);
  padding:10px 4px 14px;
  display:flex;
  align-items:flex-end;
  justify-content:center;
}
.risk-matrix-grid__rowhead{
  grid-column:1;
  font-size:12px;
  font-weight:800;
  text-align:right;
  color:var(--text2);
  display:flex;
  align-items:center;
  justify-content:flex-end;
  padding-right:12px;
}
.risk-matrix-cell{
  display:flex;
  align-items:center;
  justify-content:center;
  border:none;
  border-radius:12px;
  font-family:inherit;
  color:var(--text);
  cursor:pointer;
  transition:transform .12s ease,box-shadow .15s ease,opacity .15s ease;
  border:1px solid rgba(255,255,255,.08);
  min-height:56px;
  padding:8px;
}
.risk-matrix-cell__count{font-size:20px;font-weight:800;line-height:1;font-variant-numeric:tabular-nums}
.risk-matrix-cell:focus-visible{outline:2px solid rgba(77,160,255,.75);outline-offset:2px}
.risk-matrix-cell--empty{
  opacity:.28;
  cursor:default;
  border-style:dashed;
  border-color:rgba(255,255,255,.06);
}
.risk-matrix-cell--empty.risk-matrix-cell--active{opacity:.55;cursor:pointer}
.risk-matrix-cell--has-data{cursor:pointer;opacity:1}
.risk-matrix-cell--has-data:hover{
  transform:translateY(-1px);
  box-shadow:0 4px 16px rgba(0,0,0,.22);
  border-color:rgba(255,255,255,.16);
  filter:brightness(1.06);
}
.risk-matrix-panel--embedded .risk-matrix-cell--has-data:hover{transform:translateY(-1px) scale(1.02)}
.risk-matrix-cell--active{
  box-shadow:0 0 0 2px rgba(88,166,255,.75),0 6px 18px rgba(0,0,0,.2);
  z-index:1;
  opacity:1!important;
  border-color:rgba(88,166,255,.4);
}
.risk-matrix-cell--t1{background:rgba(34,196,131,.14)}
.risk-matrix-cell--t2{background:rgba(110,205,100,.16)}
.risk-matrix-cell--t3{background:rgba(243,179,79,.2)}
.risk-matrix-cell--t4{background:rgba(255,144,70,.22)}
.risk-matrix-cell--t5{background:rgba(239,91,107,.24)}
.risk-matrix-legend{margin-top:6px;padding-top:10px;border-top:1px solid rgba(255,255,255,.06)}
.risk-matrix-legend__compact{
  display:inline-flex;
  align-items:center;
  gap:6px;
  font-size:11px;
  color:var(--text3);
}
.risk-matrix-legend__compact-label{margin-right:4px;font-weight:700}
.risk-matrix-legend__sw{
  display:inline-grid;
  place-items:center;
  width:22px;
  height:22px;
  border-radius:6px;
  font-size:9px;
  font-weight:800;
  color:rgba(0,0,0,.75);
}
.risk-matrix-legend__sw--1{background:rgba(34,196,131,.5)}
.risk-matrix-legend__sw--2{background:rgba(110,205,100,.55)}
.risk-matrix-legend__sw--3{background:rgba(243,179,79,.55)}
.risk-matrix-legend__sw--4{background:rgba(255,144,70,.55)}
.risk-matrix-legend__sw--5{background:rgba(239,91,107,.55);color:#fff}
`;

export function ensureQhsePilotageStyles() {
  if (document.getElementById(STYLE_ID)) return;
  const el = document.createElement('style');
  el.id = STYLE_ID;
  el.textContent = CSS;
  document.head.append(el);
}
