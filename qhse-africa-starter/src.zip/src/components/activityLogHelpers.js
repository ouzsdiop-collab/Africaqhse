/**
 * Métadonnées modules — un seul endroit pour labels / styles (badges).
 * Les filtres / tri futurs pourront réutiliser ces clés.
 */
export const MODULE_META = {
  incidents: { label: 'Incidents', short: 'INC', className: 'mod-incidents' },
  actions: { label: 'Actions', short: 'ACT', className: 'mod-actions' },
  audits: { label: 'Audits', short: 'AUD', className: 'mod-audits' },
  iso: { label: 'Conformité ISO', short: 'ISO', className: 'mod-iso' },
  products: { label: 'Produits / FDS', short: 'PRD', className: 'mod-products' },
  context: { label: 'Contexte site', short: 'CTX', className: 'mod-context' },
  system: { label: 'Système', short: 'SYS', className: 'mod-system' },
  'ai-center': { label: 'Centre IA', short: 'IA', className: 'mod-ai-center' }
};

export function moduleMeta(moduleId) {
  return MODULE_META[moduleId] || { label: moduleId || '—', short: '—', className: 'mod-default' };
}

/**
 * Repère les actions sensibles pour la traçabilité (mise en avant visuelle légère).
 */
export function classifyActionImportance(action) {
  if (!action) return 'normal';
  const a = action.toLowerCase();
  const triggers = [
    'créé',
    'création',
    'supprim',
    'audit',
    'conformité',
    'initialis',
    'changement de site',
    'préparation',
    'incident',
    'sécurité'
  ];
  if (triggers.some((k) => a.includes(k))) return 'high';
  return 'normal';
}

/**
 * Synthèse affichable à partir de la liste courante (ordre antichronologique attendu).
 * @param {Array<{ module?: string, timestamp?: string }>} entries
 */
export function buildActivityLogSnapshot(entries) {
  const total = entries.length;
  const lastActivity = total ? entries[0].timestamp || '—' : '—';

  const recentModuleKeys = [];
  const seen = new Set();
  for (let i = 0; i < entries.length && recentModuleKeys.length < 6; i++) {
    const m = entries[i].module;
    if (m && !seen.has(m)) {
      seen.add(m);
      recentModuleKeys.push(m);
    }
  }

  return { total, lastActivity, recentModuleKeys };
}
