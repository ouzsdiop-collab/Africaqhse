const STYLE_ID = 'qhse-iso-page-styles';

const CSS = `
.iso-page .iso-header-card .content-card-head{align-items:flex-start}
.iso-global-snapshot{border-radius:16px;padding:20px 22px;margin-top:4px;border:1px solid rgba(148,163,184,.16);background:linear-gradient(135deg,rgba(59,130,246,.08),rgba(255,255,255,.02))}
.iso-global-snapshot--ok{border-color:rgba(34,197,94,.25);background:linear-gradient(135deg,rgba(34,197,94,.1),rgba(255,255,255,.02))}
.iso-global-snapshot--watch{border-color:rgba(245,158,11,.28);background:linear-gradient(135deg,rgba(245,158,11,.1),rgba(255,255,255,.02))}
.iso-global-snapshot--risk{border-color:rgba(239,68,68,.3);background:linear-gradient(135deg,rgba(239,68,68,.1),rgba(255,255,255,.02))}
.iso-global-snapshot-inner{display:flex;flex-wrap:wrap;gap:20px;align-items:center}
.iso-global-score{min-width:120px;text-align:center}
.iso-global-pct{font-size:clamp(2.5rem,6vw,3.25rem);font-weight:800;letter-spacing:-.04em;line-height:1;color:var(--text)}
.iso-global-pct-suffix{font-size:1.25rem;font-weight:700;color:var(--text2);vertical-align:super;margin-left:2px}
.iso-global-score-caption{font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--text3);margin-top:4px}
.iso-global-copy{flex:1;min-width:200px}
.iso-global-label{font-size:18px;font-weight:800;color:var(--text);margin-bottom:6px}
.iso-global-message{margin:0;font-size:14px;line-height:1.5;color:var(--text2)}
.iso-global-meta{margin-top:10px;font-size:12px;font-weight:600;color:var(--text3)}
.iso-points-panel{border-radius:16px;padding:18px 20px;border:1px solid rgba(148,163,184,.18);background:rgba(0,0,0,.12);margin-top:12px}
.iso-points-panel-title{margin:0 0 6px;font-size:17px;font-weight:800;color:var(--text)}
.iso-points-panel-lead{margin:0 0 16px;font-size:13px;line-height:1.45;color:var(--text2)}
.iso-points-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
@media (max-width:900px){.iso-points-grid{grid-template-columns:1fr}}
.iso-points-col{border-radius:12px;padding:14px 16px;background:rgba(255,255,255,.03);border:1px solid rgba(148,163,184,.1);min-width:0}
.iso-points-col-head{display:flex;align-items:center;gap:8px;font-size:11px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--text3);margin-bottom:8px}
.iso-points-icon{width:8px;height:8px;border-radius:999px;flex-shrink:0}
.iso-points-icon--req{background:linear-gradient(135deg,#f59e0b,#ef4444)}
.iso-points-icon--doc{background:linear-gradient(135deg,#3b82f6,#8b5cf6)}
.iso-points-icon--aud{background:linear-gradient(135deg,#22c55e,#14b8a6)}
.iso-points-metric{font-size:14px;font-weight:700;color:var(--text);margin-bottom:10px}
.iso-points-list{list-style:none;margin:0;padding:0;display:grid;gap:10px}
.iso-points-list li{min-width:0}
.iso-points-list-empty,.iso-points-list-more{font-size:12px;color:var(--text2);line-height:1.4}
.iso-points-list-more{color:var(--text3)}
.iso-points-action-link{display:block;width:100%;text-align:left;background:none;border:none;padding:0;font:inherit;font-weight:700;color:var(--accent,#60a5fa);cursor:pointer;text-decoration:underline;text-underline-offset:3px}
.iso-points-action-link:hover{filter:brightness(1.1)}
.iso-points-mini-badge{font-size:10px!important;padding:2px 6px!important;vertical-align:middle}
.iso-points-list-sub{display:block;font-size:11px;color:var(--text3);margin-top:4px}
.iso-points-doc-tag{display:inline-block;font-size:9px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;padding:2px 6px;border-radius:6px;margin-right:8px;background:rgba(239,68,68,.2);color:#fecaca}
.iso-points-list-note{margin:4px 0 0;font-size:12px;color:var(--text2);line-height:1.4}
.iso-norms-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:4px}
@media (max-width:1000px){.iso-norms-grid{grid-template-columns:1fr}}
.iso-norms-grid--lite{margin-top:8px}
.iso-norm-card{border:1px solid rgba(148,163,184,.14);border-radius:14px;padding:14px 16px;background:rgba(255,255,255,.02);display:grid;gap:8px;min-width:0}
.iso-norm-card--lite{padding:12px 14px;gap:10px}
.iso-norm-card-top{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:8px}
.iso-norm-line{margin:0;font-size:13px;line-height:1.45;color:var(--text2)}
.iso-norm-id{font-size:11px;font-weight:800;letter-spacing:.12em;text-transform:uppercase;color:var(--text3)}
.iso-norm-title{margin:0;font-size:15px;font-weight:700;line-height:1.3;color:var(--text)}
.iso-norm-hint{margin:0;font-size:12px;line-height:1.45;color:var(--text2)}
.iso-req-hot-wrap{display:grid;gap:10px;margin-top:8px}
.iso-req-hot-empty{margin:0;padding:14px;border-radius:12px;border:1px dashed rgba(148,163,184,.2);font-size:13px;color:var(--text2);line-height:1.45}
.iso-req-hot-item{display:flex;flex-wrap:wrap;align-items:center;gap:12px;padding:12px 14px;border-radius:12px;border:1px solid rgba(148,163,184,.12);background:rgba(255,255,255,.02)}
.iso-req-hot-main{flex:1;min-width:180px}
.iso-req-hot-title{font-weight:700;font-size:14px;color:var(--text);line-height:1.3}
.iso-req-hot-sub{font-size:12px;color:var(--text3);margin-top:4px}
.iso-req-hot-btn{font-size:12px!important;padding:8px 14px!important;min-height:36px!important}
.iso-toggle-full-req,.iso-toggle-full-docs{margin-top:12px;width:100%;max-width:320px}
.iso-req-full-wrap{margin-top:8px}
.iso-doc-attention-list{display:grid;gap:14px;margin-top:8px}
.iso-doc-attention-block-title{font-size:10px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--text3);margin-bottom:8px}
.iso-doc-attention-row{padding:10px 12px;border-radius:10px;background:rgba(0,0,0,.12);border:1px solid rgba(148,163,184,.1)}
.iso-doc-attention-row strong{display:block;font-size:13px;color:var(--text)}
.iso-doc-attention-note{margin:6px 0 0;font-size:12px;color:var(--text2);line-height:1.4}
.iso-doc-attention-empty{margin:0;font-size:13px;color:var(--text2);line-height:1.45}
.iso-docs-priority{display:grid;gap:4px}
.iso-section-stack{display:grid;gap:14px;min-width:0}
.iso-table-wrap{overflow-x:auto;margin-top:8px;border-radius:12px;border:1px solid rgba(148,163,184,.1)}
.iso-table{display:grid;gap:0;min-width:720px}
.iso-table-head,.iso-table-row{display:grid;grid-template-columns:minmax(180px,2.2fr) minmax(100px,1fr) minmax(110px,1fr) minmax(100px,1fr) minmax(110px,1fr);gap:10px;padding:10px 14px;align-items:center;font-size:12px}
.iso-req-table .iso-table-head,.iso-req-table .iso-table-row{
  grid-template-columns:minmax(200px,2.4fr) minmax(92px,0.9fr) minmax(130px,1.1fr) minmax(110px,1fr) minmax(140px,1.3fr);
  min-width:860px;
}
.iso-cell-small{font-size:11px;font-weight:600;margin-top:4px;display:inline-block}
.iso-analyze-btn{font-size:12px!important;padding:8px 12px!important;min-height:38px!important;white-space:nowrap}
.iso-table-head{font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--text3);background:rgba(0,0,0,.15);border-bottom:1px solid rgba(148,163,184,.12)}
.iso-table-row{border-bottom:1px solid rgba(148,163,184,.08);padding:12px 14px}
.iso-table-row:last-child{border-bottom:none}
.iso-table-row .iso-cell-strong{font-weight:700;color:var(--text);line-height:1.35}
.iso-table-row .iso-cell-muted{color:var(--text2);line-height:1.35}
.iso-doc-table .iso-table-head,.iso-doc-table .iso-table-row{grid-template-columns:minmax(160px,2fr) 80px minmax(100px,1fr) minmax(120px,1.2fr);min-width:560px}
.iso-review-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-top:8px}
@media (max-width:640px){.iso-review-grid{grid-template-columns:1fr}}
.iso-review-tile{border-radius:12px;border:1px solid rgba(148,163,184,.12);padding:12px 14px;background:rgba(255,255,255,.02)}
.iso-review-tile span:first-child{display:block;font-size:10px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--text3);margin-bottom:6px}
.iso-review-tile .iso-review-value{font-size:20px;font-weight:800;letter-spacing:-.02em;color:var(--text)}
.iso-review-tile .iso-review-detail{display:block;margin-top:4px;font-size:12px;color:var(--text2);line-height:1.4}
.iso-pilotage-aside{display:grid;gap:14px;align-content:start}

/* —— Hiérarchie visuelle (page ISO hub, dark premium) —— tout préfixé .iso-page pour limiter la portée —— */
.iso-page.iso-page--hub{
  gap:1.75rem;
}
.iso-page.iso-page--hub .iso-hub-intro.content-card{
  background:rgba(0,0,0,.06);
  border:1px solid rgba(148,163,184,.11);
  box-shadow:0 1px 0 rgba(255,255,255,.035) inset;
  border-radius:16px;
}
.iso-page.iso-page--hub .iso-hub-intro .content-card-head{margin-bottom:0}
.iso-page.iso-page--hub .iso-hub-hero{
  display:flex;
  flex-direction:column;
  gap:1.5rem;
  min-width:0;
}
.iso-page.iso-page--hub .iso-hub-hero-split{
  display:grid;
  grid-template-columns:minmax(0,1.58fr) minmax(252px,0.82fr);
  gap:1.35rem;
  align-items:stretch;
}
@media (max-width:960px){
  .iso-page.iso-page--hub .iso-hub-hero-split{grid-template-columns:1fr}
}
.iso-page.iso-page--hub .iso-hub-hero-norms{
  min-width:0;
  display:flex;
  flex-direction:column;
}
.iso-page.iso-page--hub .iso-hub-hero-norms>.content-card{flex:1}
.iso-page.iso-page--hub .iso-hub-hero-metric{
  min-width:0;
  display:flex;
  flex-direction:column;
}
/* Snapshot = panneau d’appui (moins « carte principale » que les normes) */
.iso-page.iso-page--hub .iso-hub-hero-metric>.iso-global-snapshot{
  margin-top:0;
  flex:1;
  display:flex;
  flex-direction:column;
  justify-content:center;
  padding:16px 18px;
  border-radius:16px;
  border:1px solid rgba(148,163,184,.11);
  background:rgba(0,0,0,.14);
  box-shadow:none;
}
.iso-page.iso-page--hub .iso-hub-hero-metric .iso-global-pct{
  font-size:clamp(1.85rem,4.2vw,2.65rem);
}
.iso-page.iso-page--hub .iso-hub-hero-metric .iso-global-label{
  font-size:15px;
}
.iso-page.iso-page--hub .iso-hub-hero-metric .iso-global-message{
  font-size:13px;
}
/* Bloc central normes : palier visuel maximal */
.iso-page.iso-page--hub .iso-norms-central.content-card{
  position:relative;
  z-index:1;
  border-radius:20px;
  border:1px solid rgba(125,211,252,.24);
  background:linear-gradient(165deg,rgba(255,255,255,.06) 0%,rgba(255,255,255,.022) 45%,rgba(8,12,20,.35) 100%);
  box-shadow:
    0 0 0 1px rgba(125,211,252,.1),
    0 22px 56px rgba(0,0,0,.3),
    0 1px 0 rgba(255,255,255,.07) inset;
}
.iso-page.iso-page--hub .iso-norms-hero-wrap .content-card-head{padding-bottom:6px;border-bottom:1px solid rgba(125,211,252,.1);margin-bottom:4px}
.iso-page.iso-page--hub .iso-norms-hero-wrap .content-card-head h3{
  font-size:1.32rem;
  letter-spacing:-.025em;
}
.iso-page.iso-page--hub .iso-norms-hero-wrap .content-card-lead{
  max-width:62ch;
  line-height:1.55;
  color:var(--text2);
}
.iso-page.iso-page--hub .iso-norms-hero-wrap .iso-norms-grid{
  margin-top:14px;
  gap:14px;
}
.iso-page.iso-page--hub .iso-norm-card--hero{
  padding:16px 18px;
  border-radius:16px;
  border-color:rgba(148,163,184,.2);
  background:linear-gradient(180deg,rgba(255,255,255,.055),rgba(255,255,255,.012));
}
.iso-page.iso-page--hub .iso-norm-card--hero .iso-norm-title{
  margin:6px 0 6px;
  font-size:14px;
  font-weight:700;
  line-height:1.3;
}
.iso-page.iso-page--hub .iso-norm-card--hero .iso-norm-hint{
  margin:10px 0 0;
  font-size:12px;
  line-height:1.45;
}
/* IA : second palier fort, halo distinct des cartes neutres */
.iso-page.iso-page--hub .iso-ai-spotlight{
  position:relative;
  overflow:hidden;
  border-radius:18px;
  padding:22px 26px 24px;
  border:1px solid rgba(125,211,252,.32);
  background:linear-gradient(135deg,rgba(56,189,248,.16),rgba(168,85,247,.1),rgba(255,255,255,.028));
  box-shadow:
    0 1px 0 rgba(255,255,255,.07) inset,
    0 0 0 1px rgba(56,189,248,.08),
    0 16px 48px rgba(0,0,0,.22);
}
.iso-page.iso-page--hub .iso-ai-spotlight::before{
  content:'';
  position:absolute;
  inset:0;
  background:radial-gradient(ellipse 70% 55% at 15% -10%,rgba(56,189,248,.2),transparent 52%);
  pointer-events:none;
}
.iso-page.iso-page--hub .iso-ai-spotlight>*{
  position:relative;
  z-index:1;
}
.iso-page.iso-page--hub .iso-ai-spotlight .iso-ai-badge{
  display:inline-flex;
  align-items:center;
  gap:6px;
  font-size:10px;
  font-weight:800;
  letter-spacing:.14em;
  text-transform:uppercase;
  color:#a5f3fc;
  margin-bottom:10px;
}
.iso-page.iso-page--hub .iso-ai-spotlight h3{
  margin:0 0 10px;
  font-size:1.3rem;
  font-weight:800;
  letter-spacing:-.02em;
  color:var(--text);
}
.iso-page.iso-page--hub .iso-ai-spotlight .iso-ai-lead{
  margin:0;
  font-size:13.5px;
  line-height:1.62;
  color:var(--text2);
  max-width:72ch;
}
.iso-page.iso-page--hub .iso-ai-spotlight .iso-ai-steps{
  margin:18px 0 0;
  padding:0;
  list-style:none;
  display:flex;
  flex-wrap:wrap;
  gap:12px;
}
.iso-page.iso-page--hub .iso-ai-spotlight .iso-ai-steps li{
  font-size:12px;
  font-weight:600;
  color:var(--text2);
  padding:10px 14px;
  border-radius:12px;
  background:rgba(0,0,0,.26);
  border:1px solid rgba(125,211,252,.2);
  line-height:1.4;
}
/* Actions prioritaires : palier intermédiaire (ni héros ni liste plate) */
.iso-page.iso-page--hub .iso-points-panel{
  margin-top:0;
  padding:22px 24px 24px;
  border-radius:18px;
  border:1px solid rgba(148,163,184,.17);
  background:linear-gradient(180deg,rgba(0,0,0,.2),rgba(0,0,0,.11));
  box-shadow:0 10px 32px rgba(0,0,0,.2);
}
.iso-page.iso-page--hub .iso-actions-priority-section .iso-points-panel-title{
  font-size:1.07rem;
  letter-spacing:-.018em;
}
.iso-page.iso-page--hub .iso-points-panel-title{margin-bottom:8px}
.iso-page.iso-page--hub .iso-points-panel-lead{margin-bottom:20px;line-height:1.55}
.iso-page.iso-page--hub .iso-points-grid{gap:16px}
.iso-page.iso-page--hub .iso-points-col{
  padding:16px 18px;
  border-radius:14px;
  background:rgba(255,255,255,.025);
  border-color:rgba(148,163,184,.11);
}
.iso-page.iso-page--hub .iso-points-list{gap:12px}
/* Cartes détail (exigences, docs, revue) : palier bas — moins d’élévation */
.iso-page.iso-page--hub .two-column .content-card.card-soft,
.iso-page.iso-page--hub>article.content-card.card-soft:not(.iso-header-card){
  background:rgba(0,0,0,.065);
  border:1px solid rgba(148,163,184,.09);
  box-shadow:none;
  border-radius:15px;
}
.iso-page.iso-page--hub .two-column .content-card .content-card-head{
  border-bottom:1px solid rgba(255,255,255,.05);
  padding-bottom:12px;
  margin-bottom:4px;
}
.iso-page.iso-page--hub .iso-section-stack{gap:18px}
.iso-page.iso-page--hub .iso-pilotage-aside{gap:18px}
.iso-page.iso-page--hub .iso-req-hot-wrap{gap:12px;margin-top:10px}
.iso-page.iso-page--hub .iso-req-hot-item{
  padding:14px 16px;
  border-radius:14px;
  background:rgba(255,255,255,.02);
  border-color:rgba(148,163,184,.1);
}
.iso-page.iso-page--hub .two-column{gap:20px}
`;

export function ensureIsoPageStyles() {
  if (document.getElementById(STYLE_ID)) return;
  const el = document.createElement('style');
  el.id = STYLE_ID;
  el.textContent = CSS;
  document.head.append(el);
}
