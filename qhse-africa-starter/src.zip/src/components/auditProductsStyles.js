const STYLE_ID = 'qhse-audit-products-styles';

const CSS = `
.audit-products-page .audit-last-card{border:1px solid rgba(148,163,184,.12)}
.audit-last-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:14px;margin-top:12px}
.audit-last-item{display:grid;gap:4px}
.audit-last-item span:first-child{font-size:10px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--text3)}
.audit-last-item span:last-child{font-size:14px;font-weight:700;color:var(--text)}
.audit-last-score{font-size:28px;font-weight:800;letter-spacing:-.03em}
.audit-checklist-head{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:10px}
.audit-checklist-row{align-items:center}
.audit-score-panel{text-align:center}
.audit-score-gauge-wrap{display:grid;place-items:center;margin:8px 0 12px}
.audit-score-gauge{width:160px;height:160px;border-radius:50%;box-shadow:0 12px 32px rgba(0,0,0,.2)}
.audit-score-gauge-inner{display:grid;place-items:center;width:160px;height:160px;margin-top:-160px;position:relative;pointer-events:none}
.audit-score-gauge-inner strong{font-size:36px;font-weight:800;letter-spacing:-.04em}
.audit-score-gauge-inner small{display:block;font-size:12px;color:var(--text3);margin-top:2px}
.audit-history-stack{display:grid;gap:8px}
.audit-history-row{padding:12px 14px}
.audit-actions-bar{margin-top:16px;display:flex;justify-content:flex-end}
.audit-right-stack{display:grid;gap:14px;min-width:0}
.products-toolbar{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:14px;align-items:center}
.products-toolbar .control-input{max-width:320px;flex:1;min-width:200px}
.products-list{display:grid;gap:10px}
.products-row{display:flex;justify-content:space-between;align-items:flex-start;gap:14px;flex-wrap:wrap}
.products-row-main{min-width:0;flex:1}
.products-row-actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
.products-actions-bar{margin-top:16px;display:flex;justify-content:flex-end}
`;

export function ensureAuditProductsStyles() {
  if (document.getElementById(STYLE_ID)) return;
  const el = document.createElement('style');
  el.id = STYLE_ID;
  el.textContent = CSS;
  document.head.append(el);
}
