/**
 * Analyse automatique — jusqu’à 3 insights avec recommandations et micro-actions.
 */

import { computeIncidentWeekMetrics } from '../utils/dashboardIncidentMetrics.js';
import { createDashboardBlockActions, goDashboardPage } from '../utils/dashboardBlockActions.js';

const MAX_INSIGHTS = 3;

/** @typedef {'actions' | 'incidents' | 'compliance' | 'calm'} InsightAccent */

function isNcOpen(row) {
  const s = String(row?.status || '').toLowerCase();
  if (!s) return true;
  if (/(clos|ferm|done|termin|clôtur|résolu|resolu|complete)/i.test(s)) return false;
  return true;
}

/**
 * @typedef {{ label: string; pageId: string }} InsightLink
 * @typedef {{
 *   message: string;
 *   recommendation: string;
 *   see: InsightLink;
 *   apply: InsightLink;
 *   accent: InsightAccent;
 * }} Insight
 */

/**
 * @param {{
 *   stats?: { overdueActions?: number; incidents?: number; actions?: number };
 *   incidents?: unknown[];
 *   ncs?: unknown[];
 * }} input
 * @returns {Insight[]}
 */
export function computeAutoAnalysisInsights(input) {
  const stats = input?.stats || {};
  const incidents = Array.isArray(input?.incidents) ? input.incidents : [];
  const ncs = Array.isArray(input?.ncs) ? input.ncs : [];

  const od = Math.max(0, Number(stats.overdueActions) || 0);
  const openNc = ncs.filter(isNcOpen).length;

  const now = Date.now();
  const { last7, spike } = computeIncidentWeekMetrics(incidents, now);

  /** @type {Insight[]} */
  const items = [];

  if (od >= 2) {
    items.push({
      accent: 'actions',
      message:
        'Plusieurs actions traînent au-delà de l’échéance : c’est souvent le signal le plus visible pour les équipes.',
      recommendation:
        'En réunion courte, tranchez qui fait quoi cette semaine — ou affichez publiquement une nouvelle date réaliste, plutôt que de laisser filer.',
      see: { label: 'Voir les actions', pageId: 'actions' },
      apply: { label: 'Prioriser le plan', pageId: 'actions' }
    });
  } else if (od === 1) {
    items.push({
      accent: 'actions',
      message:
        'Une action est en retard : un seul glissement peut donner le ton sur toute la discipline d’exécution.',
      recommendation:
        'Quelqu’un doit clôturer ou replanifier aujourd’hui, avec un commentaire lisible pour la direction.',
      see: { label: 'Voir les actions', pageId: 'actions' },
      apply: { label: 'Mettre à jour', pageId: 'actions' }
    });
  }

  if (spike || last7 >= 4) {
    items.push({
      accent: 'incidents',
      message: spike
        ? 'Les incidents récents montrent un pic : le terrain envoie un signal qu’il faut entendre vite.'
        : 'Le volume d’incidents sur la période récente est élevé par rapport à l’habitude.',
      recommendation:
        'Regardez d’abord le « quoi » et le « où », puis décidez si c’est un incident isolé ou un symptôme de dérive — la réponse n’est pas toujours une action de plus.',
      see: { label: 'Voir les incidents', pageId: 'incidents' },
      apply: { label: 'Creuser les causes', pageId: 'incidents' }
    });
  }

  if (openNc >= 1) {
    items.push({
      accent: 'compliance',
      message:
        openNc >= 3
          ? 'Plusieurs non-conformités restent ouvertes : le registre commence à peser sur la crédibilité du SMS.'
          : 'Au moins une non-conformité attend encore une décision ou une preuve de clôture.',
      recommendation:
        openNc >= 3
          ? 'Bloquez un créneau avec les porteurs : soit on clôture, soit on assume un report explicite avec justification.'
          : 'Avancez le plan associé ou documentez pourquoi ce n’est pas encore clos — l’auditeur suivant le demandera.',
      see: { label: 'Voir audits & NC', pageId: 'audits' },
      apply: { label: 'Relancer les plans', pageId: 'actions' }
    });
  }

  const totalInc = Number(stats.incidents);
  const totalAct = Number(stats.actions);
  const aggLow =
    Number.isFinite(totalInc) &&
    Number.isFinite(totalAct) &&
    totalInc === 0 &&
    totalAct === 0 &&
    od === 0 &&
    openNc === 0 &&
    last7 === 0;

  if (aggLow && items.length < MAX_INSIGHTS) {
    items.push({
      accent: 'calm',
      message:
        'Les chiffres agrégés sont calmes sur ce filtre — soit la situation est saine, soit la donnée n’est pas encore là.',
      recommendation:
        'Un coup d’œil terrain (incidents, actions) suffit à confirmer : mieux vaut une vraie absence d’événement qu’un trou dans la saisie.',
      see: { label: 'Voir les incidents', pageId: 'incidents' },
      apply: { label: 'Préparer un audit', pageId: 'audits' }
    });
  }

  return items.slice(0, MAX_INSIGHTS);
}

/**
 * @param {HTMLElement} parent
 * @param {InsightLink} see
 * @param {InsightLink} apply
 */
function appendInsightActions(parent, see, apply) {
  const row = document.createElement('div');
  row.className = 'dashboard-auto-analysis-item-acts';

  const mk = (link, cls) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = `dashboard-auto-analysis-act ${cls}`;
    b.textContent = link.label;
    b.addEventListener('click', () => goDashboardPage(link.pageId));
    return b;
  };

  row.append(mk(see, 'dashboard-auto-analysis-act--see'));
  row.append(mk(apply, 'dashboard-auto-analysis-act--apply'));
  parent.append(row);
}

export function createDashboardAutoAnalysis() {
  const card = document.createElement('article');
  card.className = 'content-card card-soft dashboard-auto-analysis-card';

  const strip = document.createElement('div');
  strip.className = 'dashboard-auto-analysis-strip';
  const stripBadge = document.createElement('span');
  stripBadge.className = 'dashboard-auto-analysis-strip-badge';
  stripBadge.textContent = 'Assistant de pilotage';
  const stripText = document.createElement('p');
  stripText.className = 'dashboard-auto-analysis-strip-text';
  strip.append(stripBadge, stripText);

  const host = document.createElement('div');
  host.className = 'dashboard-auto-analysis-host';
  card.append(strip, host);

  function update(payload) {
    card.querySelector('.dashboard-auto-analysis-actions')?.remove();
    const insights = computeAutoAnalysisInsights(payload || {});

    stripText.textContent =
      insights.length === 0
        ? 'Aucun signal fort ne ressort des règles simples appliquées ici — la suite se lit dans la situation et les alertes.'
        : `${insights.length} lecture${insights.length > 1 ? 's' : ''} utile${insights.length > 1 ? 's' : ''} à partir des retards, incidents et NC visibles.`;

    host.replaceChildren();

    if (!insights.length) {
      const block = document.createElement('div');
      block.className = 'dashboard-auto-analysis-empty-block';
      const icon = document.createElement('div');
      icon.className = 'dashboard-auto-analysis-empty-icon';
      icon.setAttribute('aria-hidden', 'true');
      const check = document.createElement('span');
      check.className = 'dashboard-auto-analysis-empty-check';
      check.textContent = '✓';
      icon.append(check);
      const copy = document.createElement('div');
      copy.className = 'dashboard-auto-analysis-empty-copy';
      const p = document.createElement('p');
      p.className = 'dashboard-auto-analysis-empty-lead';
      p.textContent = 'Rien qui crie au feu sur les règles qu’on applique ici';
      const sub = document.createElement('p');
      sub.className = 'dashboard-auto-analysis-empty-detail';
      sub.textContent =
        'Ce n’est pas une garantie absolue : ça veut dire que les seuils simples (retards, pics, NC) ne sont pas franchis. Gardez un œil sur la situation écrite au-dessus et sur vos alertes.';
      copy.append(p, sub);
      block.append(icon, copy);
      host.append(block);
    } else {
      const list = document.createElement('ul');
      list.className = 'dashboard-auto-analysis-list';
      insights.forEach(({ message, recommendation, see, apply, accent }, i) => {
        const li = document.createElement('li');
        li.className = `dashboard-auto-analysis-item dashboard-auto-analysis-item--accent-${accent}`;

        const idx = document.createElement('span');
        idx.className = 'dashboard-auto-analysis-item-index';
        idx.textContent = String(i + 1);

        const body = document.createElement('div');
        body.className = 'dashboard-auto-analysis-item-body';

        const fieldMsg = document.createElement('div');
        fieldMsg.className = 'dashboard-auto-analysis-field';
        const lblM = document.createElement('span');
        lblM.className = 'dashboard-auto-analysis-field-lbl';
        lblM.textContent = 'Ce que ça dit';
        const msg = document.createElement('p');
        msg.className = 'dashboard-auto-analysis-msg';
        msg.textContent = message;
        fieldMsg.append(lblM, msg);

        const fieldRec = document.createElement('div');
        fieldRec.className = 'dashboard-auto-analysis-field';
        const lblR = document.createElement('span');
        lblR.className = 'dashboard-auto-analysis-field-lbl';
        lblR.textContent = 'Piste concrète';
        const rec = document.createElement('p');
        rec.className = 'dashboard-auto-analysis-rec';
        rec.textContent = recommendation;
        fieldRec.append(lblR, rec);

        body.append(fieldMsg, fieldRec);
        appendInsightActions(body, see, apply);
        li.append(idx, body);
        list.append(li);
      });
      host.append(list);
    }

    const actWrap = document.createElement('div');
    actWrap.className = 'dashboard-auto-analysis-actions';
    const specs = insights.length
      ? [
          { label: 'Synthèse actions', pageId: 'actions' },
          { label: 'Synthèse incidents', pageId: 'incidents' }
        ]
      : [
          { label: 'Voir les incidents', pageId: 'incidents' },
          { label: 'Ouvrir les audits', pageId: 'audits' }
        ];
    const bar = createDashboardBlockActions(specs, {
      className: 'dashboard-block-actions dashboard-block-actions--tight'
    });
    if (bar) actWrap.append(bar);
    if (actWrap.childNodes.length) card.append(actWrap);
  }

  return { root: card, update };
}
