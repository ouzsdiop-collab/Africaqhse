import { showToast } from '../components/toast.js';
import { ensureAuditProductsStyles } from '../components/auditProductsStyles.js';

/** Registre produits / FDS — données mock */
const PRODUCT_REGISTRY = [
  {
    name: 'Acide sulfurique',
    cas: '7664-93-9',
    site: 'Site principal',
    danger: 'élevé',
    revision: '02/2026'
  },
  {
    name: 'Gasoil industriel',
    cas: '68334-30-5',
    site: 'Zone carburants',
    danger: 'élevé',
    revision: '01/2026'
  },
  {
    name: 'Soude caustique',
    cas: '1310-73-2',
    site: 'Atelier chimie',
    danger: 'moyen',
    revision: '11/2025'
  },
  {
    name: 'Antigel technique',
    cas: '107-21-1',
    site: 'Magasin général',
    danger: 'faible',
    revision: '09/2025'
  }
];

function dangerTone(d) {
  const t = String(d).toLowerCase();
  if (t.includes('élev') || t.includes('elev')) return { cls: 'red', label: 'Élevé' };
  if (t.includes('moyen')) return { cls: 'amber', label: 'Moyen' };
  return { cls: 'green', label: 'Faible' };
}

function matchesFilter(p, q) {
  if (!q) return true;
  const s = `${p.name} ${p.cas} ${p.site}`.toLowerCase();
  return s.includes(q);
}

function createProductRow(product) {
  const row = document.createElement('article');
  row.className = 'list-row products-row';
  const d = dangerTone(product.danger);

  const main = document.createElement('div');
  main.className = 'products-row-main';
  main.innerHTML = `
    <strong>${product.name}</strong>
    <p style="margin:6px 0 0;font-size:13px;color:var(--text2)">CAS ${product.cas} · ${product.site}</p>
    <p style="margin:4px 0 0;font-size:12px;color:var(--text3)">FDS révisée ${product.revision}</p>
  `;

  const actions = document.createElement('div');
  actions.className = 'products-row-actions';

  const badge = document.createElement('span');
  badge.className = `badge ${d.cls}`;
  badge.textContent = `Danger ${d.label}`;

  const btnFds = document.createElement('button');
  btnFds.type = 'button';
  btnFds.className = 'btn';
  btnFds.textContent = 'Voir FDS';
  btnFds.addEventListener('click', () => {
    showToast(`FDS ${product.name} — ouverture document (démo).`, 'info');
  });

  const btnDet = document.createElement('button');
  btnDet.type = 'button';
  btnDet.className = 'btn btn-primary';
  btnDet.textContent = 'Détails';
  btnDet.addEventListener('click', () => {
    showToast(`Fiche produit ${product.name} (démo).`, 'info');
  });

  actions.append(badge, btnFds, btnDet);
  row.append(main, actions);
  return row;
}

export function renderProducts() {
  ensureAuditProductsStyles();

  const page = document.createElement('section');
  page.className = 'page-stack audit-products-page';

  const card = document.createElement('article');
  card.className = 'content-card card-soft';
  card.innerHTML = `
    <div class="content-card-head">
      <div>
        <div class="section-kicker">Sécurité chimique</div>
        <h3>Registre produits / FDS</h3>
        <p style="margin:0;font-size:13px;color:var(--text2);max-width:56ch">
          Stockage et danger — recherche locale sur le registre mock.
        </p>
      </div>
    </div>
    <div class="products-toolbar">
      <input type="search" class="control-input products-search" placeholder="Rechercher un produit, un CAS, un site…" autocomplete="off" />
    </div>
  `;

  const listHost = document.createElement('div');
  listHost.className = 'products-list';

  const input = card.querySelector('.products-search');

  function refreshList() {
    const q = (input.value || '').trim().toLowerCase();
    listHost.replaceChildren();
    PRODUCT_REGISTRY.filter((p) => matchesFilter(p, q)).forEach((p) => listHost.append(createProductRow(p)));
    if (!listHost.children.length) {
      const empty = document.createElement('p');
      empty.style.margin = '0';
      empty.style.fontSize = '13px';
      empty.style.color = 'var(--text3)';
      empty.textContent = 'Aucun produit ne correspond à la recherche.';
      listHost.append(empty);
    }
  }

  input.addEventListener('input', refreshList);

  const bar = document.createElement('div');
  bar.className = 'products-actions-bar';
  const addBtn = document.createElement('button');
  addBtn.type = 'button';
  addBtn.className = 'btn btn-primary';
  addBtn.textContent = 'Ajouter un produit';
  addBtn.addEventListener('click', () => {
    showToast('Ajout produit / FDS : formulaire à brancher (démo).', 'info');
  });
  bar.append(addBtn);

  card.append(listHost);
  page.append(card, bar);

  refreshList();
  return page;
}
