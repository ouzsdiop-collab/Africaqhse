import { showToast } from '../components/toast.js';
import { ensureIsoPageStyles } from '../components/isoPageStyles.js';
import { ensureQhsePilotageStyles } from '../components/qhsePilotageStyles.js';
import { openComplianceAssistModal } from '../components/isoComplianceAssistPanel.js';
import { appState } from '../utils/state.js';
import {
  getRequirements,
  getNormById,
  setRequirementStatus,
  CONTROLLED_DOCUMENTS,
  computeComplianceSummary,
  DOCUMENT_ATTENTION,
  AUDITS_TO_SCHEDULE,
  CONFORMITY_NORMS
} from '../data/conformityStore.js';

/** Normes — cartes allégées (statut + une phrase). */
const NORMS_LITE = [
  {
    id: 'ISO 9001',
    status: 'Sous contrôle',
    badge: 'amber',
    line: 'Réserves mineures : plan qualité en cours.'
  },
  {
    id: 'ISO 14001',
    status: 'Conforme',
    badge: 'green',
    line: 'Dernier audit interne sans écart majeur.'
  },
  {
    id: 'ISO 45001',
    status: 'À surveiller',
    badge: 'amber',
    line: 'Point habilitations — clôture visée mi-avril.'
  }
];

const REVIEW_PREP = [
  { label: 'Incidents', value: '4', detail: '3 clos · 1 analyse en cours (terrain nord)' },
  { label: 'Audits', value: '2', detail: '1 interne planifié · 1 surveillance ISO' },
  { label: 'Actions', value: '12', detail: '7 en retard < 15 j · 5 dans les délais' },
  { label: 'Indicateurs', value: '8/10', detail: '2 indicateurs en attente de consolidation groupe' }
];

/**
 * @param {'conforme'|'partiel'|'non_conforme'} st
 */
function conformityBadgeClass(st) {
  if (st === 'conforme') return 'green';
  if (st === 'partiel') return 'amber';
  return 'red';
}

/**
 * @param {'conforme'|'partiel'|'non_conforme'} st
 */
function conformityLabel(st) {
  if (st === 'conforme') return 'Conforme';
  if (st === 'partiel') return 'Partiel';
  return 'Non conforme';
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/**
 * @param {ReturnType<typeof computeComplianceSummary>} s
 */
function createGlobalSnapshot(s) {
  const wrap = document.createElement('div');
  wrap.className = `iso-global-snapshot iso-global-snapshot--${s.globalTone}`;
  wrap.innerHTML = `
    <div class="iso-global-snapshot-inner">
      <div class="iso-global-score" aria-label="Score de conformité">
        <span class="iso-global-pct">${s.pct}</span>
        <span class="iso-global-pct-suffix">%</span>
        <div class="iso-global-score-caption">conformité (exigences)</div>
      </div>
      <div class="iso-global-copy">
        <div class="iso-global-label">${escapeHtml(s.globalLabel)}</div>
        <p class="iso-global-message">${escapeHtml(s.message)}</p>
        <div class="iso-global-meta" aria-hidden="true"></div>
      </div>
    </div>
  `;
  const meta = wrap.querySelector('.iso-global-meta');
  if (meta) {
    meta.textContent = `${s.ok} conforme(s) · ${s.partial} partiel(le)(s) · ${s.nonOk} non conforme(s)`;
  }
  return wrap;
}

/**
 * @param {HTMLElement} el
 * @param {ReturnType<typeof computeComplianceSummary>} s
 */
function updateGlobalSnapshot(el, s) {
  el.className = `iso-global-snapshot iso-global-snapshot--${s.globalTone}`;
  const pct = el.querySelector('.iso-global-pct');
  const label = el.querySelector('.iso-global-label');
  const message = el.querySelector('.iso-global-message');
  const meta = el.querySelector('.iso-global-meta');
  if (pct) pct.textContent = String(s.pct);
  if (label) label.textContent = s.globalLabel;
  if (message) message.textContent = s.message;
  if (meta) meta.textContent = `${s.ok} conforme(s) · ${s.partial} partiel(le)(s) · ${s.nonOk} non conforme(s)`;
}

/**
 * @param {(row: Record<string, unknown> & { normCode: string }) => void} onAnalyze
 */
function buildPointsPanel(onAnalyze) {
  const panel = document.createElement('section');
  panel.className = 'iso-points-panel iso-actions-priority-section';
  panel.setAttribute('aria-labelledby', 'iso-points-title');

  const title = document.createElement('h3');
  title.id = 'iso-points-title';
  title.className = 'iso-points-panel-title';
  title.textContent = 'Actions prioritaires';

  const lead = document.createElement('p');
  lead.className = 'iso-points-panel-lead';
  lead.textContent = 'Ce qui demande une action maintenant — exigences, documents et audits.';

  const grid = document.createElement('div');
  grid.className = 'iso-points-grid';

  const colReq = document.createElement('div');
  colReq.className = 'iso-points-col';
  const colDoc = document.createElement('div');
  colDoc.className = 'iso-points-col';
  const colAud = document.createElement('div');
  colAud.className = 'iso-points-col';

  grid.append(colReq, colDoc, colAud);
  panel.append(title, lead, grid);

  function renderColContent() {
    const reqs = getRequirements().filter((r) => r.status !== 'conforme');
    const { missing, obsolete, critical } = DOCUMENT_ATTENTION;

    colReq.innerHTML = '';
    const hReq = document.createElement('div');
    hReq.className = 'iso-points-col-head';
    hReq.innerHTML = `<span class="iso-points-icon iso-points-icon--req" aria-hidden="true"></span><span>Exigences</span>`;
    const metricReq = document.createElement('div');
    metricReq.className = 'iso-points-metric';
    metricReq.textContent = reqs.length ? `${reqs.length} à consolider ou corriger` : 'Aucune exigence en écart';
    const listReq = document.createElement('ul');
    listReq.className = 'iso-points-list';
    if (reqs.length === 0) {
      const li = document.createElement('li');
      li.className = 'iso-points-list-empty';
      li.textContent = 'Toutes les exigences suivies sont au vert.';
      listReq.append(li);
    } else {
      reqs.slice(0, 4).forEach((row) => {
        const norm = getNormById(row.normId);
        const normCode = norm ? norm.code : row.normId;
        const li = document.createElement('li');
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'iso-points-action-link';
        btn.textContent = `${row.clause} — ${row.title}`;
        btn.addEventListener('click', () => onAnalyze({ ...row, normCode }));
        const badge = document.createElement('span');
        badge.className = `badge ${conformityBadgeClass(row.status)} iso-points-mini-badge`;
        badge.textContent = conformityLabel(row.status);
        li.append(btn, document.createTextNode(' '), badge, document.createElement('br'));
        const sub = document.createElement('span');
        sub.className = 'iso-points-list-sub';
        sub.textContent = normCode;
        li.append(sub);
        listReq.append(li);
      });
      if (reqs.length > 4) {
        const li = document.createElement('li');
        li.className = 'iso-points-list-more';
        li.textContent = `+ ${reqs.length - 4} autre(s) — voir « toutes les exigences » ci-dessous.`;
        listReq.append(li);
      }
    }
    colReq.append(hReq, metricReq, listReq);

    colDoc.innerHTML = '';
    const hDoc = document.createElement('div');
    hDoc.className = 'iso-points-col-head';
    hDoc.innerHTML = `<span class="iso-points-icon iso-points-icon--doc" aria-hidden="true"></span><span>Documents</span>`;
    const nMiss = missing.length;
    const nObs = obsolete.length;
    const nCrit = critical.length;
    const metricDoc = document.createElement('div');
    metricDoc.className = 'iso-points-metric';
    if (nMiss + nObs + nCrit === 0) {
      metricDoc.textContent = 'Aucun document critique signalé';
    } else {
      const parts = [];
      if (nMiss) parts.push(`${nMiss} manquant(s)`);
      if (nObs) parts.push(`${nObs} obsolète(s)`);
      if (nCrit) parts.push(`${nCrit} critique(s)`);
      metricDoc.textContent = parts.join(' · ');
    }
    const listDoc = document.createElement('ul');
    listDoc.className = 'iso-points-list';
    const pushDocItem = (label, name, note) => {
      const li = document.createElement('li');
      const tag = document.createElement('span');
      tag.className = 'iso-points-doc-tag';
      tag.textContent = label;
      const strong = document.createElement('strong');
      strong.textContent = name;
      const p = document.createElement('p');
      p.className = 'iso-points-list-note';
      p.textContent = note;
      li.append(tag, strong, p);
      listDoc.append(li);
    };
    missing.forEach((d) => pushDocItem('Manquant', d.name, d.note));
    obsolete.forEach((d) => pushDocItem('Obsolète', d.name + (d.version ? ` v${d.version}` : ''), d.note));
    critical.forEach((d) => pushDocItem('Critique', d.name + (d.version ? ` v${d.version}` : ''), d.note));
    if (listDoc.children.length === 0) {
      const li = document.createElement('li');
      li.className = 'iso-points-list-empty';
      li.textContent = 'Rien à signaler sur les documents prioritaires.';
      listDoc.append(li);
    }
    colDoc.append(hDoc, metricDoc, listDoc);

    colAud.innerHTML = '';
    const hAud = document.createElement('div');
    hAud.className = 'iso-points-col-head';
    hAud.innerHTML = `<span class="iso-points-icon iso-points-icon--aud" aria-hidden="true"></span><span>Audits à faire</span>`;
    const metricAud = document.createElement('div');
    metricAud.className = 'iso-points-metric';
    metricAud.textContent = AUDITS_TO_SCHEDULE.length
      ? `${AUDITS_TO_SCHEDULE.length} échéance(s) à piloter`
      : 'Aucun audit planifié (démo)';
    const listAud = document.createElement('ul');
    listAud.className = 'iso-points-list';
    AUDITS_TO_SCHEDULE.forEach((a) => {
      const li = document.createElement('li');
      li.innerHTML = `<strong>${escapeHtml(a.title)}</strong><p class="iso-points-list-note">${escapeHtml(
        a.horizon
      )}<span class="iso-points-list-sub"> · ${escapeHtml(a.owner)}</span></p>`;
      listAud.append(li);
    });
    if (AUDITS_TO_SCHEDULE.length === 0) {
      const li = document.createElement('li');
      li.className = 'iso-points-list-empty';
      li.textContent = 'Ajoutez vos audits dans le planning (à brancher).';
      listAud.append(li);
    }
    colAud.append(hAud, metricAud, listAud);
  }

  renderColContent();
  return { panel, renderColContent };
}

/**
 * @param {{
 *   id: string;
 *   status: string;
 *   badge: string;
 *   line: string;
 *   title?: string;
 *   statsTotal?: number;
 *   statsNonOk?: number;
 * }} norm
 */
function createNormCardLite(norm) {
  const card = document.createElement('article');
  card.className = 'iso-norm-card iso-norm-card--lite iso-norm-card--hero';
  const top = document.createElement('div');
  top.className = 'iso-norm-card-top';
  const id = document.createElement('span');
  id.className = 'iso-norm-id';
  id.textContent = norm.id;
  const badge = document.createElement('span');
  badge.className = `badge ${norm.badge}`;
  badge.textContent = norm.status;
  top.append(id, badge);
  card.append(top);
  if (norm.title) {
    const t = document.createElement('h4');
    t.className = 'iso-norm-title';
    t.textContent = norm.title;
    card.append(t);
  }
  const line = document.createElement('p');
  line.className = 'iso-norm-line';
  line.textContent = norm.line;
  card.append(line);
  if (norm.statsTotal != null) {
    const hint = document.createElement('p');
    hint.className = 'iso-norm-hint';
    const ok = norm.statsTotal - (norm.statsNonOk ?? 0);
    hint.textContent =
      norm.statsNonOk && norm.statsNonOk > 0
        ? `${norm.statsTotal} exigence(s) suivie(s) · ${norm.statsNonOk} en écart · ${ok} au vert`
        : `${norm.statsTotal} exigence(s) suivie(s) · aucun écart sur ce référentiel`;
    card.append(hint);
  }
  return card;
}

/**
 * @param {{
 *   onAnalyze: (row: Record<string, unknown> & { normCode: string }) => void;
 *   refreshTable: () => void;
 * }} ctx
 */
function createRequirementsTable(ctx) {
  const wrap = document.createElement('div');
  wrap.className = 'iso-table-wrap iso-table-wrap--req';

  const table = document.createElement('div');
  table.className = 'iso-table iso-req-table';

  const head = document.createElement('div');
  head.className = 'iso-table-head';
  head.innerHTML = `
    <span>Exigence</span>
    <span>Statut</span>
    <span>Assistance</span>
    <span>Responsable</span>
    <span>Preuve documentaire</span>
  `;
  table.append(head);

  function renderRows() {
    table.querySelectorAll('.iso-table-row').forEach((el) => el.remove());
    const rows = getRequirements();
    rows.forEach((row) => {
      const norm = getNormById(row.normId);
      const normCode = norm ? norm.code : row.normId;

      const line = document.createElement('div');
      line.className = 'iso-table-row';
      const stClass = conformityBadgeClass(row.status);
      const badgeLabel = conformityLabel(row.status);

      const exigence = document.createElement('span');
      exigence.className = 'iso-cell-strong';
      exigence.innerHTML = `${escapeHtml(row.clause)} — ${escapeHtml(row.title)}<br/><span class="iso-cell-muted iso-cell-small">${escapeHtml(
        normCode
      )}</span>`;

      const statCell = document.createElement('span');
      statCell.innerHTML = `<span class="badge ${stClass}">${escapeHtml(badgeLabel)}</span>`;

      const assistCell = document.createElement('span');
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'btn btn-secondary iso-analyze-btn';
      btn.textContent = 'Analyser conformité';
      btn.addEventListener('click', () => ctx.onAnalyze({ ...row, normCode }));
      assistCell.append(btn);

      const owner = document.createElement('span');
      owner.className = 'iso-cell-muted';
      owner.textContent = row.owner;

      const proof = document.createElement('span');
      proof.className = 'iso-cell-muted';
      proof.textContent = row.evidence;

      line.append(exigence, statCell, assistCell, owner, proof);
      table.append(line);
    });
  }

  renderRows();
  ctx.refreshTable = renderRows;
  wrap.append(table);
  return wrap;
}

/**
 * @param {{ onAnalyze: (row: Record<string, unknown> & { normCode: string }) => void }} ctx
 * @param {{ refreshHotList?: () => void }} [ref]
 */
function createRequirementsHotList(ctx, ref) {
  const wrap = document.createElement('div');
  wrap.className = 'iso-req-hot-wrap';

  function render() {
    wrap.innerHTML = '';
    const problematic = getRequirements().filter((r) => r.status !== 'conforme');
    if (problematic.length === 0) {
      const empty = document.createElement('p');
      empty.className = 'iso-req-hot-empty';
      empty.textContent =
        'Aucune exigence problématique : les écarts partiels et non conformes apparaîtront ici pour action rapide.';
      wrap.append(empty);
      return;
    }
    problematic.forEach((row) => {
      const norm = getNormById(row.normId);
      const normCode = norm ? norm.code : row.normId;
      const item = document.createElement('div');
      item.className = 'iso-req-hot-item';
      const left = document.createElement('div');
      left.className = 'iso-req-hot-main';
      const title = document.createElement('div');
      title.className = 'iso-req-hot-title';
      title.textContent = `${row.clause} — ${row.title}`;
      const sub = document.createElement('div');
      sub.className = 'iso-req-hot-sub';
      sub.textContent = `${normCode} · ${row.owner}`;
      left.append(title, sub);
      const badge = document.createElement('span');
      badge.className = `badge ${conformityBadgeClass(row.status)}`;
      badge.textContent = conformityLabel(row.status);
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'btn btn-primary iso-req-hot-btn';
      btn.textContent = 'Traiter';
      btn.addEventListener('click', () => ctx.onAnalyze({ ...row, normCode }));
      item.append(left, badge, btn);
      wrap.append(item);
    });
  }

  if (ref) ref.refreshHotList = render;
  render();
  return wrap;
}

function createDocumentsTable() {
  const wrap = document.createElement('div');
  wrap.className = 'iso-table-wrap';
  const table = document.createElement('div');
  table.className = 'iso-table iso-doc-table';
  const head = document.createElement('div');
  head.className = 'iso-table-head';
  head.innerHTML = `<span>Document</span><span>Version</span><span>Révision</span><span>Propriétaire</span>`;
  table.append(head);
  CONTROLLED_DOCUMENTS.forEach((row) => {
    const line = document.createElement('div');
    line.className = 'iso-table-row';
    line.innerHTML = `
      <span class="iso-cell-strong">${escapeHtml(row.name)}</span>
      <span class="iso-cell-muted">${escapeHtml(row.version || '—')}</span>
      <span class="iso-cell-muted">—</span>
      <span class="iso-cell-muted">—</span>
    `;
    table.append(line);
  });
  wrap.append(table);
  return wrap;
}

/**
 * Liste documents critiques / manquants / obsolètes + zone repliable pour la liste complète.
 */
function createDocumentsPrioritySection() {
  const root = document.createElement('div');
  root.className = 'iso-docs-priority';

  const listWrap = document.createElement('div');
  listWrap.className = 'iso-doc-attention-list';

  function renderAttention() {
    listWrap.innerHTML = '';
    const { critical, missing, obsolete } = DOCUMENT_ATTENTION;
    const blocks = [
      { key: 'missing', label: 'Manquants', items: missing },
      { key: 'obsolete', label: 'Obsolètes', items: obsolete },
      { key: 'critical', label: 'Critiques', items: critical }
    ];
    let any = false;
    blocks.forEach(({ label, items }) => {
      if (!items.length) return;
      any = true;
      const sec = document.createElement('div');
      sec.className = 'iso-doc-attention-block';
      const h = document.createElement('div');
      h.className = 'iso-doc-attention-block-title';
      h.textContent = label;
      sec.append(h);
      items.forEach((d) => {
        const row = document.createElement('div');
        row.className = 'iso-doc-attention-row';
        const name = document.createElement('strong');
        name.textContent = d.name + (d.version ? ` · v${d.version}` : '');
        const note = document.createElement('p');
        note.className = 'iso-doc-attention-note';
        note.textContent = d.note;
        row.append(name, note);
        sec.append(row);
      });
      listWrap.append(sec);
    });
    if (!any) {
      const p = document.createElement('p');
      p.className = 'iso-doc-attention-empty';
      p.textContent = 'Aucun document manquant, obsolète ou critique signalé pour ce site.';
      listWrap.append(p);
    }
  }

  renderAttention();

  const toggleFull = document.createElement('button');
  toggleFull.type = 'button';
  toggleFull.className = 'btn btn-secondary iso-toggle-full-docs';
  toggleFull.setAttribute('aria-expanded', 'false');
  toggleFull.textContent = 'Voir tous les documents maîtrisés';

  const fullWrap = document.createElement('div');
  fullWrap.className = 'iso-req-full-wrap';
  fullWrap.hidden = true;
  fullWrap.append(createDocumentsTable());

  toggleFull.addEventListener('click', () => {
    const open = fullWrap.hidden;
    fullWrap.hidden = !open;
    toggleFull.setAttribute('aria-expanded', open ? 'true' : 'false');
    toggleFull.textContent = open ? 'Masquer la liste complète' : 'Voir tous les documents maîtrisés';
  });

  root.append(listWrap, toggleFull, fullWrap);
  return { root, renderAttention };
}

function createReviewBlock() {
  const grid = document.createElement('div');
  grid.className = 'iso-review-grid';
  REVIEW_PREP.forEach((item) => {
    const tile = document.createElement('div');
    tile.className = 'iso-review-tile';
    const lbl = document.createElement('span');
    lbl.textContent = item.label;
    const val = document.createElement('span');
    val.className = 'iso-review-value';
    val.textContent = item.value;
    const det = document.createElement('span');
    det.className = 'iso-review-detail';
    det.textContent = item.detail;
    tile.append(lbl, val, det);
    grid.append(tile);
  });
  return grid;
}

export function renderIso(onAddLog) {
  ensureIsoPageStyles();
  ensureQhsePilotageStyles();

  const page = document.createElement('section');
  page.className = 'page-stack iso-page iso-page--hub';

  const headerCard = document.createElement('article');
  headerCard.className = 'content-card card-soft iso-header-card iso-hub-intro';
  headerCard.innerHTML = `
    <div class="content-card-head content-card-head--split">
      <div>
        <div class="section-kicker">Système de management</div>
        <h3>Conformité &amp; ISO</h3>
        <p class="content-card-lead content-card-lead--narrow">
          Les référentiels ISO structurent la page : situation globale, exigences suivies, documents et revue.
          L’assistance analyse chaque ligne — la validation humaine reste obligatoire avant enregistrement.
        </p>
      </div>
      <button type="button" class="btn btn-primary btn--pilotage-cta iso-prep-audit">Préparer l’audit</button>
    </div>
  `;

  headerCard.querySelector('.iso-prep-audit').addEventListener('click', () => {
    showToast('Préparation d’audit : checklist, équipe et pièces — workflow à brancher sur le SI (démo).', 'info');
    if (typeof onAddLog === 'function') {
      onAddLog({
        module: 'iso',
        action: 'Préparation audit lancée',
        detail: 'Depuis le centre Conformité & ISO — simulation prototype',
        user: 'Responsable QHSE'
      });
    }
  });

  const aiSpotlight = document.createElement('article');
  aiSpotlight.className = 'content-card card-soft iso-ai-spotlight';
  aiSpotlight.setAttribute('aria-label', 'Assistance conformité');
  aiSpotlight.innerHTML = `
    <div class="iso-ai-badge">Assistance IA · analyse interne</div>
    <h3>Analyse conformité assistée</h3>
    <p class="iso-ai-lead">
      Déclenchez l’analyse depuis chaque exigence : rapprochement avec vos documents maîtrisés et proposition de statut.
      Vous validez, rejetez ou corrigez — rien n’est figé sans action humaine.
    </p>
    <ul class="iso-ai-steps">
      <li>1. Choisir une exigence (liste prioritaire ou tableau complet)</li>
      <li>2. Bouton <strong>Analyser conformité</strong> ou <strong>Traiter</strong></li>
      <li>3. Lecture de la proposition puis validation explicite</li>
    </ul>
  `;

  const summary0 = computeComplianceSummary();
  const globalSnapshotEl = createGlobalSnapshot(summary0);

  /** @type {{ refreshTable: () => void; onAnalyze: (row: unknown) => void }} */
  const tableCtx = {
    refreshTable: () => {},
    onAnalyze: () => {}
  };

  tableCtx.onAnalyze = (row) => {
    openComplianceAssistModal({
      requirement: {
        id: row.id,
        normId: row.normId,
        normCode: row.normCode,
        clause: row.clause,
        title: row.title,
        summary: row.summary,
        evidence: row.evidence,
        status: row.status
      },
      controlledDocuments: CONTROLLED_DOCUMENTS,
      siteId: appState.activeSiteId,
      onStatusCommitted: (requirementId, status, meta) => {
        setRequirementStatus(requirementId, status);
        refreshPilotage();
        if (typeof onAddLog === 'function') {
          onAddLog({
            module: 'iso',
            action: 'Statut exigence mis à jour (validation humaine)',
            detail: `${requirementId} → ${status} (${meta.source})`,
            user: 'Utilisateur'
          });
        }
      }
    });
  };

  const { panel: pointsPanel, renderColContent: renderPoints } = buildPointsPanel((row) => tableCtx.onAnalyze(row));

  const docsSection = createDocumentsPrioritySection();

  const hotRef = {};
  const hotListWrap = createRequirementsHotList({ onAnalyze: (row) => tableCtx.onAnalyze(row) }, hotRef);

  const normsCard = document.createElement('article');
  normsCard.className = 'content-card card-soft iso-norms-hero-wrap iso-norms-central';
  normsCard.innerHTML = `
    <div class="content-card-head">
      <div>
        <div class="section-kicker">Référentiels</div>
        <h3>Normes — cœur du pilotage</h3>
        <p class="content-card-lead">
          Chaque référentiel regroupe les exigences suivies dans le registre : repérez vite où concentrer l’effort, puis ouvrez l’assistance au niveau de la ligne.
        </p>
      </div>
    </div>
  `;
  const normsGrid = document.createElement('div');
  normsGrid.className = 'iso-norms-grid iso-norms-grid--lite';

  function renderNormsGrid() {
    normsGrid.replaceChildren();
    CONFORMITY_NORMS.forEach((sn) => {
      const lite = NORMS_LITE.find((x) => x.id === sn.code);
      if (!lite) return;
      const reqs = getRequirements().filter((r) => r.normId === sn.id);
      const nonOk = reqs.filter((r) => r.status !== 'conforme').length;
      normsGrid.append(
        createNormCardLite({
          id: sn.code,
          title: sn.title,
          status: lite.status,
          badge: lite.badge,
          line: lite.line,
          statsTotal: reqs.length,
          statsNonOk: nonOk
        })
      );
    });
  }
  renderNormsGrid();
  normsCard.append(normsGrid);

  function refreshPilotage() {
    updateGlobalSnapshot(globalSnapshotEl, computeComplianceSummary());
    renderNormsGrid();
    renderPoints();
    if (typeof hotRef.refreshHotList === 'function') hotRef.refreshHotList();
    tableCtx.refreshTable();
    docsSection.renderAttention();
  }

  const reqCard = document.createElement('article');
  reqCard.className = 'content-card card-soft';
  reqCard.innerHTML = `
    <div class="content-card-head">
      <div>
        <div class="section-kicker">Exigences</div>
        <h3>À traiter en priorité</h3>
        <p class="content-card-lead">
          Liste des exigences en écart (partiel ou non conforme). Ouvrez l’assistance pour analyser et valider le statut.
        </p>
      </div>
    </div>
  `;

  reqCard.append(hotListWrap);

  const toggleFullReq = document.createElement('button');
  toggleFullReq.type = 'button';
  toggleFullReq.className = 'btn btn-secondary iso-toggle-full-req';
  toggleFullReq.setAttribute('aria-expanded', 'false');
  toggleFullReq.textContent = 'Voir toutes les exigences';

  const fullReqWrap = document.createElement('div');
  fullReqWrap.className = 'iso-req-full-wrap';
  fullReqWrap.hidden = true;
  fullReqWrap.append(createRequirementsTable(tableCtx));

  toggleFullReq.addEventListener('click', () => {
    const open = fullReqWrap.hidden;
    fullReqWrap.hidden = !open;
    toggleFullReq.setAttribute('aria-expanded', open ? 'true' : 'false');
    toggleFullReq.textContent = open ? 'Masquer toutes les exigences' : 'Voir toutes les exigences';
  });

  reqCard.append(toggleFullReq, fullReqWrap);

  const docsCard = document.createElement('article');
  docsCard.className = 'content-card card-soft';
  docsCard.innerHTML = `
    <div class="content-card-head">
      <div>
        <div class="section-kicker">Documentation</div>
        <h3>Documents à l’attention</h3>
        <p class="content-card-lead">Critiques, manquants ou obsolètes — la liste complète reste accessible ci-dessous.</p>
      </div>
    </div>
  `;
  docsCard.append(docsSection.root);

  const reviewCard = document.createElement('article');
  reviewCard.className = 'content-card card-soft';
  reviewCard.innerHTML = `
    <div class="content-card-head">
      <div>
        <div class="section-kicker">Revue de direction</div>
        <h3>Synthèse rapide</h3>
        <p class="content-card-lead">Entrées pour le comité — chiffres de démo.</p>
      </div>
    </div>
  `;
  reviewCard.append(createReviewBlock());

  const layout = document.createElement('section');
  layout.className = 'two-column';
  const mainCol = document.createElement('div');
  mainCol.className = 'iso-section-stack';
  mainCol.append(reqCard);
  const asideCol = document.createElement('div');
  asideCol.className = 'iso-pilotage-aside';
  asideCol.append(docsCard);
  layout.append(mainCol, asideCol);

  const hubHero = document.createElement('div');
  hubHero.className = 'iso-hub-hero';

  const heroSplit = document.createElement('div');
  heroSplit.className = 'iso-hub-hero-split';

  const heroNormsHost = document.createElement('div');
  heroNormsHost.className = 'iso-hub-hero-norms';
  heroNormsHost.append(normsCard);

  const heroMetricHost = document.createElement('div');
  heroMetricHost.className = 'iso-hub-hero-metric';
  heroMetricHost.append(globalSnapshotEl);

  heroSplit.append(heroNormsHost, heroMetricHost);
  hubHero.append(heroSplit, aiSpotlight);

  page.append(headerCard, hubHero, pointsPanel, layout, reviewCard);
  return page;
}
