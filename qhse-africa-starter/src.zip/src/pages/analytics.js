import { getSessionUser } from '../data/sessionUser.js';
import { qhseFetch } from '../utils/qhseFetch.js';
import { withSiteQuery } from '../utils/siteFilter.js';
import { appState } from '../utils/state.js';
import { fetchSitesCatalog } from '../services/sitesCatalog.service.js';
import { fetchUsers } from '../services/users.service.js';
import { showToast } from '../components/toast.js';
import { ensureQhsePilotageStyles } from '../components/qhsePilotageStyles.js';
import { ensureDashboardStyles } from '../components/dashboardStyles.js';

function formatFrDateTime(iso) {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  } catch {
    return '—';
  }
}

function formatFrDate(iso) {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  } catch {
    return '—';
  }
}

function alertBadgeClass(level) {
  if (level === 'critical') return 'red';
  if (level === 'high') return 'amber';
  return 'blue';
}

function emptyNote(text) {
  const p = document.createElement('p');
  p.style.margin = '0';
  p.style.fontSize = '13px';
  p.style.color = 'var(--text3)';
  p.textContent = text;
  return p;
}

function buildKpiGrid(counts, kpis) {
  const grid = document.createElement('section');
  grid.className = 'kpi-grid dashboard-kpi-grid';

  const items = [
    {
      label: 'Incidents (total)',
      value: String(counts.incidentsTotal ?? '—'),
      tone: 'blue',
      note: `${counts.incidentsLast30Days ?? '—'} sur 30 j.`
    },
    {
      label: 'Incidents critiques ouverts',
      value: String(counts.incidentsCriticalOpen ?? '—'),
      tone: counts.incidentsCriticalOpen > 0 ? 'red' : 'green',
      note: 'Sur les 400 derniers incidents (non clos)'
    },
    {
      label: 'NC ouvertes',
      value: String(counts.nonConformitiesOpen ?? '—'),
      tone: counts.nonConformitiesOpen >= 5 ? 'amber' : 'blue',
      note: `Sur ${counts.nonConformitiesTotal ?? '—'} enregistrées`
    },
    {
      label: 'Actions en retard',
      value: String(counts.actionsOverdue ?? '—'),
      tone: counts.actionsOverdue > 0 ? 'amber' : 'green',
      note: `Sur ${counts.actionsTotal ?? '—'} actions`
    },
    {
      label: 'Audits (total)',
      value: String(counts.auditsTotal ?? '—'),
      tone: 'blue',
      note: 'Référentiel audits'
    },
    {
      label: 'Score moyen audits',
      value:
        kpis.auditScoreAvg != null && !Number.isNaN(kpis.auditScoreAvg)
          ? `${kpis.auditScoreAvg} %`
          : '—',
      tone:
        kpis.auditScoreAvg != null && kpis.auditScoreAvg < 70
          ? 'amber'
          : 'green',
      note:
        kpis.auditScoreMin != null && kpis.auditScoreMax != null
          ? `Min ${kpis.auditScoreMin} % · Max ${kpis.auditScoreMax} %`
          : 'Pas assez de données'
    }
  ];

  items.forEach((kpi) => {
    const card = document.createElement('article');
    card.className = 'metric-card card-soft';
    card.innerHTML = `
      <div class="metric-label">${kpi.label}</div>
      <div class="metric-value ${kpi.tone}">${kpi.value}</div>
      <div class="metric-note">${kpi.note}</div>
    `;
    grid.append(card);
  });

  return grid;
}

function buildStackSection(title, kicker, host) {
  const card = document.createElement('article');
  card.className = 'content-card card-soft';
  const head = document.createElement('div');
  head.className = 'content-card-head';
  head.innerHTML = `
    <div>
      <div class="section-kicker">${kicker}</div>
      <h3>${title}</h3>
    </div>
  `;
  card.append(head, host);
  return card;
}

function buildPeriodicSummaryGrid(summary) {
  const grid = document.createElement('section');
  grid.className = 'kpi-grid dashboard-kpi-grid';
  const items = [
    {
      label: 'Incidents créés (période)',
      value: String(summary.incidentsCreated ?? '—'),
      tone: 'blue',
      note: 'Déclarations sur la fenêtre'
    },
    {
      label: 'Audits enregistrés',
      value: String(summary.auditsRecorded ?? '—'),
      tone: 'blue',
      note: 'Créés sur la période'
    },
    {
      label: 'Score moyen audits',
      value:
        summary.auditScoreAvg != null && !Number.isNaN(summary.auditScoreAvg)
          ? `${summary.auditScoreAvg} %`
          : '—',
      tone:
        summary.auditScoreAvg != null && summary.auditScoreAvg < 70
          ? 'amber'
          : 'green',
      note: 'Sur les audits de la période'
    },
    {
      label: 'NC créées',
      value: String(summary.nonConformitiesCreated ?? '—'),
      tone: 'amber',
      note: `${summary.nonConformitiesOpenAmongCreated ?? '—'} encore ouvertes`
    },
    {
      label: 'Actions créées',
      value: String(summary.actionsCreated ?? '—'),
      tone: 'blue',
      note: `${summary.actionsCreatedWithClosedLikeStatus ?? '—'} statut terminé/clôturé`
    },
    {
      label: 'Actions en retard (stock)',
      value: String(summary.actionsOverdueStock ?? '—'),
      tone: summary.actionsOverdueStock > 0 ? 'amber' : 'green',
      note: 'À la fin de la période, filtres appliqués'
    },
    {
      label: 'Incidents critiques (période)',
      value: String(summary.criticalIncidentsInPeriod ?? '—'),
      tone: summary.criticalIncidentsOpenInPeriod > 0 ? 'red' : 'green',
      note: `${summary.criticalIncidentsOpenInPeriod ?? '—'} non clôturés`
    }
  ];
  items.forEach((kpi) => {
    const card = document.createElement('article');
    card.className = 'metric-card card-soft';
    card.innerHTML = `
      <div class="metric-label">${kpi.label}</div>
      <div class="metric-value ${kpi.tone}">${kpi.value}</div>
      <div class="metric-note">${kpi.note}</div>
    `;
    grid.append(card);
  });
  return grid;
}

function mountPeriodicReportingBlock(periodicCard) {
  const periodSel = periodicCard.querySelector('.analytics-periodic-period');
  const startIn = periodicCard.querySelector('.analytics-periodic-start');
  const endIn = periodicCard.querySelector('.analytics-periodic-end');
  const siteSel = periodicCard.querySelector('.analytics-periodic-site');
  const assigneeSel = periodicCard.querySelector('.analytics-periodic-assignee');
  const loadBtn = periodicCard.querySelector('.analytics-periodic-load');
  const resultsHost = periodicCard.querySelector('.analytics-periodic-results');
  const statusLine = periodicCard.querySelector('.analytics-periodic-status');

  (async function fillFilters() {
    siteSel.innerHTML = '<option value="">— Tous sites —</option>';
    assigneeSel.innerHTML = '<option value="">— Tous responsables —</option>';
    try {
      const sites = await fetchSitesCatalog();
      sites.forEach((s) => {
        if (!s?.id) return;
        const o = document.createElement('option');
        o.value = s.id;
        o.textContent = s.code ? `${s.name} (${s.code})` : s.name;
        siteSel.append(o);
      });
    } catch {
      /* ignore */
    }
    if (appState.activeSiteId) {
      siteSel.value = appState.activeSiteId;
    }
    try {
      const users = await fetchUsers();
      users.forEach((u) => {
        if (!u?.id) return;
        const o = document.createElement('option');
        o.value = u.id;
        o.textContent = `${u.name} (${u.role})`;
        assigneeSel.append(o);
      });
    } catch {
      /* ignore */
    }
  })();

  loadBtn.addEventListener('click', async () => {
    const params = new URLSearchParams();
    const sd = (startIn.value || '').trim();
    const ed = (endIn.value || '').trim();
    if ((sd && !ed) || (!sd && ed)) {
      statusLine.textContent =
        'Indiquez la date de début et la date de fin, ou laissez les deux vides.';
      showToast(
        'Période personnalisée : renseigner début et fin, ou utiliser la liste « Période » sans dates.',
        'warning'
      );
      return;
    }
    if (sd && ed) {
      params.set('startDate', sd);
      params.set('endDate', ed);
    } else {
      params.set('period', periodSel.value || 'weekly');
    }
    const sid = (siteSel.value || '').trim();
    if (sid) params.set('siteId', sid);
    const aid = (assigneeSel.value || '').trim();
    if (aid) params.set('assigneeId', aid);

    loadBtn.disabled = true;
    statusLine.textContent = 'Chargement…';
    resultsHost.replaceChildren();
    try {
      const res = await qhseFetch(`/api/reports/periodic?${params.toString()}`);
      if (res.status === 403) {
        statusLine.textContent = 'Permission « rapports » requise.';
        showToast('Accès reporting périodique refusé', 'error');
        return;
      }
      if (!res.ok) {
        let msg = `Erreur ${res.status}`;
        try {
          const b = await res.json();
          if (b.error) msg = b.error;
        } catch {
          /* ignore */
        }
        statusLine.textContent = msg;
        showToast(msg, 'error');
        return;
      }
      const data = await res.json();
      const meta = data.meta || {};
      statusLine.textContent = `Période : ${formatFrDate(meta.startDate)} → ${formatFrDate(meta.endDate)} · généré ${formatFrDateTime(meta.generatedAt)}`;

      const metaNote = document.createElement('p');
      metaNote.style.margin = '0 0 10px';
      metaNote.style.fontSize = '12px';
      metaNote.style.color = 'var(--text3)';
      metaNote.style.lineHeight = '1.45';
      const lim = Array.isArray(meta.limitations) ? meta.limitations : [];
      metaNote.textContent =
        lim.length > 0
          ? `Limites V1 : ${lim.join(' ')}`
          : '';

      resultsHost.append(metaNote);
      resultsHost.append(buildPeriodicSummaryGrid(data.summary || {}));

      const alertsStack = document.createElement('div');
      alertsStack.className = 'stack';
      const alerts = Array.isArray(data.alerts) ? data.alerts : [];
      if (alerts.length === 0) {
        alertsStack.append(emptyNote('Aucune alerte.'));
      } else {
        alerts.forEach((a) => {
          const row = document.createElement('article');
          row.className = 'list-row';
          const tone = alertBadgeClass(a.level);
          row.innerHTML = `
            <div>
              <strong>${a.code || 'ALERTE'}</strong>
              <p style="margin:6px 0 0;font-size:13px;line-height:1.45;color:var(--text2)">${a.message || ''}</p>
            </div>
            <span class="badge ${tone}">${a.level === 'critical' ? 'Critique' : a.level === 'high' ? 'Priorité' : 'Info'}</span>
          `;
          alertsStack.append(row);
        });
      }
      resultsHost.append(buildStackSection('Alertes (période)', 'Pilotage', alertsStack));

      const two = document.createElement('div');
      two.className = 'two-column';

      const incStack = document.createElement('div');
      incStack.className = 'stack';
      const incs = Array.isArray(data.incidents?.sample) ? data.incidents.sample : [];
      if (incs.length === 0) {
        incStack.append(emptyNote('Aucun incident sur la période.'));
      } else {
        incs.forEach((inc) => {
          const row = document.createElement('article');
          row.className = 'list-row';
          row.innerHTML = `
            <div>
              <strong>${inc.ref} — ${inc.type}</strong>
              <p style="margin:6px 0 0;font-size:13px;color:var(--text2)">${inc.site} · ${inc.status}</p>
            </div>
            <span class="badge blue">${formatFrDate(inc.createdAt)}</span>
          `;
          incStack.append(row);
        });
      }

      const audStack = document.createElement('div');
      audStack.className = 'stack';
      const auds = Array.isArray(data.audits?.sample) ? data.audits.sample : [];
      if (auds.length === 0) {
        audStack.append(emptyNote('Aucun audit sur la période.'));
      } else {
        auds.forEach((a) => {
          const row = document.createElement('article');
          row.className = 'list-row';
          row.innerHTML = `
            <div>
              <strong>${a.ref}</strong>
              <p style="margin:6px 0 0;font-size:13px;color:var(--text2)">${a.site} · ${a.status}</p>
            </div>
            <span class="badge blue">${a.score} %</span>
          `;
          audStack.append(row);
        });
      }

      two.append(
        buildStackSection('Incidents (extrait)', 'Période', incStack),
        buildStackSection('Audits (extrait)', 'Période', audStack)
      );
      resultsHost.append(two);

      const two2 = document.createElement('div');
      two2.className = 'two-column';
      const ncStack = document.createElement('div');
      ncStack.className = 'stack';
      const ncs = Array.isArray(data.nonConformities?.sample) ? data.nonConformities.sample : [];
      if (ncs.length === 0) {
        ncStack.append(emptyNote('Aucune NC créée sur la période.'));
      } else {
        ncs.forEach((nc) => {
          const row = document.createElement('article');
          row.className = 'list-row';
          row.innerHTML = `
            <div>
              <strong>${nc.title}</strong>
              <p style="margin:6px 0 0;font-size:13px;color:var(--text2)">Audit ${nc.auditRef} · ${nc.status}</p>
            </div>
            <span class="badge amber">NC</span>
          `;
          ncStack.append(row);
        });
      }
      const actStack = document.createElement('div');
      actStack.className = 'stack';
      const acts = Array.isArray(data.actions?.overdueSample) ? data.actions.overdueSample : [];
      if (acts.length === 0) {
        actStack.append(emptyNote('Aucun extrait d’actions en retard (ou liste vide).'));
      } else {
        acts.forEach((act) => {
          const row = document.createElement('article');
          row.className = 'list-row';
          const due = act.dueDate ? formatFrDate(act.dueDate) : '—';
          row.innerHTML = `
            <div>
              <strong>${act.title}</strong>
              <p style="margin:6px 0 0;font-size:13px;color:var(--text2)">${act.owner || '—'} · Échéance ${due}</p>
            </div>
            <span class="badge amber">Retard</span>
          `;
          actStack.append(row);
        });
      }
      two2.append(
        buildStackSection('NC créées (extrait)', 'Période', ncStack),
        buildStackSection('Actions en retard (extrait)', 'Stock fin période', actStack)
      );
      resultsHost.append(two2);
    } catch (err) {
      console.error('[analytics] periodic', err);
      statusLine.textContent = 'Erreur réseau ou serveur.';
      showToast('Erreur chargement reporting périodique', 'error');
    } finally {
      loadBtn.disabled = false;
    }
  });
}

function mountAutomationBlock(page) {
  const su = getSessionUser();
  const role = String(su?.role ?? '').toUpperCase();
  if (!su || (role !== 'ADMIN' && role !== 'QHSE')) return;

  const card = document.createElement('article');
  card.className = 'content-card card-soft';
  card.style.marginTop = '14px';
  card.innerHTML = `
    <div class="content-card-head">
      <div>
        <div class="section-kicker">Automatisation</div>
        <h3>Jobs planifiés (V1)</h3>
        <p class="dashboard-muted-lead" style="margin:6px 0 0">
          Synthèse hebdomadaire par e-mail (ADMIN, QHSE, DIRECTION) et relances des actions en retard. Nécessite SMTP configuré côté serveur.
        </p>
      </div>
    </div>
    <p class="automation-status-line" style="margin:0;font-size:13px;color:var(--text2)"></p>
    <div style="margin-top:12px;display:flex;flex-wrap:wrap;gap:10px;align-items:center">
      <button type="button" class="btn btn-primary automation-run-btn" style="min-height:44px;font-weight:700">Exécuter maintenant</button>
    </div>
    <p class="automation-run-result" style="margin:10px 0 0;font-size:12px;color:var(--text3);white-space:pre-wrap"></p>
  `;

  const statusEl = card.querySelector('.automation-status-line');
  const resultEl = card.querySelector('.automation-run-result');
  const btn = card.querySelector('.automation-run-btn');

  (async function loadStatus() {
    try {
      const res = await qhseFetch('/api/automation/status');
      if (!res.ok) {
        statusEl.textContent = 'Statut indisponible (droits ou API).';
        return;
      }
      const s = await res.json();
      const last =
        s.lastRunAt != null
          ? ` · Dernier passage : ${formatFrDateTime(s.lastRunAt)}`
          : '';
      statusEl.textContent = `SMTP : ${s.smtpConfigured ? 'configuré' : 'non configuré'} · Planificateur serveur : ${s.schedulerEnabled ? 'oui' : 'non'}${last}`;
    } catch {
      statusEl.textContent = 'Impossible de charger le statut.';
    }
  })();

  btn.addEventListener('click', async () => {
    btn.disabled = true;
    resultEl.textContent = 'Exécution…';
    try {
      const res = await qhseFetch('/api/automation/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        resultEl.textContent = data.error || `Erreur ${res.status}`;
        showToast(data.error || 'Erreur', 'error');
        return;
      }
      resultEl.textContent = JSON.stringify(data.result ?? data, null, 2);
      showToast('Jobs exécutés', 'info');
      try {
        const sr = await qhseFetch('/api/automation/status');
        if (sr.ok) {
          const s = await sr.json();
          const last =
            s.lastRunAt != null
              ? ` · Dernier passage : ${formatFrDateTime(s.lastRunAt)}`
              : '';
          statusEl.textContent = `SMTP : ${s.smtpConfigured ? 'configuré' : 'non configuré'} · Planificateur serveur : ${s.schedulerEnabled ? 'oui' : 'non'}${last}`;
        }
      } catch {
        /* ignore */
      }
    } catch (e) {
      resultEl.textContent = String(e?.message || e);
      showToast('Erreur réseau', 'error');
    } finally {
      btn.disabled = false;
    }
  });

  page.append(card);
}

export function renderAnalytics() {
  ensureQhsePilotageStyles();
  ensureDashboardStyles();

  const page = document.createElement('section');
  page.className = 'page-stack';

  const lead = document.createElement('p');
  lead.className = 'dashboard-muted-lead';
  lead.style.margin = '0 0 8px';
  lead.textContent =
    'Synthèse consolidée pour le pilotage QHSE et la préparation des revues — données issues du SI.';

  page.append(lead);
  mountAutomationBlock(page);

  const loading = document.createElement('p');
  loading.style.margin = '0';
  loading.style.fontSize = '14px';
  loading.style.color = 'var(--text2)';
  loading.textContent = 'Chargement de la synthèse…';

  const contentHost = document.createElement('div');
  contentHost.style.display = 'flex';
  contentHost.style.flexDirection = 'column';
  contentHost.style.gap = '18px';
  contentHost.append(loading);

  page.append(contentHost);

  const chartWrap = document.createElement('section');
  chartWrap.className = 'two-column';
  chartWrap.style.marginTop = '4px';

  const chart = document.createElement('article');
  chart.className = 'content-card card-soft';
  chart.innerHTML = `
    <div class="content-card-head">
      <div>
        <div class="section-kicker">Lecture</div>
        <h3>Tendance illustrative</h3>
        <p class="dashboard-muted-lead" style="margin:6px 0 0">Courbe décorative — les indicateurs réels sont dans la grille ci-dessus.</p>
      </div>
    </div>
    <div class="line-chart">
      <svg viewBox="0 0 700 220" preserveAspectRatio="none">
        <defs>
          <linearGradient id="lineFillAnalytics" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="rgba(77,160,255,.45)"/>
            <stop offset="100%" stop-color="rgba(77,160,255,0)"/>
          </linearGradient>
        </defs>
        <path d="M0 180 C80 165, 100 120, 160 124 S260 150, 320 115 S420 70, 480 95 S580 145, 700 80 L700 220 L0 220 Z" fill="url(#lineFillAnalytics)"/>
        <path d="M0 180 C80 165, 100 120, 160 124 S260 150, 320 115 S420 70, 480 95 S580 145, 700 80" fill="none" stroke="#66b3ff" stroke-width="4" stroke-linecap="round"/>
      </svg>
    </div>
  `;

  const exportHint = document.createElement('article');
  exportHint.className = 'content-card card-soft';
  exportHint.innerHTML = `
    <div class="content-card-head">
      <div>
        <div class="section-kicker">Export</div>
        <h3>Rapports périodiques</h3>
        <p class="dashboard-muted-lead" style="margin:6px 0 0">
          Synthèse consolidée sur fenêtre <strong>hebdomadaire</strong> ou <strong>mensuelle</strong> (ou dates au choix). Même permission que la synthèse globale. Structure <code style="font-size:12px">export</code> côté API pour futur PDF / envoi automatique.
        </p>
      </div>
    </div>
    <p style="margin:0 0 12px;font-size:13px;color:var(--text2);line-height:1.5">
      Les rapports d’audit unitaires restent disponibles depuis le module Audits (PDF / e-mail).
    </p>
    <div class="form-grid" style="gap:10px;align-items:flex-end">
      <label class="field">
        <span>Période</span>
        <select class="control-select analytics-periodic-period" aria-label="Type de période">
          <option value="weekly">7 derniers jours</option>
          <option value="monthly">Mois en cours (1er → aujourd’hui)</option>
        </select>
      </label>
      <label class="field">
        <span>Début (optionnel)</span>
        <input type="date" class="control-input analytics-periodic-start" />
      </label>
      <label class="field">
        <span>Fin (optionnel)</span>
        <input type="date" class="control-input analytics-periodic-end" />
      </label>
      <label class="field">
        <span>Site</span>
        <select class="control-select analytics-periodic-site" aria-label="Filtrer par site"></select>
      </label>
      <label class="field">
        <span>Responsable (actions)</span>
        <select class="control-select analytics-periodic-assignee" aria-label="Filtrer par assigné"></select>
      </label>
      <button type="button" class="btn btn-primary analytics-periodic-load" style="min-height:44px;font-weight:700">
        Charger le reporting périodique
      </button>
    </div>
    <p class="analytics-periodic-status" style="margin:10px 0 0;font-size:12px;color:var(--text3)"></p>
    <div class="analytics-periodic-results stack" style="margin-top:12px"></div>
  `;
  mountPeriodicReportingBlock(exportHint);

  chartWrap.append(chart, exportHint);

  (async function load() {
    try {
      const res = await qhseFetch(withSiteQuery('/api/reports/summary'));
      if (res.status === 403) {
        loading.textContent =
          'Accès refusé : la synthèse nécessite la permission « rapports » (lecture).';
        showToast('Permission rapports requise pour la synthèse.', 'error');
        return;
      }
      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }
      const data = await res.json();

      contentHost.replaceChildren();

      const meta = document.createElement('p');
      meta.style.margin = '0';
      meta.style.fontSize = '12px';
      meta.style.color = 'var(--text3)';
      meta.textContent = `Généré le ${formatFrDateTime(data.generatedAt)} · ${data.export?.documentTitle ?? 'Synthèse QHSE'}`;
      contentHost.append(meta);

      contentHost.append(buildKpiGrid(data.counts || {}, data.kpis || {}));

      const alertsStack = document.createElement('div');
      alertsStack.className = 'stack';
      const alerts = Array.isArray(data.priorityAlerts) ? data.priorityAlerts : [];
      if (alerts.length === 0) {
        alertsStack.append(emptyNote('Aucune alerte renvoyée.'));
      } else {
        alerts.forEach((a) => {
          const row = document.createElement('article');
          row.className = 'list-row';
          const tone = alertBadgeClass(a.level);
          row.innerHTML = `
            <div>
              <strong>${a.code || 'ALERTE'}</strong>
              <p style="margin:6px 0 0;font-size:13px;line-height:1.45;color:var(--text2)">${a.message || ''}</p>
            </div>
            <span class="badge ${tone}">${a.level === 'critical' ? 'Critique' : a.level === 'high' ? 'Priorité' : 'Info'}</span>
          `;
          alertsStack.append(row);
        });
      }
      contentHost.append(buildStackSection('Alertes prioritaires', 'Pilotage', alertsStack));

      const two = document.createElement('div');
      two.className = 'two-column';

      const critStack = document.createElement('div');
      critStack.className = 'stack';
      const crit = Array.isArray(data.criticalIncidents) ? data.criticalIncidents : [];
      if (crit.length === 0) {
        critStack.append(emptyNote('Aucun incident critique ouvert dans le périmètre analysé.'));
      } else {
        crit.forEach((inc) => {
          const row = document.createElement('article');
          row.className = 'list-row';
          row.innerHTML = `
            <div>
              <strong>${inc.ref} — ${inc.type}</strong>
              <p style="margin:6px 0 0;font-size:13px;color:var(--text2)">${inc.site} · ${inc.status}</p>
            </div>
            <span class="badge red">${formatFrDate(inc.createdAt)}</span>
          `;
          critStack.append(row);
        });
      }

      const auditStack = document.createElement('div');
      auditStack.className = 'stack';
      const audits = Array.isArray(data.recentAudits) ? data.recentAudits : [];
      if (audits.length === 0) {
        auditStack.append(emptyNote('Aucun audit enregistré.'));
      } else {
        audits.forEach((a) => {
          const row = document.createElement('article');
          row.className = 'list-row';
          row.innerHTML = `
            <div>
              <strong>${a.ref}</strong>
              <p style="margin:6px 0 0;font-size:13px;color:var(--text2)">${a.site} · ${a.status}</p>
            </div>
            <span class="badge blue">${a.score} %</span>
          `;
          auditStack.append(row);
        });
      }

      two.append(
        buildStackSection('Incidents critiques (aperçu)', 'Sécurité', critStack),
        buildStackSection('Audits récents', 'Conformité', auditStack)
      );
      contentHost.append(two);

      const two2 = document.createElement('div');
      two2.className = 'two-column';

      const ncStack = document.createElement('div');
      ncStack.className = 'stack';
      const ncs = Array.isArray(data.openNonConformities) ? data.openNonConformities : [];
      if (ncs.length === 0) {
        ncStack.append(emptyNote('Aucune non-conformité ouverte listée (ou échantillon vide).'));
      } else {
        ncs.forEach((nc) => {
          const row = document.createElement('article');
          row.className = 'list-row';
          row.innerHTML = `
            <div>
              <strong>${nc.title}</strong>
              <p style="margin:6px 0 0;font-size:13px;color:var(--text2)">Audit ${nc.auditRef} · ${nc.status}</p>
            </div>
            <span class="badge amber">NC</span>
          `;
          ncStack.append(row);
        });
      }

      const actStack = document.createElement('div');
      actStack.className = 'stack';
      const acts = Array.isArray(data.overdueActions) ? data.overdueActions : [];
      if (acts.length === 0) {
        actStack.append(emptyNote('Aucune action en retard dans les extraits récents.'));
      } else {
        acts.forEach((act) => {
          const row = document.createElement('article');
          row.className = 'list-row';
          const due = act.dueDate ? formatFrDate(act.dueDate) : '—';
          row.innerHTML = `
            <div>
              <strong>${act.title}</strong>
              <p style="margin:6px 0 0;font-size:13px;color:var(--text2)">${act.owner || '—'} · Échéance ${due}</p>
            </div>
            <span class="badge amber">Retard</span>
          `;
          actStack.append(row);
        });
      }

      two2.append(
        buildStackSection('Non-conformités ouvertes (aperçu)', 'Qualité', ncStack),
        buildStackSection('Actions en retard (aperçu)', 'Exécution', actStack)
      );
      contentHost.append(two2);
      contentHost.append(chartWrap);
    } catch (err) {
      console.error('[analytics] /api/reports/summary', err);
      loading.textContent = 'Impossible de charger la synthèse. Vérifiez l’API et la console.';
      showToast('Erreur chargement synthèse reporting', 'error');
    }
  })();

  return page;
}
