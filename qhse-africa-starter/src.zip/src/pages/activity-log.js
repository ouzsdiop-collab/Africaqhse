import { activityLogStore } from '../data/activityLog.js';
import { ensureActivityLogStyles } from '../components/activityLogStyles.js';
import { buildActivityLogSnapshot } from '../components/activityLogHelpers.js';
import { createActivityLogSummary } from '../components/activityLogSummary.js';
import { createActivityLogRow } from '../components/activityLogRow.js';

/**
 * Tableau du journal — réutilisable avec une liste filtrée / triée (futur).
 * @param {Array} entries liste déjà ordonnée (ex. antichronologique)
 */
export function createActivityLogTable(entries) {
  const table = document.createElement('div');
  table.className = 'activity-log-table';
  table.setAttribute('data-activity-log-table', '');

  const head = document.createElement('div');
  head.className = 'activity-log-head';
  head.innerHTML = `
    <span>Module</span>
    <span>Action</span>
    <span>Détail</span>
    <span>Utilisateur</span>
    <span>Date / heure</span>
  `;
  table.append(head);

  entries.forEach((entry) => {
    table.append(createActivityLogRow(entry));
  });

  return table;
}

export function renderActivityLog() {
  ensureActivityLogStyles();

  const entries = activityLogStore.all();
  const snapshot = buildActivityLogSnapshot(entries);

  const page = document.createElement('section');
  page.className = 'page-stack activity-log-page';

  const card = document.createElement('article');
  card.className = 'content-card card-soft';

  const headBlock = document.createElement('div');
  headBlock.className = 'content-card-head';
  headBlock.innerHTML = `
    <div>
      <div class="section-kicker">Traçabilité</div>
      <h3>Journal des modifications</h3>
      <p class="content-card-lead">
        Piste d’audit : qui a fait quoi, sur quel module, avec quelle description — structuré pour revue ISO et contrôles internes (données mock).
      </p>
    </div>
  `;

  card.append(headBlock);
  card.append(createActivityLogSummary(snapshot));

  const toolbar = document.createElement('div');
  toolbar.className = 'activity-log-toolbar';
  toolbar.setAttribute('role', 'note');
  toolbar.innerHTML = `
    <span>Lecture</span>
    <span class="activity-log-toolbar-note">Tri par date décroissante · colonnes figées pour export futur</span>
  `;
  card.append(toolbar);

  card.append(createActivityLogTable(entries));

  const extensionSlot = document.createElement('div');
  extensionSlot.className = 'activity-log-extension-slot';
  extensionSlot.innerHTML = `
    <span class="activity-log-extension-label">Évolutions prévues</span>
    <span class="activity-log-extension-text">Filtres par module, recherche plein texte et tri — même structure de tableau, autre source de lignes.</span>
  `;
  card.append(extensionSlot);

  page.append(card);
  return page;
}
