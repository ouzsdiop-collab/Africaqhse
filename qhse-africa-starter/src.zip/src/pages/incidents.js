import { siteOptions } from '../data/navigation.js';
import { appState } from '../utils/state.js';
import { showToast } from '../components/toast.js';
import { activityLogStore } from '../data/activityLog.js';
import { createSeveritySegment } from '../components/severitySegment.js';
import { getApiBase } from '../config.js';
import { qhseFetch } from '../utils/qhseFetch.js';
import { withSiteQuery } from '../utils/siteFilter.js';
import { fetchSitesCatalog } from '../services/sitesCatalog.service.js';
import { fetchUsers } from '../services/users.service.js';
import { getSessionUser } from '../data/sessionUser.js';
import { canResource } from '../utils/permissionsUi.js';
import { readImportDraft, clearImportDraft } from '../utils/importDraft.js';

const INCIDENT_TYPES = [
  'Quasi-accident',
  'Accident',
  'Environnement',
  'Engin / circulation',
  'Autre'
];

const LIST_SUB_DEFAULT =
  'Tri : gravité critique en tête, puis plus récents. Carte = titre, type, gravité, date, statut.';

/** Statuts proposés pour le select rapide (libre côté API si autre valeur en base). */
const STATUS_PRESETS = ['Nouveau', 'En cours', 'Investigation', 'Clôturé'];

const INCIDENTS_TOOLBAR_STYLE_ID = 'qhse-incidents-toolbar';

function ensureIncidentsToolbarStyles() {
  if (document.getElementById(INCIDENTS_TOOLBAR_STYLE_ID)) return;
  const el = document.createElement('style');
  el.id = INCIDENTS_TOOLBAR_STYLE_ID;
  el.textContent = `
.incidents-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  flex-wrap: wrap;
  padding: 8px 0 11px;
  border-bottom: 1px solid rgba(255,255,255,.06);
  margin-bottom: 12px;
}
.incidents-toolbar__left {
  display: flex;
  align-items: center;
  gap: 10px;
}
.incidents-toolbar__right {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}
.incidents-count {
  font-size: 12px;
  font-weight: 600;
  letter-spacing: 0.01em;
  color: var(--text, rgba(255,255,255,.88));
}
[data-display-mode="simple"] .incidents-toolbar__right {
  display: none;
}
`;
  document.head.append(el);
}

const INCIDENTS_STATES_STYLE_ID = 'qhse-incidents-states-styles';

function ensureIncidentsStatesStyles() {
  if (document.getElementById(INCIDENTS_STATES_STYLE_ID)) return;
  const el = document.createElement('style');
  el.id = INCIDENTS_STATES_STYLE_ID;
  el.textContent = `
.incidents-skeleton{
  display:flex;flex-direction:column;gap:8px;padding:2px 0;
}
.skeleton-card{
  padding:12px 14px;border-radius:10px;
  border:1px solid rgba(255,255,255,.055);
  background:rgba(255,255,255,.018);
}
.skeleton-line{
  border-radius:3px;
  background:rgba(255,255,255,.065);
  animation:skeletonPulse 1.5s ease-in-out infinite;
}
.skeleton-line--title{height:11px;width:52%;margin-bottom:8px;}
.skeleton-line--sub{height:10px;width:78%;margin-bottom:6px;}
.skeleton-line--meta{height:9px;width:34%;}
@keyframes skeletonPulse{
  0%,100%{opacity:.5}50%{opacity:1}
}
.incidents-list-host .incidents-empty{
  display:flex;flex-direction:column;
  align-items:center;justify-content:center;
  gap:8px;padding:36px 20px;text-align:center;
}
.incidents-list-host .incidents-empty__title{
  margin:0;font-size:15px;font-weight:600;
  color:var(--text,rgba(255,255,255,.88));
}
.incidents-list-host .incidents-empty__sub{
  margin:0;font-size:13px;line-height:1.5;
  color:var(--text2,rgba(255,255,255,.5));
  max-width:34ch;
}
.incidents-list-host .incidents-empty__cta{margin-top:6px;}
`;
  document.head.append(el);
}

const INCIDENTS_SLIDEOVER_STYLE_ID = 'qhse-incidents-slideover';

function ensureIncidentsSlideOverStyles() {
  if (document.getElementById(INCIDENTS_SLIDEOVER_STYLE_ID)) return;
  const el = document.createElement('style');
  el.id = INCIDENTS_SLIDEOVER_STYLE_ID;
  el.textContent = `
.inc-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,.6);
  z-index: 200;
  opacity: 0;
  pointer-events: none;
  transition: opacity 200ms ease;
}
.inc-overlay--open {
  opacity: 1;
  pointer-events: all;
}
.inc-slideover {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  width: min(440px, 100vw);
  background: var(--bg, #0f172a);
  border-left: 1px solid rgba(255,255,255,.09);
  z-index: 201;
  transform: translateX(100%);
  transition: transform 220ms ease;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.inc-slideover--open {
  transform: translateX(0);
}
.inc-slideover__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 18px;
  border-bottom: 1px solid rgba(255,255,255,.065);
  flex-shrink: 0;
}
.inc-slideover__title {
  font-size: 14px;
  font-weight: 600;
  color: var(--text, rgba(255,255,255,.9));
}
.inc-slideover__close {
  width: 32px;
  height: 32px;
  border-radius: 8px;
  border: 0.5px solid rgba(255,255,255,.1);
  background: transparent;
  color: var(--text2, rgba(255,255,255,.5));
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 150ms;
}
.inc-slideover__close:hover {
  background: rgba(255,255,255,.07);
  color: var(--text, rgba(255,255,255,.88));
}
.inc-slideover__body {
  flex: 1;
  overflow-y: auto;
  padding: 16px 18px 20px;
}
`;
  document.head.append(el);
}

let incidentRecords = [];

function normalizedUserRole(role) {
  return String(role ?? '').trim().toUpperCase();
}

function normalizeSeverity(label) {
  const t = String(label).toLowerCase();
  if (t.includes('critique')) return 'critique';
  if (t.includes('faible')) return 'faible';
  return 'moyen';
}

function formatDateFromIso(iso) {
  if (!iso) return formatToday();
  try {
    return new Date(iso).toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  } catch {
    return formatToday();
  }
}

function formatIsoDateToFr(isoDate) {
  if (!isoDate || typeof isoDate !== 'string') return '';
  const [y, m, d] = isoDate.split('-');
  if (!y || !m || !d) return isoDate;
  return `${d}/${m}/${y}`;
}

function incidentTitleFromRow(row) {
  const raw = (row.description || '').trim();
  if (raw) {
    const line = raw.split(/\r?\n/)[0].trim();
    return line.length > 76 ? `${line.slice(0, 73)}…` : line;
  }
  return `${row.type} · ${row.site}`;
}

/**
 * @param {Record<string, unknown>} row
 */
function mapApiIncident(row) {
  if (!row || typeof row !== 'object' || !row.ref) return null;
  const createdAtMs = row.createdAt ? new Date(row.createdAt).getTime() : Date.now();
  const sev = normalizeSeverity(row.severity);
  return {
    ref: row.ref,
    type: row.type,
    site: row.site,
    severity: sev,
    status: row.status ?? 'Nouveau',
    date: formatDateFromIso(row.createdAt),
    createdAtMs,
    description: typeof row.description === 'string' ? row.description : ''
  };
}

function mapRowToDisplay(inc) {
  return {
    ...inc,
    title: incidentTitleFromRow(inc)
  };
}

function computeNextRef(list) {
  const nums = list.map((r) => {
    const m = /^INC-(\d+)$/i.exec(r.ref);
    return m ? parseInt(m[1], 10) : 0;
  });
  const max = nums.length ? Math.max(...nums) : 200;
  return `INC-${max + 1}`;
}

function formatToday() {
  return new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

function severityDsBadgeClass(sev) {
  if (sev === 'faible') return 'ds-badge--ok';
  if (sev === 'critique') return 'ds-badge--danger';
  return 'ds-badge--warn';
}

function severityOrder(sev) {
  if (sev === 'critique') return 0;
  if (sev === 'moyen') return 1;
  if (sev === 'faible') return 2;
  return 3;
}

function sortIncidentsForDisplay(list) {
  return [...list].sort((a, b) => {
    const da = severityOrder(a.severity);
    const db = severityOrder(b.severity);
    if (da !== db) return da - db;
    return (b.createdAtMs || 0) - (a.createdAtMs || 0);
  });
}

function statusOptionsForSelect(current) {
  const cur = String(current || '').trim();
  const set = new Set(STATUS_PRESETS);
  if (cur && !set.has(cur)) {
    return [cur, ...STATUS_PRESETS];
  }
  return [...STATUS_PRESETS];
}

function isStatusClosed(st) {
  return /clos|ferm|termin|clôtur|résolu|resolu|done|complete/i.test(String(st));
}

function countOpenIncidents(list) {
  return list.filter((i) => !isStatusClosed(i.status)).length;
}

/** @type {object[] | null} */
let cachedUsersForActions = null;

async function ensureUsersCached() {
  if (cachedUsersForActions) return cachedUsersForActions;
  try {
    cachedUsersForActions = await fetchUsers();
  } catch (e) {
    console.warn('[incidents] fetchUsers', e);
    cachedUsersForActions = [];
  }
  return cachedUsersForActions;
}

/**
 * @param {ReturnType<typeof mapApiIncident> & { title: string }} inc
 */
async function createLinkedAction(inc) {
  await ensureUsersCached();
  const qhse = cachedUsersForActions?.find((u) => normalizedUserRole(u.role) === 'QHSE');
  const detailParts = [
    `Incident ${inc.ref}`,
    `${inc.type} · ${inc.site}`,
    inc.severity ? `Gravité : ${inc.severity}` : '',
    inc.description ? inc.description.slice(0, 400) : ''
  ].filter(Boolean);
  const body = {
    title: `Suite incident ${inc.ref}`,
    detail: detailParts.join(' — '),
    status: 'À lancer',
    owner: 'Responsable QHSE'
  };
  if (qhse) {
    body.assigneeId = qhse.id;
    body.owner = qhse.name;
  }
  if (appState.activeSiteId) {
    body.siteId = appState.activeSiteId;
  }
  const res = await qhseFetch('/api/actions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  if (!res.ok) {
    try {
      const errBody = await res.json();
      console.error('[incidents] POST action liée', res.status, errBody);
    } catch {
      console.error('[incidents] POST action liée', res.status);
    }
    showToast('Impossible de créer l’action', 'error');
    return;
  }
  showToast(`Action créée — liée à ${inc.ref}`, 'info');
  activityLogStore.add({
    module: 'incidents',
    action: 'Création action liée',
    detail: `Depuis incident ${inc.ref}`,
    user: getSessionUser()?.name || 'Responsable QHSE'
  });
}

/**
 * @param {ReturnType<typeof mapApiIncident> & { title: string }} inc
 * @param {(entry: { module: string; action: string; detail: string; user: string }) => void} [onAddLog]
 */
function buildChip(label, value) {
  const chip = document.createElement('span');
  chip.className = 'incident-card__chip';
  chip.append(
    Object.assign(document.createElement('strong'), { textContent: label }),
    document.createTextNode(String(value))
  );
  return chip;
}

function buildIncidentCard(inc, handlers) {
  const { onDetail, onCreateAction, onStatusChange, canWriteIncidents, canWriteActions } = handlers;

  const article = document.createElement('article');
  article.className = 'incident-card';
  article.dataset.severity = inc.severity;
  if (inc.severity === 'critique') {
    article.classList.add('incident-card--critical');
  }

  const main = document.createElement('div');
  main.className = 'incident-card__main';

  const refEl = document.createElement('p');
  refEl.className = 'incident-card__ref';
  refEl.textContent = inc.ref;

  const h = document.createElement('h4');
  h.className = 'incident-card__title';
  h.textContent = inc.title;

  const chips = document.createElement('div');
  chips.className = 'incident-card__chips';
  chips.append(
    buildChip('Type', inc.type),
    buildChip('Date', inc.date),
    buildChip('Site', inc.site)
  );

  main.append(refEl, h, chips);

  const side = document.createElement('div');
  side.className = 'incident-card__side';

  const badges = document.createElement('div');
  badges.className = 'incident-card__badges';
  const badgeSev = document.createElement('span');
  badgeSev.className = `ds-badge ${severityDsBadgeClass(inc.severity)}`;
  badgeSev.textContent =
    inc.severity.charAt(0).toUpperCase() + inc.severity.slice(1);
  const badgeSt = document.createElement('span');
  badgeSt.className = `ds-badge ${isStatusClosed(inc.status) ? 'ds-badge--ok' : 'ds-badge--info'}`;
  badgeSt.textContent = inc.status;
  badges.append(badgeSev, badgeSt);

  const statusRow = document.createElement('div');
  statusRow.className = 'incident-card__status-row';
  const lab = document.createElement('label');
  const labSpan = document.createElement('span');
  labSpan.textContent = 'Statut';
  const sel = document.createElement('select');
  sel.className = 'control-select';
  sel.disabled = !canWriteIncidents;
  if (!canWriteIncidents) {
    sel.title = 'Modification du statut réservée (écriture incidents)';
  }
  statusOptionsForSelect(inc.status).forEach((opt) => {
    const o = document.createElement('option');
    o.value = opt;
    o.textContent = opt;
    sel.append(o);
  });
  if ([...sel.options].some((o) => o.value === inc.status)) {
    sel.value = inc.status;
  }
  sel.addEventListener('change', () => {
    if (sel.value !== inc.status) {
      onStatusChange(inc, sel.value, sel);
    }
  });
  lab.append(labSpan, sel);
  statusRow.append(lab);

  const acts = document.createElement('div');
  acts.className = 'incident-card__acts';

  const btnDetail = document.createElement('button');
  btnDetail.type = 'button';
  btnDetail.className = 'incident-card__act incident-card__act--ghost';
  btnDetail.textContent = 'Voir le détail';
  btnDetail.addEventListener('click', () => onDetail(inc));

  const btnAction = document.createElement('button');
  btnAction.type = 'button';
  btnAction.className = 'btn btn-primary incident-card__act incident-card__act--primary';
  btnAction.textContent = 'Créer une action';
  btnAction.hidden = !canWriteActions;
  btnAction.addEventListener('click', () => onCreateAction(inc));

  acts.append(btnDetail, btnAction);

  side.append(badges, statusRow, acts);
  article.append(main, side);
  return article;
}

function createDetailDialog() {
  const dlg = document.createElement('dialog');
  dlg.className = 'incidents-detail-dialog';

  dlg.addEventListener('click', (e) => {
    if (e.target === dlg) dlg.close();
  });

  function show(inc) {
    dlg.replaceChildren();
    const inner = document.createElement('div');
    inner.className = 'incidents-detail-dialog__inner';

    const head = document.createElement('div');
    head.className = 'incidents-detail-dialog__head';
    const h2 = document.createElement('h2');
    h2.textContent = inc.ref;
    const closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.className = 'btn incidents-detail-dialog__close';
    closeBtn.textContent = 'Fermer';
    closeBtn.addEventListener('click', () => dlg.close());
    head.append(h2, closeBtn);

    const grid = document.createElement('dl');
    grid.className = 'incidents-detail-dialog__grid';

    const addRow = (label, value) => {
      const dt = document.createElement('dt');
      dt.textContent = label;
      const dd = document.createElement('dd');
      dd.textContent = value;
      grid.append(dt, dd);
    };

    addRow('Titre', inc.title);
    addRow('Type', inc.type);
    addRow('Site', inc.site);
    addRow(
      'Gravité',
      inc.severity.charAt(0).toUpperCase() + inc.severity.slice(1)
    );
    addRow('Statut', inc.status);
    addRow('Date', inc.date);

    const desc = document.createElement('p');
    desc.className = 'incidents-detail-dialog__desc';
    desc.textContent = (inc.description || '').trim() || '— Aucune description.';

    inner.append(head, grid, desc);
    dlg.append(inner);
    dlg.showModal();
  }

  return { element: dlg, show };
}

export function renderIncidents(onAddLog) {
  /* Évite liste / compteurs obsolètes quand on revient sur la page (variable module). */
  incidentRecords = [];

  const page = document.createElement('section');
  page.className = 'page-stack incidents-page incidents-page--premium';

  let panelFilterStatus = 'all';
  let panelFilterSeverity = 'all';
  let filterDateRange = 'all';
  let filterSeverity = '';
  let filterStatus = '';

  function renderFilteredList() {
    refreshList();
  }

  const detailDialog = createDetailDialog();
  page.append(detailDialog.element);

  const siteLabel = appState.currentSite || 'Tous sites';

  const hero = document.createElement('section');
  hero.className = 'hero card-soft incidents-hero';
  const heroShell = document.createElement('div');
  heroShell.className = 'incidents-hero__shell';
  const heroCopy = document.createElement('div');
  heroCopy.className = 'incidents-hero__copy';
  const heroKicker = document.createElement('div');
  heroKicker.className = 'section-kicker incidents-hero__kicker';
  heroKicker.textContent = `Terrain · ${siteLabel}`;
  const heroTitle = document.createElement('h1');
  heroTitle.className = 'incidents-hero__title';
  heroTitle.textContent = 'Incidents';
  const heroLead1 = document.createElement('p');
  heroLead1.className = 'incidents-hero__lead incidents-hero__lead--primary';
  heroLead1.textContent =
    'Priorisez les situations graves, déclarez en quelques secondes et reliez chaque fiche au plan d’actions.';
  const heroLead2 = document.createElement('p');
  heroLead2.className = 'incidents-hero__lead incidents-hero__lead--secondary';
  heroLead2.textContent =
    'Cartes lisibles, gravité critique en tête, filtres rapides — pour agir sans perdre de temps.';
  heroCopy.append(heroKicker, heroTitle, heroLead1, heroLead2);

  const heroActions = document.createElement('div');
  heroActions.className = 'incidents-hero__actions';
  const heroBtnDeclare = document.createElement('button');
  heroBtnDeclare.type = 'button';
  heroBtnDeclare.className = 'btn btn-primary incidents-hero__cta';
  heroBtnDeclare.textContent = 'Nouvelle déclaration';
  const heroBtnDash = document.createElement('button');
  heroBtnDash.type = 'button';
  heroBtnDash.className = 'incidents-hero__secondary';
  heroBtnDash.textContent = 'Vue d’ensemble';
  heroBtnDash.addEventListener('click', () => {
    window.location.hash = 'dashboard';
  });
  heroActions.append(heroBtnDeclare, heroBtnDash);
  heroShell.append(heroCopy, heroActions);
  hero.append(heroShell);

  const synth = document.createElement('div');
  synth.className = 'incidents-synth';

  function makeSynthTile(label, extraClass = '') {
    const tile = document.createElement('div');
    tile.className = `incidents-synth-tile ${extraClass}`.trim();
    const lb = document.createElement('p');
    lb.className = 'incidents-synth-tile__label';
    lb.textContent = label;
    const val = document.createElement('p');
    val.className = 'incidents-synth-tile__value';
    val.textContent = '—';
    const hint = document.createElement('p');
    hint.className = 'incidents-synth-tile__hint';
    tile.append(lb, val, hint);
    return { tile, val, hint };
  }

  const synthTotal = makeSynthTile('Total chargés', '');
  synthTotal.hint.textContent = 'Dans le périmètre API courant';

  const synthCrit = makeSynthTile('Critiques', 'incidents-synth-tile--alert');
  synthCrit.hint.textContent = 'À traiter en priorité';

  const synthOpen = makeSynthTile('Ouverts', '');
  synthOpen.hint.textContent = 'Non clos / non terminés';

  const synthShown = makeSynthTile('Affichés', '');
  synthShown.hint.textContent = 'Après filtres actifs';

  synth.append(
    synthTotal.tile,
    synthCrit.tile,
    synthOpen.tile,
    synthShown.tile
  );

  function filterIncidents(list) {
    return list.filter((inc) => {
      if (filterSeverity && inc.severity !== filterSeverity) return false;
      if (filterStatus && String(inc.status || '').trim() !== filterStatus) {
        return false;
      }
      if (panelFilterSeverity !== 'all' && inc.severity !== panelFilterSeverity)
        return false;
      if (panelFilterStatus === 'all') return true;
      const st = String(inc.status).toLowerCase();
      if (panelFilterStatus === 'nouveau') {
        return st.includes('nouveau') || st.includes('new');
      }
      if (panelFilterStatus === 'clos') {
        return isStatusClosed(st);
      }
      return true;
    });
  }

  function getFilteredSortedRows() {
    let rows = filterIncidents(incidentRecords);
    if (filterDateRange !== 'all') {
      const days = parseInt(filterDateRange, 10);
      const cutoff = Date.now() - days * 86400000;
      rows = rows.filter((inc) => {
        const t = inc.createdAtMs;
        return Number.isFinite(t) && t >= cutoff;
      });
    }
    return sortIncidentsForDisplay(rows);
  }

  function updateSynthTiles(displayedCount) {
    const dash = '—';
    if (apiLoadState === 'loading') {
      synthTotal.val.textContent = dash;
      synthCrit.val.textContent = dash;
      synthOpen.val.textContent = dash;
      synthShown.val.textContent = dash;
      return;
    }
    if (apiLoadState === 'error') {
      synthTotal.val.textContent = dash;
      synthCrit.val.textContent = dash;
      synthOpen.val.textContent = dash;
      synthShown.val.textContent = dash;
      return;
    }
    const total = incidentRecords.length;
    const crit = incidentRecords.filter((i) => i.severity === 'critique').length;
    const open = countOpenIncidents(incidentRecords);
    synthTotal.val.textContent = String(total);
    synthCrit.val.textContent = String(crit);
    synthOpen.val.textContent = String(open);
    synthShown.val.textContent = String(displayedCount);
  }

  const filtersSection = document.createElement('section');
  filtersSection.className = 'incidents-section';
  const filtersHead = document.createElement('header');
  filtersHead.className = 'incidents-section-head';
  const fk = document.createElement('span');
  fk.className = 'incidents-section-kicker';
  fk.textContent = 'Filtrer';
  const fh = document.createElement('h2');
  fh.className = 'incidents-section-title';
  fh.textContent = 'Affiner la liste';
  const fs = document.createElement('p');
  fs.className = 'incidents-section-sub';
  fs.textContent =
    'Gravité, statut et période — combinaisons instantanées, sans recharger la page.';
  filtersHead.append(fk, fh, fs);

  const filtersWrap = document.createElement('div');
  filtersWrap.className = 'incidents-filters-wrap';

  const filtersBar = document.createElement('div');
  filtersBar.className = 'incidents-filters';

  const statusLab = document.createElement('label');
  const statusLabSpan = document.createElement('span');
  statusLabSpan.textContent = 'Statut';
  const statusSel = document.createElement('select');
  statusSel.className = 'control-select';
  [
    ['all', 'Tous'],
    ['nouveau', 'Nouveau'],
    ['clos', 'Clos / terminé']
  ].forEach(([v, t]) => {
    const o = document.createElement('option');
    o.value = v;
    o.textContent = t;
    statusSel.append(o);
  });
  statusSel.addEventListener('change', () => {
    panelFilterStatus = statusSel.value;
    refreshList();
  });
  statusLab.append(statusLabSpan, statusSel);

  const sevLab = document.createElement('label');
  const sevLabSpan = document.createElement('span');
  sevLabSpan.textContent = 'Gravité';
  const sevSel = document.createElement('select');
  sevSel.className = 'control-select';
  [
    ['all', 'Toutes'],
    ['critique', 'Critique'],
    ['moyen', 'Moyen'],
    ['faible', 'Faible']
  ].forEach(([v, t]) => {
    const o = document.createElement('option');
    o.value = v;
    o.textContent = t;
    sevSel.append(o);
  });
  sevSel.addEventListener('change', () => {
    panelFilterSeverity = sevSel.value;
    refreshList();
  });
  sevLab.append(sevLabSpan, sevSel);

  const dateLab = document.createElement('label');
  const dateLabSpan = document.createElement('span');
  dateLabSpan.textContent = 'Période';
  const dateSel = document.createElement('select');
  dateSel.className = 'control-select';
  [
    ['all', 'Toutes'],
    ['7', '7 derniers jours'],
    ['30', '30 derniers jours']
  ].forEach(([v, t]) => {
    const o = document.createElement('option');
    o.value = v;
    o.textContent = t;
    dateSel.append(o);
  });
  dateSel.addEventListener('change', () => {
    filterDateRange = dateSel.value;
    refreshList();
  });
  dateLab.append(dateLabSpan, dateSel);

  filtersBar.append(statusLab, sevLab, dateLab);
  filtersWrap.append(filtersBar);
  filtersSection.append(filtersHead, filtersWrap);

  const quick = document.createElement('article');
  quick.id = 'incidents-declare';
  quick.className = 'content-card card-soft incidents-form-card incidents-premium-card';
  quick.innerHTML = `
    <div class="content-card-head">
      <div>
        <div class="section-kicker">Déclaration rapide</div>
        <h3>Nouvel incident</h3>
        <p class="incidents-form-lead">
          Type, date des faits, site, gravité et description — enregistrement immédiat dans le registre.
        </p>
        <p class="incidents-form-api-hint" title="URL technique pour support / intégration">
          API : <code>${getApiBase()}</code>
        </p>
      </div>
    </div>
    <div class="incidents-form-grid">
      <label class="field">
        <span>Type</span>
        <select class="control-select incident-field-type" style="min-height:42px;font-size:13px"></select>
      </label>
      <label class="field">
        <span>Date des faits</span>
        <input type="date" class="control-input incidents-field-date incident-field-date" />
      </label>
      <label class="field field-full">
        <span>Site</span>
        <select class="control-select incident-field-site" style="min-height:42px;font-size:13px"></select>
      </label>
      <div class="field field-full">
        <span>Gravité</span>
        <div class="incident-severity-mount"></div>
      </div>
      <label class="field field-full">
        <span>Description</span>
        <textarea class="control-input incidents-field-desc incident-field-desc" maxlength="2000" rows="3" placeholder="Que s’est-il passé ? Où ? Conséquences immédiates ?" autocomplete="off"></textarea>
      </label>
      <div class="field-full incidents-form-actions">
        <button type="button" class="text-button incidents-photo">Pièce jointe photo (bientôt)</button>
        <button type="button" class="btn btn-primary incidents-submit incident-submit">Enregistrer l’incident</button>
      </div>
    </div>
  `;

  const typeSelect = quick.querySelector('.incident-field-type');
  const optTypePlaceholder = document.createElement('option');
  optTypePlaceholder.value = '';
  optTypePlaceholder.textContent = '— Choisir le type —';
  typeSelect.append(optTypePlaceholder);
  INCIDENT_TYPES.forEach((t) => {
    const opt = document.createElement('option');
    opt.value = t;
    opt.textContent = t;
    typeSelect.append(opt);
  });

  const dateFactsInput = quick.querySelector('.incident-field-date');
  try {
    const t = new Date();
    dateFactsInput.valueAsDate = t;
  } catch {
    /* ignore */
  }

  const siteSelect = quick.querySelector('.incident-field-site');

  async function fillIncidentSiteSelect() {
    siteSelect.innerHTML = '';
    const namesSeen = new Set();
    try {
      const catalog = await fetchSitesCatalog();
      catalog.forEach((s) => {
        if (!s?.name) return;
        const opt = document.createElement('option');
        opt.value = s.name;
        opt.textContent = s.code ? `${s.name} (${s.code})` : s.name;
        opt.dataset.siteId = s.id;
        siteSelect.append(opt);
        namesSeen.add(s.name);
      });
    } catch {
      /* fallback */
    }
    siteOptions.forEach((s) => {
      if (namesSeen.has(s)) return;
      const opt = document.createElement('option');
      opt.value = s;
      opt.textContent = s;
      siteSelect.append(opt);
    });

    if (appState.activeSiteId) {
      const hit = [...siteSelect.options].find(
        (o) => o.dataset.siteId === appState.activeSiteId
      );
      if (hit) {
        siteSelect.value = hit.value;
        return;
      }
    }
    const activeSite = appState.currentSite;
    if (activeSite && siteOptions.includes(activeSite)) {
      siteSelect.value = activeSite;
    } else if ([...siteSelect.options].some((o) => o.value === activeSite)) {
      siteSelect.value = activeSite;
    } else if (siteSelect.options.length) {
      siteSelect.selectedIndex = 0;
    }
  }

  const descInput = quick.querySelector('.incident-field-desc');
  const severityMount = quick.querySelector('.incident-severity-mount');
  const severity = createSeveritySegment('moyen');
  severityMount.append(severity.element);

  function applyIncidentImportDraftIfAny() {
    const draft = readImportDraft();
    if (!draft || draft.targetPageId !== 'incidents' || !draft.prefillData) {
      return;
    }
    const p = draft.prefillData;
    if (p.type && INCIDENT_TYPES.includes(p.type)) {
      typeSelect.value = p.type;
    }
    if (p.site && typeof p.site === 'string') {
      const siteStr = p.site.trim();
      const matchValue = [...siteSelect.options].some((o) => o.value === siteStr);
      if (matchValue) {
        siteSelect.value = siteStr;
      } else if (siteOptions.includes(p.site)) {
        siteSelect.value = p.site;
      }
    }
    const sevRaw = p.severity || p.gravite;
    if (sevRaw) {
      severity.setValue(normalizeSeverity(String(sevRaw)));
    }
    let desc = p.description ? String(p.description) : '';
    if (
      p.site &&
      typeof p.site === 'string' &&
      !siteOptions.includes(p.site) &&
      ![...siteSelect.options].some((o) => o.value === p.site.trim()) &&
      desc.length < 1900
    ) {
      const hint = `[Site détecté (non listé) : ${p.site.slice(0, 48)}] `;
      desc = hint + desc;
    }
    if (desc) {
      descInput.value = desc.slice(0, 2000);
    }
    clearImportDraft();
    showToast('Brouillon import appliqué — vérifiez puis enregistrez.', 'info');
  }

  (async function initIncidentSiteAndDraft() {
    await fillIncidentSiteSelect();
    applyIncidentImportDraftIfAny();
  })();

  const submitBtn = quick.querySelector('.incident-submit');
  const canDeclare = canResource(getSessionUser()?.role, 'incidents', 'write');
  if (!canDeclare && getSessionUser()) {
    quick.querySelector('.incidents-form-grid').style.opacity = '0.58';
    submitBtn.disabled = true;
    submitBtn.title = 'Déclaration réservée — votre rôle est en lecture sur les incidents';
  }

  ensureIncidentsSlideOverStyles();
  document.getElementById('qhse-inc-slideover-overlay')?.remove();
  document.getElementById('qhse-inc-slideover-panel')?.remove();

  function createSlideOver() {
    const overlay = document.createElement('div');
    overlay.className = 'inc-overlay';
    overlay.id = 'qhse-inc-slideover-overlay';
    overlay.setAttribute('aria-hidden', 'true');

    const panel = document.createElement('div');
    panel.className = 'inc-slideover';
    panel.id = 'qhse-inc-slideover-panel';
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-modal', 'true');
    panel.setAttribute('aria-label', 'Déclarer un incident');

    const header = document.createElement('div');
    header.className = 'inc-slideover__head';
    header.innerHTML = `
    <span class="inc-slideover__title">
      Déclarer un incident
    </span>
    <button type="button"
      class="inc-slideover__close"
      aria-label="Fermer">
      <svg width="18" height="18"
        viewBox="0 0 24 24" fill="none"
        stroke="currentColor" stroke-width="2">
        <path d="M18 6L6 18M6 6l12 12"/>
      </svg>
    </button>
  `;

    const body = document.createElement('div');
    body.className = 'inc-slideover__body';

    panel.append(header, body);

    function onDocKeydown(e) {
      if (e.key !== 'Escape') return;
      if (!panel.classList.contains('inc-slideover--open')) return;
      e.preventDefault();
      close();
    }

    function open(formElement) {
      body.replaceChildren(formElement);
      overlay.setAttribute('aria-hidden', 'false');
      overlay.classList.add('inc-overlay--open');
      panel.classList.add('inc-slideover--open');
      document.body.style.overflow = 'hidden';
      document.addEventListener('keydown', onDocKeydown);
      panel.querySelector('input, select, textarea')?.focus();
    }

    function close() {
      overlay.setAttribute('aria-hidden', 'true');
      overlay.classList.remove('inc-overlay--open');
      panel.classList.remove('inc-slideover--open');
      document.body.style.overflow = '';
      document.removeEventListener('keydown', onDocKeydown);
      body.replaceChildren();
    }

    overlay.addEventListener('click', close);
    header.querySelector('.inc-slideover__close').addEventListener('click', close);

    document.body.append(overlay, panel);
    return { open, close };
  }

  const slideOver = createSlideOver();

  heroBtnDeclare.addEventListener('click', () => slideOver.open(quick));

  const listCard = document.createElement('article');
  listCard.className = 'content-card card-soft incidents-premium-card';
  listCard.id = 'incidents-recent-list';
  listCard.innerHTML = `
    <div class="content-card-head">
      <div>
        <div class="section-kicker">Registre</div>
        <h3 class="incidents-list-heading"></h3>
        <p class="incidents-list-sub" style="margin:0;font-size:13px;line-height:1.55;color:var(--text2);max-width:62ch">${LIST_SUB_DEFAULT}</p>
      </div>
    </div>
  `;

  const listHeading = listCard.querySelector('.incidents-list-heading');
  const listSub = listCard.querySelector('.incidents-list-sub');
  const listHost = document.createElement('div');
  listHost.className = 'incidents-list-host';

  ensureIncidentsToolbarStyles();
  ensureIncidentsStatesStyles();

  const toolbar = document.createElement('div');
  toolbar.className = 'incidents-toolbar';
  toolbar.innerHTML = `
  <div class="incidents-toolbar__left">
    <span class="incidents-count">
      ${incidentRecords.length} incident${incidentRecords.length !== 1 ? 's' : ''}
    </span>
  </div>
  <div class="incidents-toolbar__right">
    <select class="control-select incidents-filter-severity">
      <option value="">Toutes gravités</option>
      <option value="critique">Critique</option>
      <option value="moyen">Moyen</option>
      <option value="faible">Faible</option>
    </select>
    <select class="control-select incidents-filter-status">
      <option value="">Tous statuts</option>
      <option value="Nouveau">Nouveau</option>
      <option value="En cours">En cours</option>
      <option value="Investigation">Investigation</option>
      <option value="Clôturé">Clôturé</option>
    </select>
  </div>
`;

  toolbar.querySelector('.incidents-filter-severity').addEventListener('change', (e) => {
    filterSeverity = e.target.value;
    renderFilteredList();
  });
  toolbar.querySelector('.incidents-filter-status').addEventListener('change', (e) => {
    filterStatus = e.target.value;
    renderFilteredList();
  });

  listCard.append(toolbar);
  listCard.append(listHost);

  let apiLoadState = 'loading';

  const canWriteIncidents = canResource(getSessionUser()?.role, 'incidents', 'write');
  const canWriteActions = canResource(getSessionUser()?.role, 'actions', 'write');

  async function patchIncidentStatus(inc, newStatus, selectEl) {
    selectEl.disabled = true;
    try {
      const res = await qhseFetch(
        `/api/incidents/${encodeURIComponent(inc.ref)}`,
        {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status: newStatus })
        }
      );
      if (!res.ok) {
        let msg = 'Mise à jour impossible';
        try {
          const b = await res.json();
          if (b.error) msg = b.error;
        } catch {
          /* ignore */
        }
        showToast(msg, 'error');
        selectEl.value = inc.status;
        return;
      }
      const updated = await res.json();
      const entry = mapApiIncident(updated);
      if (!entry) {
        showToast('Réponse serveur inattendue', 'error');
        selectEl.value = inc.status;
        return;
      }
      const idx = incidentRecords.findIndex((r) => r.ref === entry.ref);
      if (idx >= 0) incidentRecords[idx] = entry;
      else incidentRecords = [entry, ...incidentRecords];
      showToast(`Statut : ${newStatus}`, 'info');
      if (typeof onAddLog === 'function') {
    onAddLog({
      module: 'incidents',
          action: 'Statut incident',
          detail: `${inc.ref} → ${newStatus}`,
          user: getSessionUser()?.name || 'Responsable QHSE'
        });
      }
      refreshList();
    } catch (err) {
      console.error('[incidents] PATCH', err);
      showToast('Erreur réseau', 'error');
      selectEl.value = inc.status;
    } finally {
      selectEl.disabled = !canWriteIncidents;
    }
  }

  function refreshList() {
    const rows = getFilteredSortedRows();
    updateSynthTiles(rows.length);

    const countEl = toolbar.querySelector('.incidents-count');
    if (countEl) {
      const n = rows.length;
      countEl.textContent = `${n} incident${n !== 1 ? 's' : ''}`;
    }

    if (apiLoadState === 'loading') {
      listHeading.textContent = 'Incidents';
    } else if (apiLoadState === 'error') {
      listHeading.textContent = 'Incidents';
    } else {
      const total = incidentRecords.length;
      const shown = rows.length;
      listHeading.textContent =
        shown === total ? `Incidents (${total})` : `Incidents — ${shown} sur ${total}`;
    }
    if (apiLoadState === 'loading') {
      listSub.textContent = 'Chargement des données…';
    } else if (apiLoadState === 'error') {
      listSub.textContent =
        'Liste indisponible — vérifiez que l’API est joignable (port configuré).';
    } else {
      listSub.textContent = LIST_SUB_DEFAULT;
    }

    listHost.replaceChildren();

    if (apiLoadState === 'loading') {
      const wrap = document.createElement('div');
      wrap.className = 'incidents-skeleton';
      const skeletonHTML = [1, 2, 3]
        .map(
          () => `
  <div class="skeleton-card">
    <div class="skeleton-line skeleton-line--title"></div>
    <div class="skeleton-line skeleton-line--sub"></div>
    <div class="skeleton-line skeleton-line--meta"></div>
  </div>
`
        )
        .join('');
      wrap.innerHTML = skeletonHTML;
      listHost.append(wrap);
      return;
    }

    if (apiLoadState === 'error' && incidentRecords.length === 0) {
      const wrap = document.createElement('div');
      wrap.className = 'incidents-empty';
      const t = document.createElement('p');
      t.className = 'incidents-empty__title';
      t.textContent = 'Liste indisponible';
      const s = document.createElement('p');
      s.className = 'incidents-empty__sub';
      s.textContent =
        'Vérifiez que l’API tourne et que le navigateur peut l’atteindre (ex. http://localhost:5173 avec backend actif).';
      wrap.append(t, s);
      listHost.append(wrap);
      return;
    }

    if (apiLoadState === 'ok' && incidentRecords.length === 0) {
      const wrap = document.createElement('div');
      wrap.className = 'incidents-empty';
      wrap.innerHTML = `
  <svg width="36" height="36" viewBox="0 0 24 24" fill="none"
    stroke="currentColor" stroke-width="1.5"
    style="opacity:.35;color:var(--text2)">
    <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94
             a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
    <path d="M12 9v4"/><path d="M12 17h.01"/>
  </svg>
  <p class="incidents-empty__title">Aucun incident enregistré</p>
  <p class="incidents-empty__sub">
    Déclarez le premier incident de votre périmètre.
  </p>
  <button type="button" class="btn btn-primary incidents-empty__cta">
    Déclarer un incident
  </button>
`;
      const emptyCta = wrap.querySelector('.incidents-empty__cta');
      if (emptyCta) emptyCta.addEventListener('click', () => slideOver.open(quick));
      listHost.append(wrap);
      return;
    }

    if (apiLoadState === 'ok' && rows.length === 0 && incidentRecords.length > 0) {
      const wrap = document.createElement('div');
      wrap.className = 'incidents-empty';
      const t = document.createElement('p');
      t.className = 'incidents-empty__title';
      t.textContent = 'Aucun résultat';
      const s = document.createElement('p');
      s.className = 'incidents-empty__sub';
      s.textContent =
        'Ajustez les filtres (statut, gravité, période) pour retrouver des fiches dans le registre.';
      wrap.append(t, s);
      listHost.append(wrap);
      return;
    }

    const displayRows = rows.map((r) => mapRowToDisplay(r));
    displayRows.forEach((inc) => {
      listHost.append(
        buildIncidentCard(inc, {
          onDetail: (i) => detailDialog.show(i),
          onCreateAction: async (i) => {
            await createLinkedAction(i);
          },
          onStatusChange: patchIncidentStatus,
          canWriteIncidents,
          canWriteActions
        })
      );
    });
  }

  refreshList();

  (async function loadIncidentsFromApi() {
    try {
      const res = await qhseFetch(withSiteQuery('/api/incidents?limit=500'));
      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }
      const data = await res.json();
      const rows = Array.isArray(data) ? data : [];
      incidentRecords = rows.map(mapApiIncident).filter(Boolean);
      apiLoadState = 'ok';
      refreshList();
    } catch (err) {
      console.error('[incidents] GET /api/incidents', err);
      showToast('Erreur serveur', 'error');
      incidentRecords = [];
      apiLoadState = 'error';
      refreshList();
    }
  })();

  ensureUsersCached().catch(() => {});

  quick.querySelector('.incidents-photo').addEventListener('click', () => {
    showToast('Pièce jointe photo : bientôt (mode hors ligne)', 'info');
  });

  submitBtn.addEventListener('click', async () => {
    const type = typeSelect.value.trim();
    const site = siteSelect.value.trim();

    if (!type || !site) {
      showToast('Type et site obligatoires', 'error');
      return;
    }

    const sev = severity.getValue();
    const descRaw = (descInput.value || '').trim();
    const dateNote =
      dateFactsInput.value && typeof dateFactsInput.value === 'string'
        ? `Faits le ${formatIsoDateToFr(dateFactsInput.value)}. `
        : '';
    const detailText = (dateNote + descRaw).trim();
    const detailForLog = detailText || 'Sans description';

    const ref = computeNextRef(incidentRecords);

    submitBtn.disabled = true;
    try {
      const res = await qhseFetch('/api/incidents', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ref,
          type,
          site,
          severity: sev,
          description: detailText || undefined,
          status: 'Nouveau',
          ...(siteSelect.selectedOptions[0]?.dataset.siteId
            ? { siteId: siteSelect.selectedOptions[0].dataset.siteId }
            : {})
        })
      });

      if (!res.ok) {
        try {
          const body = await res.json();
          console.error('[incidents] POST /api/incidents', res.status, body);
        } catch {
          console.error('[incidents] POST /api/incidents', res.status);
        }
        showToast('Erreur serveur', 'error');
        return;
      }

      const created = await res.json();
      const entry = mapApiIncident(created);
      if (!entry) {
        console.error('[incidents] réponse POST invalide', created);
        showToast('Erreur serveur', 'error');
        return;
      }
      incidentRecords = [entry, ...incidentRecords.filter((r) => r.ref !== entry.ref)];
      apiLoadState = 'ok';
      refreshList();
      slideOver.close();

      if (typeof onAddLog === 'function') {
        onAddLog({
          module: 'incidents',
          action: 'Incident déclaré',
          detail: `${ref} · ${type} · ${site} · ${sev} — ${detailForLog.slice(0, 80)}${detailForLog.length > 80 ? '…' : ''}`,
          user: 'Agent terrain'
        });
      }

      showToast(`Incident enregistré : ${ref}`, 'info');
      descInput.value = '';
      severity.setValue('moyen');
      typeSelect.value = '';
      try {
        dateFactsInput.valueAsDate = new Date();
      } catch {
        dateFactsInput.value = '';
      }

      setTimeout(() => {
        document.getElementById('incidents-recent-list')?.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }, 0);
    } catch (err) {
      console.error('[incidents] POST /api/incidents', err);
      showToast('Erreur serveur', 'error');
    } finally {
      submitBtn.disabled = false;
    }
  });

  page.append(hero, synth, filtersSection, listCard);
  return page;
}
