import { showToast } from '../components/toast.js';
import { qhseFetch } from '../utils/qhseFetch.js';
import { withSiteQuery } from '../utils/siteFilter.js';
import { appState } from '../utils/state.js';
import { getSessionUser } from '../data/sessionUser.js';
import { canResource } from '../utils/permissionsUi.js';
import { activityLogStore } from '../data/activityLog.js';
import { ensureAuditProductsStyles } from '../components/auditProductsStyles.js';
import { ensureAuditPlusStyles } from '../components/auditPlusStyles.js';
import { createQhseKpiStrip } from '../components/qhseKpiStrip.js';
import { ensureQhsePilotageStyles } from '../components/qhsePilotageStyles.js';
import { createAuditScoreGauge } from '../components/auditScoreGauge.js';
import { createAuditFieldMode } from '../components/auditFieldMode.js';
import { fetchUsers } from '../services/users.service.js';
import { readImportDraft, clearImportDraft } from '../utils/importDraft.js';

/** Données mock — module Audits */
const AUDIT_KPI = [
  { label: 'Audits réalisés (YTD)', value: '12', tone: 'blue', hint: 'Périmètre interne + surveillance' },
  { label: 'Taux de conformité', value: '87%', tone: 'green', hint: 'Moyenne pondérée des derniers audits' },
  { label: 'Non-conformités ouvertes', value: '8', tone: 'amber', hint: 'Suivi plan d’actions' },
  { label: 'Audits en retard', value: '2', tone: 'red', hint: 'Échéances dépassées ou à reprogrammer' }
];

const PLANNED_AUDITS = [
  {
    ref: 'AUD-P-021',
    site: 'Site principal',
    auditeur: 'M. Diallo',
    date: '08/04/2026',
    statut: 'à venir'
  },
  {
    ref: 'AUD-P-022',
    site: 'Site sud',
    auditeur: 'Équipe qualité',
    date: '02/04/2026',
    statut: 'en cours'
  },
  {
    ref: 'AUD-P-019',
    site: 'Site principal',
    auditeur: 'Cabinet externe',
    date: '15/03/2026',
    statut: 'terminé'
  }
];

const LAST_AUDIT = {
  date: '28/03/2026',
  site: 'Site principal',
  score: 78,
  progress: 72,
  conforme: false,
  ref: 'AUD-2026-014',
  ncCount: 2,
  statusLabel: 'Non conforme — actions requises'
};

const CHECKLIST = [
  { point: 'Contrôles opérationnels documentés', conforme: true },
  { point: 'Gestion des déchets dangereux (registres)', conforme: false },
  { point: 'Habilitations et autorisations à jour', conforme: true },
  { point: 'Plan urgence environnementale / exercices', conforme: false }
];

const HISTORY = [
  { date: '15/02/2026', score: 82 },
  { date: '20/11/2025', score: 79 },
  { date: '05/08/2025', score: 74 }
];

/** Points pour le mode terrain (même thématique que la checklist synthèse) */
const FIELD_POINTS = [
  { id: 'f1', point: 'Contrôles opérationnels documentés' },
  { id: 'f2', point: 'Gestion des déchets dangereux (registres)' },
  { id: 'f3', point: 'Habilitations et autorisations à jour' },
  { id: 'f4', point: 'Plan urgence environnementale / exercices' }
];

/** Dernier audit (tri API) — même source pour PDF, e-mail et note d’envoi auto. */
async function loadLatestAuditRow() {
  const res = await qhseFetch('/api/audits?limit=500');
  if (!res.ok) {
    return { ok: false, row: null, status: res.status };
  }
  const audits = await res.json().catch(() => null);
  if (!Array.isArray(audits) || audits.length === 0) {
    return { ok: true, row: null };
  }
  return { ok: true, row: audits[0] };
}

async function loadLatestAuditRef() {
  const { ok, row, status } = await loadLatestAuditRow();
  return { ok, ref: row?.ref ?? null, status, row };
}

/**
 * Brouillon issu de l’import (phase 3) — création API uniquement après validation utilisateur.
 * @param {Record<string, unknown>} prefill
 */
function createAuditImportDraftSection(prefill, canAuditWrite, su) {
  const card = document.createElement('article');
  card.className = 'content-card card-soft';
  card.style.marginBottom = '14px';
  card.innerHTML = `
    <div class="content-card-head">
      <div>
        <div class="section-kicker">Import documentaire</div>
        <h3>Brouillon audit — à valider</h3>
        <p class="content-card-lead" style="margin:0;max-width:56ch;font-size:13px">Données proposées depuis l’import ; rien n’est créé tant vous n’enregistrez pas.</p>
      </div>
    </div>
    <div class="form-grid" style="gap:12px">
      <label class="field"><span>Référence</span><input type="text" class="control-input audit-draft-ref" autocomplete="off" /></label>
      <label class="field"><span>Site</span><input type="text" class="control-input audit-draft-site" autocomplete="off" /></label>
      <label class="field"><span>Score (0–100)</span><input type="number" min="0" max="100" class="control-input audit-draft-score" /></label>
      <label class="field field-full"><span>Statut</span><input type="text" class="control-input audit-draft-status" placeholder="ex. terminé, en cours" autocomplete="off" /></label>
    </div>
    <div style="display:flex;flex-wrap:wrap;gap:10px;margin-top:12px;align-items:center">
      <button type="button" class="btn btn-primary audit-draft-save">Créer l’audit</button>
      <button type="button" class="text-button audit-draft-dismiss" style="font-weight:700">Ignorer le brouillon</button>
    </div>
  `;
  const refIn = card.querySelector('.audit-draft-ref');
  const siteIn = card.querySelector('.audit-draft-site');
  const scoreIn = card.querySelector('.audit-draft-score');
  const statusIn = card.querySelector('.audit-draft-status');
  refIn.value = prefill.ref != null ? String(prefill.ref) : '';
  siteIn.value = prefill.site != null ? String(prefill.site) : '';
  scoreIn.value =
    prefill.score != null && prefill.score !== ''
      ? String(prefill.score)
      : '';
  statusIn.value = prefill.status != null ? String(prefill.status) : 'en cours';

  const saveBtn = card.querySelector('.audit-draft-save');
  const dismissBtn = card.querySelector('.audit-draft-dismiss');
  if (!canAuditWrite && su) {
    saveBtn.disabled = true;
    saveBtn.title = 'Création réservée';
  }
  saveBtn.addEventListener('click', async () => {
    const ref = refIn.value.trim();
    const site = siteIn.value.trim();
    const status = statusIn.value.trim() || 'en cours';
    const score = parseInt(scoreIn.value, 10);
    if (!ref || !site || Number.isNaN(score)) {
      showToast('Référence, site et score valides requis', 'error');
      return;
    }
    saveBtn.disabled = true;
    try {
      const res = await qhseFetch('/api/audits', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ref,
          site,
          score,
          status,
          checklist: Array.isArray(prefill.checklist) ? prefill.checklist : undefined,
          ...(appState.activeSiteId ? { siteId: appState.activeSiteId } : {})
        })
      });
      const body = await res.json().catch(() => ({}));
      if (!res.ok) {
        showToast(
          typeof body.error === 'string' ? body.error : 'Erreur création',
          'error'
        );
        return;
      }
      showToast(`Audit ${ref} enregistré.`, 'info');
      clearImportDraft();
      card.remove();
      activityLogStore.add({
        module: 'audits',
        action: 'Audit créé depuis import documentaire',
        detail: ref,
        user: 'Utilisateur'
      });
    } catch (e) {
      console.error(e);
      showToast('Erreur serveur', 'error');
    } finally {
      saveBtn.disabled = !canAuditWrite && !!su;
    }
  });
  dismissBtn.addEventListener('click', () => {
    clearImportDraft();
    card.remove();
  });
  return card;
}

function statutBadgeClass(statut) {
  if (statut === 'terminé') return 'green';
  if (statut === 'en cours') return 'amber';
  return 'blue';
}

function createChecklistRow(item) {
  const row = document.createElement('article');
  row.className = 'list-row audit-checklist-row';
  if (!item.conforme) {
    row.style.borderLeft = '4px solid rgba(239, 91, 107, 0.6)';
    row.style.paddingLeft = '12px';
  }
  const left = document.createElement('div');
  const strong = document.createElement('strong');
  strong.textContent = item.point;
  left.append(strong);
  const badge = document.createElement('span');
  badge.className = `badge ${item.conforme ? 'green' : 'red'}`;
  badge.textContent = item.conforme ? 'Conforme' : 'Non conforme';
  row.append(left, badge);
  return row;
}

function createPlanningTable() {
  const wrap = document.createElement('div');
  wrap.className = 'audit-plan-table-wrap';
  const table = document.createElement('div');
  table.className = 'audit-plan-table';

  const head = document.createElement('div');
  head.className = 'audit-plan-head';
  head.innerHTML = `
    <span>Réf.</span>
    <span>Site</span>
    <span>Auditeur</span>
    <span>Date</span>
    <span>Statut</span>
  `;
  table.append(head);

  PLANNED_AUDITS.forEach((row) => {
    const line = document.createElement('div');
    line.className = 'audit-plan-row';
    const stClass = statutBadgeClass(row.statut);
    line.innerHTML = `
      <span class="audit-plan-ref">${row.ref}</span>
      <span>${row.site}</span>
      <span>${row.auditeur}</span>
      <span>${row.date}</span>
      <span><span class="badge ${stClass}">${row.statut}</span></span>
    `;
    table.append(line);
  });

  wrap.append(table);
  return wrap;
}

export function renderAudits() {
  ensureAuditProductsStyles();
  ensureAuditPlusStyles();
  ensureQhsePilotageStyles();

  const su = getSessionUser();
  const canAuditWrite = canResource(su?.role, 'audits', 'write');
  const canReportRead = canResource(su?.role, 'reports', 'read');
  const canReportWrite = canResource(su?.role, 'reports', 'write');

  const page = document.createElement('section');
  page.className = 'page-stack audit-products-page audit-plus-page';

  const importDraft = readImportDraft();
  const importDraftEl =
    importDraft?.targetPageId === 'audits' && importDraft.prefillData
      ? createAuditImportDraftSection(
          importDraft.prefillData,
          canAuditWrite,
          su
        )
      : null;

  const kpiStrip = createQhseKpiStrip(AUDIT_KPI);
  kpiStrip.classList.add('audit-kpi-strip');

  const planCard = document.createElement('article');
  planCard.className = 'content-card card-soft audit-plan-card';
  planCard.innerHTML = `
    <div class="content-card-head">
      <div>
        <div class="section-kicker">Planification</div>
        <h3>Audits planifiés</h3>
        <p class="content-card-lead">Vue synthèse : référence, site, auditeur, fenêtre et statut opérationnel (mock).</p>
      </div>
    </div>
  `;
  planCard.append(createPlanningTable());
  const planActions = document.createElement('div');
  planActions.className = 'audit-plan-actions';
  const planBtn = document.createElement('button');
  planBtn.type = 'button';
  planBtn.className = 'btn btn-primary';
  planBtn.textContent = 'Planifier un audit';
  planBtn.addEventListener('click', () => {
    showToast('Planification : ouvrir le module calendrier / workflow (démo).', 'info');
    activityLogStore.add({
      module: 'audits',
      action: 'Demande de planification audit',
      detail: 'Depuis Audit+ — maquette front',
      user: 'Coordinateur QHSE'
    });
  });
  if (!canAuditWrite && su) planBtn.style.display = 'none';
  planActions.append(planBtn);
  planCard.append(planActions);

  const lastCard = document.createElement('article');
  lastCard.className = 'content-card card-soft audit-last-card';
  const statusTone = LAST_AUDIT.conforme ? 'green' : 'red';

  lastCard.innerHTML = `
    <div class="content-card-head">
      <div>
        <div class="section-kicker">Dernier audit clôturé</div>
        <h3>Synthèse ${LAST_AUDIT.ref}</h3>
        <p class="content-card-lead audit-last-lead">Site : ${LAST_AUDIT.site} · Date : ${LAST_AUDIT.date}</p>
      </div>
      <span class="badge ${statusTone}">${LAST_AUDIT.conforme ? 'Conforme' : 'Non conforme'}</span>
    </div>
    <div class="audit-last-grid">
      <div class="audit-last-item">
        <span>Score global</span>
        <span class="audit-last-score">${LAST_AUDIT.score}%</span>
      </div>
      <div class="audit-last-item">
        <span>Progression constats</span>
        <span>${LAST_AUDIT.progress}%</span>
      </div>
      <div class="audit-last-item">
        <span>NC relevées</span>
        <span>${LAST_AUDIT.ncCount}</span>
      </div>
      <div class="audit-last-item">
        <span>Statut global</span>
        <span>${LAST_AUDIT.statusLabel}</span>
      </div>
    </div>
    <div class="audit-last-progress">
      <div class="audit-last-progress-top">
        <span>Avancement traitement des constats</span>
        <span>${LAST_AUDIT.progress}%</span>
      </div>
      <div class="audit-progress-bar" aria-hidden="true"><span style="width:${LAST_AUDIT.progress}%"></span></div>
    </div>
    <div class="audit-last-status-row">
      <span class="badge blue">ISO 9001 / 14001 / 45001</span>
      <span class="badge ${statusTone}">Score ${LAST_AUDIT.score}% — ${LAST_AUDIT.statusLabel}</span>
    </div>
  `;

  const layout = document.createElement('section');
  layout.className = 'two-column';

  const checklistCard = document.createElement('article');
  checklistCard.className = 'content-card card-soft';
  checklistCard.innerHTML = `
    <div class="content-card-head">
      <div>
        <div class="section-kicker">Constats</div>
        <h3>Checklist — dernier audit</h3>
        <p class="content-card-lead">Vue lecture seule (synthèse direction). Le mode terrain interactif est accessible via « Lancer un audit ».</p>
      </div>
    </div>
  `;
  const checklistStack = document.createElement('div');
  checklistStack.className = 'stack';
  CHECKLIST.forEach((item) => checklistStack.append(createChecklistRow(item)));
  checklistCard.append(checklistStack);

  const rightStack = document.createElement('div');
  rightStack.className = 'audit-right-stack';

  const scoreCard = document.createElement('article');
  scoreCard.className = 'content-card card-soft';
  scoreCard.append(createAuditScoreGauge(LAST_AUDIT.score, { label: 'Score & objectifs' }));

  const historyCard = document.createElement('article');
  historyCard.className = 'content-card card-soft';
  historyCard.innerHTML = `
    <div class="content-card-head">
      <div>
        <div class="section-kicker">Historique</div>
        <h3>Audits précédents</h3>
      </div>
    </div>
  `;
  const histStack = document.createElement('div');
  histStack.className = 'audit-history-stack';
  HISTORY.forEach((h) => {
    const row = document.createElement('article');
    row.className = 'list-row audit-history-row';
    row.innerHTML = `
      <div>
        <strong>${h.date}</strong>
        <p style="margin:4px 0 0;font-size:13px;color:var(--text2)">Score ${h.score}%</p>
      </div>
      <span class="badge blue">Interne</span>
    `;
    histStack.append(row);
  });
  historyCard.append(histStack);

  rightStack.append(scoreCard, historyCard);
  layout.append(checklistCard, rightStack);

  /** Mode terrain : NC / actions liées à la référence d’audit réelle (synthèse dernier audit). */
  const fieldMode = createAuditFieldMode({
    points: FIELD_POINTS,
    auditRef: LAST_AUDIT.ref,
    siteId: appState.activeSiteId || undefined
  });

  const mainActions = document.createElement('div');
  mainActions.className = 'audit-main-actions';
  const launchBtn = document.createElement('button');
  launchBtn.type = 'button';
  launchBtn.className = 'btn btn-primary';
  launchBtn.textContent = 'Lancer un audit';
  const reportBtn = document.createElement('button');
  reportBtn.type = 'button';
  reportBtn.className = 'text-button';
  reportBtn.textContent = 'Générer rapport';
  reportBtn.style.fontWeight = '800';

  launchBtn.addEventListener('click', () => {
    fieldMode.reset();
    fieldMode.show();
    fieldMode.element.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    showToast('Mode terrain activé — renseignez la checklist ci-dessous.', 'info');
    activityLogStore.add({
      module: 'audits',
      action: 'Ouverture mode audit terrain',
      detail: 'Checklist interactive — maquette',
      user: 'Auditeur terrain'
    });
  });

  if (!canAuditWrite && su) launchBtn.style.display = 'none';

  reportBtn.addEventListener('click', async () => {
    try {
      const { ok, ref: latestRef, status } = await loadLatestAuditRef();
      if (!ok) throw new Error(`Audits ${status}`);
      if (!latestRef) {
        showToast('Aucun audit en base : impossible de générer le rapport PDF.', 'error');
        return;
      }
      const rpt = await qhseFetch(
        `/api/audits/${encodeURIComponent(latestRef)}/report`
      );
      if (!rpt.ok) {
        showToast('Export PDF indisponible', 'error');
        return;
      }
      const blob = await rpt.blob();
      const blobUrl = URL.createObjectURL(blob);
      window.open(blobUrl, '_blank');
      setTimeout(() => URL.revokeObjectURL(blobUrl), 120_000);
      activityLogStore.add({
        module: 'audits',
        action: 'Demande de rapport audit',
        detail: `Synthèse ${latestRef} — export PDF`,
        user: 'Responsable QHSE'
      });
    } catch (e) {
      console.error(e);
      showToast('Erreur serveur', 'error');
    }
  });

  if (!canReportRead && su) reportBtn.style.display = 'none';

  const sendReportRow = document.createElement('div');
  sendReportRow.className = 'audit-send-report-row';
  sendReportRow.style.cssText =
    'display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-top:10px;width:100%';

  const emailInput = document.createElement('input');
  emailInput.type = 'text';
  emailInput.className = 'control-input audit-send-report-email';
  emailInput.setAttribute('aria-label', 'Destinataires du rapport PDF par e-mail');
  emailInput.placeholder = 'E-mail(s), séparés par une virgule';
  emailInput.autocomplete = 'off';
  emailInput.style.cssText = 'flex:1;min-width:min(100%,260px);min-height:44px';

  const sendPdfEmailBtn = document.createElement('button');
  sendPdfEmailBtn.type = 'button';
  sendPdfEmailBtn.className = 'text-button';
  sendPdfEmailBtn.textContent = 'Envoyer le PDF par e-mail';
  sendPdfEmailBtn.style.fontWeight = '800';

  sendReportRow.append(emailInput, sendPdfEmailBtn);

  fetchUsers()
    .then((users) => {
      if (!Array.isArray(users) || !users.length) return;
      const dl = document.createElement('datalist');
      dl.id = `qhse-audit-report-emails-${Math.random().toString(36).slice(2, 9)}`;
      users.forEach((u) => {
        if (!u?.email) return;
        const o = document.createElement('option');
        o.value = u.email;
        if (u.name) o.label = u.name;
        dl.append(o);
      });
      emailInput.setAttribute('list', dl.id);
      sendReportRow.append(dl);
    })
    .catch(() => {});

  sendPdfEmailBtn.addEventListener('click', async () => {
    const toRaw = (emailInput.value || '').trim();
    if (!toRaw) {
      showToast('Indiquez au moins une adresse e-mail.', 'error');
      return;
    }
    sendPdfEmailBtn.disabled = true;
    try {
      const { ok, ref: latestRef, status } = await loadLatestAuditRef();
      if (!ok) throw new Error(`Audits ${status}`);
      if (!latestRef) {
        showToast('Aucun audit en base : impossible d’envoyer le rapport.', 'error');
        return;
      }
      const res = await qhseFetch(
        `/api/audits/${encodeURIComponent(latestRef)}/send-report`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ to: toRaw })
        }
      );
      const body = await res.json().catch(() => ({}));
      if (!res.ok) {
        const msg =
          typeof body.error === 'string'
            ? body.error
            : `Envoi impossible (erreur ${res.status})`;
        showToast(msg, 'error');
        return;
      }
      if (body.ok !== true) {
        showToast(
          typeof body.error === 'string'
            ? body.error
            : 'Réponse serveur inattendue.',
          'error'
        );
        return;
      }
      showToast(body.message || 'Rapport PDF envoyé par e-mail.', 'info');
      activityLogStore.add({
        module: 'audits',
        action: 'Envoi rapport PDF par e-mail',
        detail: `${latestRef} → ${Array.isArray(body.sentTo) ? body.sentTo.join(', ') : toRaw}`,
        user: 'Responsable QHSE'
      });
    } catch (e) {
      console.error(e);
      showToast('Erreur serveur', 'error');
    } finally {
      sendPdfEmailBtn.disabled = false;
    }
  });

  if (!canReportWrite && su) {
    sendReportRow.style.display = 'none';
  }

  const autoReportNote = document.createElement('p');
  autoReportNote.className = 'content-card-lead audit-auto-report-note';
  autoReportNote.style.cssText =
    'margin:8px 0 0;font-size:12px;color:var(--text3);max-width:60ch;line-height:1.45';
  autoReportNote.hidden = true;

  mainActions.append(reportBtn, launchBtn, sendReportRow, autoReportNote);

  loadLatestAuditRow().then(({ ok, row }) => {
    if (!ok || !row?.autoReportSentAt) return;
    const d = new Date(row.autoReportSentAt);
    if (Number.isNaN(d.getTime())) return;
    autoReportNote.textContent = `Audit ${row.ref} : rapport PDF envoyé automatiquement le ${d.toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' })} (clôture).`;
    autoReportNote.hidden = false;
  });

  page.append(
    ...(importDraftEl ? [importDraftEl] : []),
    kpiStrip,
    planCard,
    lastCard,
    layout,
    fieldMode.element,
    mainActions
  );
  return page;
}
