import { risks as mockRisks } from '../data/mock.js';
import { createQhseKpiStrip } from '../components/qhseKpiStrip.js';
import {
  createRiskMatrixPanel,
  parseRiskMatrixGp,
  riskCriticalityFromMeta,
  riskTierFromGp,
  riskLevelLabelFromTier
} from '../components/riskMatrixPanel.js';
import { createRiskRegisterRow } from '../components/riskRegisterRow.js';
import { ensureQhsePilotageStyles } from '../components/qhsePilotageStyles.js';
import { showToast } from '../components/toast.js';
import { qhseFetch } from '../utils/qhseFetch.js';

const CATEGORY_OPTIONS = ['Sécurité', 'Environnement', 'Qualité', 'Autre'];
const LEVEL_OPTIONS = [
  { value: 'élevée', label: 'Élevée' },
  { value: 'moyenne', label: 'Moyenne' },
  { value: 'faible', label: 'Faible' }
];

const RISK_AI_DISCLAIMER =
  'Suggestions basées sur analyse automatique — à vérifier avant toute décision.';

function countRiskLevels(list) {
  let critique = 0;
  let eleve = 0;
  let modere = 0;
  list.forEach((r) => {
    const crit = riskCriticalityFromMeta(r.meta);
    if (crit) {
      if (crit.tier >= 5) critique += 1;
      else if (crit.tier >= 3) eleve += 1;
      else modere += 1;
      return;
    }
    const s = String(r.status).toLowerCase();
    if (s.includes('critique')) critique += 1;
    else if (s.includes('très') && s.includes('élev')) eleve += 1;
    else if (s.includes('élevé') || s.includes('eleve')) eleve += 1;
    else modere += 1;
  });
  return { critique, eleve, modere };
}

/** @typedef {'critique'|'eleve'|'modere'} RiskTierBucket */

/** @param {{ meta?: string, status?: string }} r */
function riskTierBucket(r) {
  const crit = riskCriticalityFromMeta(r.meta);
  if (crit) {
    if (crit.tier >= 5) return 'critique';
    if (crit.tier >= 3) return 'eleve';
    return 'modere';
  }
  const s = String(r.status).toLowerCase();
  if (s.includes('critique')) return 'critique';
  if (s.includes('très') && s.includes('élev')) return 'eleve';
  if (s.includes('élevé') || s.includes('eleve')) return 'eleve';
  return 'modere';
}

/** @param {Array<{ title?: string, meta?: string, status?: string }>} list */
function countRisksWithoutGp(list) {
  return list.filter((r) => !parseRiskMatrixGp(r.meta)).length;
}

/** @param {Array<{ title?: string, meta?: string, status?: string }>} list */
function sortRisksByPriority(list) {
  return [...list].sort((a, b) => {
    const ca = riskCriticalityFromMeta(a.meta);
    const cb = riskCriticalityFromMeta(b.meta);
    const ta = ca?.tier ?? 0;
    const tb = cb?.tier ?? 0;
    if (tb !== ta) return tb - ta;
    const pa = ca?.product ?? 0;
    const pb = cb?.product ?? 0;
    return pb - pa;
  });
}

/** @param {string} severity @param {string} probability */
function levelsToRegisterMeta(severity, probability) {
  const gMap = { élevée: 5, moyenne: 3, faible: 2 };
  const pMap = { élevée: 4, moyenne: 3, faible: 2 };
  const G = gMap[severity] ?? 3;
  const P = pMap[probability] ?? 3;
  const tier = riskTierFromGp(G, P);
  const status = riskLevelLabelFromTier(tier);
  const tone = tier >= 5 ? 'red' : tier >= 3 ? 'amber' : 'blue';
  return { meta: `G${G} × P${P}`, tone, status };
}

function defaultTitleFromDescription(text) {
  const t = text.trim().replace(/\s+/g, ' ');
  if (!t) return 'Nouveau risque';
  return t.length <= 72 ? t : `${t.slice(0, 69)}…`;
}

/**
 * @param {object} opts
 * @param {(data: { title: string, detail: string, status: string, tone: string, meta: string }) => void} opts.onSaved — liste locale (pas d’API persistance)
 */
function openRiskCreateDialog({ onSaved }) {
  const dialog = document.createElement('dialog');
  dialog.className = 'risks-create-dialog';

  const inner = document.createElement('div');
  inner.className = 'risks-create-dialog__inner';

  inner.innerHTML = `
    <h2 class="risks-create-dialog__head">Nouvelle fiche risque</h2>
    <p class="risks-create-dialog__lead">
      Décrivez le risque. L’analyse automatique propose des pistes : vous gardez le contrôle — rien n’est enregistré sans votre validation.
    </p>
    <form class="risks-form-grid" id="risks-create-form">
      <label>Libellé court
        <input type="text" name="title" autocomplete="off" maxlength="240" placeholder="Ex. Chute hauteur zone concassage" />
      </label>
      <label>Description du risque *
        <textarea name="description" required placeholder="Contexte, causes possibles, exposition…"></textarea>
      </label>
      <div class="risks-form-actions-row">
        <button type="button" class="btn btn-secondary" data-action="analyze">Analyser le risque</button>
      </div>
      <div class="risks-ai-panel" id="risks-ai-panel" hidden>
        <p class="risks-ai-panel__disclaimer" id="risks-ai-disclaimer"></p>
        <div class="risks-ai-panel__kv" id="risks-ai-kv"></div>
        <ul class="risks-ai-panel__list" id="risks-ai-actions"></ul>
        <div class="risks-ai-panel__actions">
          <button type="button" class="btn btn-primary" data-action="apply-suggestions">Appliquer les suggestions</button>
          <button type="button" class="btn btn-secondary" data-action="ignore-suggestions">Ignorer</button>
        </div>
      </div>
      <label>Catégorie
        <select name="category">${CATEGORY_OPTIONS.map(
          (c) => `<option value="${c}">${c}</option>`
        ).join('')}</select>
      </label>
      <label>Gravité estimée
        <select name="severity">${LEVEL_OPTIONS.map(
          (o) => `<option value="${o.value}">${o.label}</option>`
        ).join('')}</select>
      </label>
      <label>Probabilité estimée
        <select name="probability">${LEVEL_OPTIONS.map(
          (o) => `<option value="${o.value}">${o.label}</option>`
        ).join('')}</select>
      </label>
      <label>Actions recommandées (modifiable)
        <textarea name="actions" placeholder="Une mesure par ligne (vous pouvez compléter ou supprimer)."></textarea>
      </label>
      <div class="risks-form-actions-row" style="margin-top:18px">
        <button type="submit" class="btn btn-primary">Valider et ajouter au registre (local)</button>
        <button type="button" class="btn btn-secondary" data-action="close">Annuler</button>
      </div>
    </form>
  `;

  dialog.append(inner);
  document.body.append(dialog);

  const form = inner.querySelector('#risks-create-form');
  const panel = inner.querySelector('#risks-ai-panel');
  const disclaimerEl = inner.querySelector('#risks-ai-disclaimer');
  const kvHost = inner.querySelector('#risks-ai-kv');
  const actionsList = inner.querySelector('#risks-ai-actions');

  /** @type {{ category: string, severity: string, probability: string, suggestedActions: string[] } | null} */
  let pendingSuggestion = null;

  function hidePanel() {
    panel.hidden = true;
    panel.classList.remove('risks-ai-panel--loading');
    pendingSuggestion = null;
    if (disclaimerEl) disclaimerEl.textContent = RISK_AI_DISCLAIMER;
    kvHost.replaceChildren();
    actionsList.replaceChildren();
  }

  function renderSuggestion(data) {
    pendingSuggestion = data;
    if (disclaimerEl) disclaimerEl.textContent = RISK_AI_DISCLAIMER;
    kvHost.innerHTML = `
      <div><span>Catégorie suggérée</span><strong>${escapeHtml(data.category)}</strong></div>
      <div><span>Gravité estimée</span><strong>${escapeHtml(levelLabel(data.severity))}</strong></div>
      <div><span>Probabilité estimée</span><strong>${escapeHtml(levelLabel(data.probability))}</strong></div>
    `;
    actionsList.replaceChildren();
    (data.suggestedActions || []).forEach((line) => {
      const li = document.createElement('li');
      li.textContent = line;
      actionsList.append(li);
    });
    panel.hidden = false;
  }

  inner.querySelector('[data-action="analyze"]').addEventListener('click', async () => {
    const desc = form.description.value.trim();
    if (!desc) {
      showToast('Saisissez une description pour lancer l’analyse.', 'info');
      form.description.focus();
      return;
    }
    panel.hidden = false;
    panel.classList.add('risks-ai-panel--loading');
    if (disclaimerEl) disclaimerEl.textContent = 'Analyse en cours…';
    kvHost.replaceChildren();
    actionsList.replaceChildren();
    try {
      const res = await qhseFetch('/api/risks/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ description: desc })
      });
      const body = await res.json().catch(() => ({}));
      if (!res.ok) {
        hidePanel();
        const msg =
          typeof body?.error === 'string' ? body.error : `Erreur ${res.status}`;
        showToast(msg, 'error');
        return;
      }
      if (
        !body.category ||
        !body.severity ||
        !body.probability ||
        !Array.isArray(body.suggestedActions)
      ) {
        hidePanel();
        showToast('Réponse serveur inattendue.', 'error');
        return;
      }
      panel.classList.remove('risks-ai-panel--loading');
      renderSuggestion(body);
    } catch (err) {
      console.error('[risks] POST /api/risks/analyze', err);
      hidePanel();
      showToast('Impossible de joindre le serveur pour l’analyse.', 'error');
    }
  });

  inner.querySelector('[data-action="apply-suggestions"]').addEventListener('click', () => {
    if (!pendingSuggestion) {
      showToast('Lancez d’abord une analyse.', 'info');
      return;
    }
    const { category, severity, probability, suggestedActions } = pendingSuggestion;
    form.category.value = CATEGORY_OPTIONS.includes(category) ? category : 'Autre';
    form.severity.value = LEVEL_OPTIONS.some((o) => o.value === severity) ? severity : 'moyenne';
    form.probability.value = LEVEL_OPTIONS.some((o) => o.value === probability)
      ? probability
      : 'moyenne';
    form.actions.value = suggestedActions.join('\n');
    showToast('Champs mis à jour — vérifiez et ajustez avant validation.', 'info');
  });

  inner.querySelector('[data-action="ignore-suggestions"]').addEventListener('click', () => {
    hidePanel();
  });

  inner.querySelector('[data-action="close"]').addEventListener('click', () => {
    dialog.close();
  });

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const description = form.description.value.trim();
    if (!description) {
      showToast('La description est obligatoire.', 'info');
      return;
    }
    let title = form.title.value.trim();
    if (!title) title = defaultTitleFromDescription(description);

    const severity = form.severity.value;
    const probability = form.probability.value;
    const actionsText = form.actions.value.trim();
    const cat = form.category.value;
    let detail = description;
    if (cat && cat !== 'Autre') detail = `${description}\n\n(Catégorie : ${cat})`;
    if (actionsText.length > 0) {
      detail = `${detail}\n\n— Mesures envisagées —\n${actionsText}`;
    }

    const { meta, tone, status } = levelsToRegisterMeta(severity, probability);
    const rowData = { title, detail, status, tone, meta };
    onSaved(rowData);
    dialog.close();
    showToast('Fiche ajoutée au registre (session courante). Enregistrement serveur : à brancher si besoin.', 'success');
  });

  dialog.addEventListener('close', () => {
    dialog.remove();
  });

  dialog.showModal();
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function levelLabel(v) {
  const o = LEVEL_OPTIONS.find((x) => x.value === v);
  return o ? o.label : v;
}

export function renderRisks() {
  ensureQhsePilotageStyles();

  const page = document.createElement('section');
  page.className = 'page-stack risks-page';

  const localRisks = [...mockRisks];

  const stripHost = document.createElement('div');
  stripHost.className = 'risks-page__kpi';

  const listStack = document.createElement('div');
  listStack.className = 'risks-page__list-stack';

  /** @type {{ g: number, p: number } | null} */
  let matrixFilter = null;
  /** @type {RiskTierBucket | null} */
  let tierFilter = null;

  const matrixPanel = createRiskMatrixPanel({
    variant: 'embedded',
    onFilterChange: (f) => {
      matrixFilter = f;
      if (f != null) matrixDetails.open = true;
      updateMatrixSummary();
      updateActiveFiltersBar();
      renderList();
    }
  });

  const matrixDetails = document.createElement('details');
  matrixDetails.className = 'risks-matrix-details';

  const matrixSummary = document.createElement('summary');
  matrixSummary.className = 'risks-matrix-details__summary';
  matrixSummary.setAttribute('aria-label', 'Afficher ou masquer la matrice G×P');

  const matrixBody = document.createElement('div');
  matrixBody.className = 'risks-matrix-details__body';
  matrixBody.append(matrixPanel.element);

  matrixDetails.append(matrixSummary, matrixBody);

  function updateMatrixSummary() {
    const placed = localRisks.filter((r) => parseRiskMatrixGp(r.meta)).length;
    const unplaced = countRisksWithoutGp(localRisks);
    const title = '<span class="risks-matrix-details__summary-title">Matrice G×P</span>';
    const meta =
      `<span class="risks-matrix-details__summary-meta">${placed}/${localRisks.length} positionnée(s)` +
      (unplaced > 0
        ? ` · <span class="risks-matrix-details__summary-warn">${unplaced} sans G×P</span>`
        : '') +
      '</span>';
    if (matrixFilter) {
      const sc = matrixFilter.g * matrixFilter.p;
      const lv = riskLevelLabelFromTier(riskTierFromGp(matrixFilter.g, matrixFilter.p));
      matrixSummary.innerHTML = `${title}${meta}<span class="risks-matrix-details__summary-pill">Filtre actif · G${matrixFilter.g}×P${matrixFilter.p} · ${escapeHtml(lv)} (score ${sc})</span>`;
    } else {
      matrixSummary.innerHTML = `${title}${meta}<span class="risks-matrix-details__summary-hint">Ouvrir pour filtrer par case</span>`;
    }
  }

  const insightsHost = document.createElement('div');
  insightsHost.className = 'risks-page__insights';

  const activeFiltersBar = document.createElement('div');
  activeFiltersBar.className = 'risks-page__active-filters';
  activeFiltersBar.hidden = true;

  function updateActiveFiltersBar() {
    const hasTier = tierFilter != null;
    const hasMatrix = matrixFilter != null;
    activeFiltersBar.hidden = !hasTier && !hasMatrix;
    activeFiltersBar.replaceChildren();
    if (activeFiltersBar.hidden) return;
    const label = document.createElement('span');
    label.className = 'risks-page__active-filters-label';
    label.textContent = 'Filtres actifs';
    const actions = document.createElement('div');
    actions.className = 'risks-page__active-filters-actions';
    if (hasTier) {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'btn btn-secondary risks-page__active-filters-btn';
      b.textContent =
        tierFilter === 'critique'
          ? 'Retirer : Critiques'
          : tierFilter === 'eleve'
            ? 'Retirer : Élevés'
            : 'Retirer : Modérés & faibles';
      b.addEventListener('click', () => {
        tierFilter = null;
        syncTierPills();
        updateActiveFiltersBar();
        renderList();
      });
      actions.append(b);
    }
    if (hasMatrix) {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'btn btn-secondary risks-page__active-filters-btn';
      b.textContent = `Retirer : G${matrixFilter.g}×P${matrixFilter.p}`;
      b.addEventListener('click', () => {
        matrixPanel.clearFilter();
      });
      actions.append(b);
    }
    const clearAll = document.createElement('button');
    clearAll.type = 'button';
    clearAll.className = 'btn btn-secondary risks-page__active-filters-btn risks-page__active-filters-btn--ghost';
    clearAll.textContent = 'Tout afficher';
    clearAll.addEventListener('click', () => {
      tierFilter = null;
      matrixPanel.clearFilter();
      syncTierPills();
      updateActiveFiltersBar();
      renderList();
    });
    actions.append(clearAll);
    activeFiltersBar.append(label, actions);
  }

  function renderInsights() {
    const { critique, eleve, modere } = countRiskLevels(localRisks);
    const n = localRisks.length;
    const unplaced = countRisksWithoutGp(localRisks);
    const toTreat = critique + eleve;
    const pct = (x) => (n > 0 ? Math.round((x / n) * 100) : 0);

    insightsHost.replaceChildren();

    const head = document.createElement('div');
    head.className = 'risks-insights__head';
    head.innerHTML = `
      <div class="risks-insights__intro">
        <div class="section-kicker">Vue opérationnelle</div>
        <h3 class="risks-insights__title">Portefeuille en un coup d’œil</h3>
        <p class="risks-insights__lead">Répartition par criticité, priorités immédiates et filtres rapides — aligné avec le pilotage du tableau de bord.</p>
      </div>
      <div class="risks-insights__kpi-inline" aria-label="Synthèse">
        <div class="risks-insights__kpi-item risks-insights__kpi-item--alert">
          <span class="risks-insights__kpi-value">${toTreat}</span>
          <span class="risks-insights__kpi-label">À traiter en priorité</span>
          <span class="risks-insights__kpi-hint">Critiques + élevés</span>
        </div>
        <div class="risks-insights__kpi-item">
          <span class="risks-insights__kpi-value">${unplaced}</span>
          <span class="risks-insights__kpi-label">Sans position G×P</span>
          <span class="risks-insights__kpi-hint">Complétez le meta sur la fiche</span>
        </div>
      </div>
    `;

    const barWrap = document.createElement('div');
    barWrap.className = 'risks-insights__bar-wrap';
    barWrap.setAttribute('aria-label', 'Répartition par criticité');
    const bar = document.createElement('div');
    bar.className = 'risks-insights__bar';
    if (n === 0) {
      bar.innerHTML = '<div class="risks-insights__bar-seg risks-insights__bar-seg--empty" style="width:100%"></div>';
    } else {
      bar.innerHTML = `
        <div class="risks-insights__bar-seg risks-insights__bar-seg--crit" style="width:${pct(critique)}%" title="Critiques : ${critique}"></div>
        <div class="risks-insights__bar-seg risks-insights__bar-seg--elev" style="width:${pct(eleve)}%" title="Élevés : ${eleve}"></div>
        <div class="risks-insights__bar-seg risks-insights__bar-seg--mod" style="width:${pct(modere)}%" title="Modérés / faibles : ${modere}"></div>
      `;
    }
    const barLegend = document.createElement('div');
    barLegend.className = 'risks-insights__bar-legend';
    barLegend.innerHTML = `
      <span><i class="risks-insights__dot risks-insights__dot--crit"></i>Critiques <strong>${critique}</strong></span>
      <span><i class="risks-insights__dot risks-insights__dot--elev"></i>Élevés <strong>${eleve}</strong></span>
      <span><i class="risks-insights__dot risks-insights__dot--mod"></i>Modérés &amp; faibles <strong>${modere}</strong></span>
    `;
    barWrap.append(bar, barLegend);

    const tierRow = document.createElement('div');
    tierRow.className = 'risks-insights__tier-row';
    tierRow.setAttribute('role', 'group');
    tierRow.setAttribute('aria-label', 'Filtrer le registre par palier');
    const tierLabel = document.createElement('span');
    tierLabel.className = 'risks-insights__tier-label';
    tierLabel.textContent = 'Filtrer le registre';
    const tierPills = document.createElement('div');
    tierPills.className = 'risks-insights__tier-pills';

    /** @param {string} key @param {string} text */
    function addTierPill(key, text) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'risks-tier-pill';
      btn.dataset.tierKey = key;
      btn.textContent = text;
      btn.addEventListener('click', () => {
        if (key === 'all') tierFilter = null;
        else if (key === 'critique') tierFilter = 'critique';
        else if (key === 'eleve') tierFilter = 'eleve';
        else tierFilter = 'modere';
        syncTierPills();
        updateActiveFiltersBar();
        renderList();
      });
      tierPills.append(btn);
    }
    addTierPill('all', 'Tout');
    addTierPill('critique', `Critiques (${critique})`);
    addTierPill('eleve', `Élevés (${eleve})`);
    addTierPill('modere', `Modérés & faibles (${modere})`);
    tierRow.append(tierLabel, tierPills);

    const topWrap = document.createElement('div');
    topWrap.className = 'risks-insights__top';
    const topTitle = document.createElement('div');
    topTitle.className = 'risks-insights__top-title';
    topTitle.textContent = 'Top risques prioritaires';
    const topList = document.createElement('ol');
    topList.className = 'risks-insights__top-list';
    const topThree = sortRisksByPriority(localRisks).slice(0, 3);
    if (topThree.length === 0) {
      const li = document.createElement('li');
      li.className = 'risks-insights__top-empty';
      li.textContent = 'Aucune fiche — ajoutez un risque pour voir la priorisation.';
      topList.append(li);
    } else {
      topThree.forEach((r, idx) => {
        const li = document.createElement('li');
        li.className = 'risks-insights__top-item';
        const gp = parseRiskMatrixGp(r.meta);
        const crit = riskCriticalityFromMeta(r.meta);
        const badge = crit
          ? riskLevelLabelFromTier(crit.tier)
          : String(r.status || '—');
        const gpTxt = gp ? `G${gp.g}×P${gp.p}` : 'G×P à renseigner';
        li.innerHTML = `<span class="risks-insights__top-rank">${idx + 1}</span><div class="risks-insights__top-main"><span class="risks-insights__top-name">${escapeHtml(String(r.title || 'Sans titre'))}</span><span class="risks-insights__top-sub">${escapeHtml(gpTxt)} · ${escapeHtml(badge)}</span></div>`;
        topList.append(li);
      });
    }
    topWrap.append(topTitle, topList);

    insightsHost.append(head, barWrap, tierRow, topWrap);
  }

  /** @param {HTMLButtonElement} btn */
  function setTierPillActive(btn, on) {
    btn.classList.toggle('risks-tier-pill--active', on);
    btn.setAttribute('aria-pressed', on ? 'true' : 'false');
  }

  function syncTierPills() {
    const pills = insightsHost.querySelectorAll('.risks-tier-pill');
    pills.forEach((btn) => {
      const key = btn.dataset.tierKey;
      const on =
        (key === 'all' && tierFilter == null) ||
        (key === 'critique' && tierFilter === 'critique') ||
        (key === 'eleve' && tierFilter === 'eleve') ||
        (key === 'modere' && tierFilter === 'modere');
      setTierPillActive(btn, Boolean(on));
    });
  }

  function renderStrip() {
    const { critique, eleve, modere } = countRiskLevels(localRisks);
    const strip = createQhseKpiStrip([
      {
        label: 'Fiches (registre)',
        value: localRisks.length,
        tone: 'blue',
        hint: 'Session courante — à relier au SI pour la persistance'
      },
      {
        label: 'Risques critiques',
        value: critique,
        tone: 'red',
        hint: 'Revues direction / plans de maîtrise'
      },
      {
        label: 'Risques élevés',
        value: eleve,
        tone: 'amber',
        hint: 'Mesures à formaliser'
      },
      {
        label: 'Risques modérés / faibles',
        value: modere,
        tone: 'green',
        hint: 'Surveillance et indicateurs'
      }
    ]);
    stripHost.replaceChildren(strip);
  }

  function renderList() {
    listStack.replaceChildren();
    let rows = localRisks;
    if (tierFilter != null) {
      rows = rows.filter((r) => riskTierBucket(r) === tierFilter);
    }
    if (matrixFilter != null) {
      rows = rows.filter((r) => {
        const gp = parseRiskMatrixGp(r.meta);
        return gp && gp.g === matrixFilter.g && gp.p === matrixFilter.p;
      });
    }
    if (rows.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'risks-page__list-empty';
      const t = document.createElement('p');
      t.className = 'risks-page__list-empty-title';
      const s = document.createElement('p');
      s.className = 'risks-page__list-empty-sub';
      if (localRisks.length === 0) {
        t.textContent = 'Aucune fiche dans le registre';
        s.textContent =
          'Ajoutez un risque pour alimenter le portefeuille et la matrice G×P.';
      } else if (tierFilter != null && matrixFilter != null) {
        t.textContent = 'Aucun résultat pour cette combinaison de filtres';
        s.textContent =
          'Élargissez le palier ou réinitialisez le filtre matrice via « Tout afficher » ou en rouvrant la matrice.';
      } else if (tierFilter != null) {
        t.textContent = 'Aucune fiche pour ce palier';
        s.textContent = 'Choisissez un autre filtre ou cliquez « Tout » dans la vue opérationnelle.';
      } else {
        t.textContent = 'Aucune fiche pour cette case G×P';
        s.textContent =
          'Choisissez une autre case ou utilisez « Tout afficher » dans le panneau matrice.';
      }
      empty.append(t, s);
      listStack.append(empty);
      return;
    }
    rows.forEach((r) => listStack.append(createRiskRegisterRow(r)));
  }

  renderStrip();
  renderInsights();
  syncTierPills();
  updateMatrixSummary();
  updateActiveFiltersBar();
  renderList();
  matrixPanel.setRisks(localRisks);

  const register = document.createElement('article');
  register.className = 'content-card card-soft risks-page__panel risks-page__panel--register';
  register.innerHTML = `
    <div class="risks-page__panel-head content-card-head content-card-head--split">
      <div class="risks-page__panel-intro">
        <div class="section-kicker">Registre des risques</div>
        <h3>Portefeuille QHSE</h3>
        <p class="content-card-lead risks-page__panel-lead">
          Fiches détaillées et criticité : la matrice G×P reste disponible ci-dessous, repliée par défaut, pour filtrer par case sans encombrer la lecture.
        </p>
      </div>
      <button type="button" class="btn btn-primary risks-add-btn btn--pilotage-cta">
        + Ajouter un risque
      </button>
    </div>
    <div class="risks-page__list-region"></div>
  `;
  register.querySelector('.risks-page__list-region').append(activeFiltersBar, listStack);

  register.querySelector('.risks-add-btn').addEventListener('click', () => {
    openRiskCreateDialog({
      onSaved: (data) => {
        localRisks.unshift(data);
        matrixPanel.clearFilter();
        renderStrip();
        renderInsights();
        syncTierPills();
        updateMatrixSummary();
        updateActiveFiltersBar();
        renderList();
        matrixPanel.setRisks(localRisks);
      }
    });
  });

  const matrixSection = document.createElement('section');
  matrixSection.className = 'risks-page__matrix-section';
  matrixSection.append(matrixDetails);

  page.append(stripHost, insightsHost, register, matrixSection);
  return page;
}
